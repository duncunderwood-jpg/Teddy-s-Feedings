# Teddy’s Feedings 1.2

Pull down on Home, History, or Insights to reload saved feedings. This refreshes local data, not a cloud account.

## Siri
Say “Hey Siri, Teddy drank in Teddy’s Feedings.” When prompted, say “Teddy drank 3 ounces of formula at 8:15 PM.” A successful save returns a spoken confirmation including amount, milk type, date, and time. Siri’s audio settings control whether it speaks.

For a shorter phrase, create a personal shortcut named “Teddy drank” in Apple Shortcuts. Add Dictate Text, then the app’s “Teddy drank” action. Set its “What did Teddy drink?” parameter to Dictated Text. Say “Hey Siri, Teddy drank,” then dictate the full bottle description. The app does not install this personal shortcut automatically.

Apple’s automatic App Shortcut phrases must include the app name. The exact single utterance “Hey Siri, Teddy drank [amount] [milk] at [time]” is not guaranteed and is not advertised as supported. The personal shortcut uses a brief dictation step instead. Include units and AM/PM. Omitted units default to ounces. Omitted time defaults to now. Unrecognized explicit times are rejected.

Supports formula, breast milk, expressed milk, mixed bottles with separate amounts, ounces and milliliters. Basic number words one–twenty and phrases such as “three and a half ounces” are accepted for milk amounts. Use numeric time dictation such as “8:15 PM”.

Physical-device Siri recognition, spoken responses, notification delivery, and free-account signing still require on-device verification.
