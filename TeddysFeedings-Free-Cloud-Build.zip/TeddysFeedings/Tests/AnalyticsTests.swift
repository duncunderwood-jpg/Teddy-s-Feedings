import Foundation

@main
struct AnalyticsTests {
    static func main() {
        var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(secondsFromGMT: 0)!
        let now = ISO8601DateFormatter().date(from: "2026-10-26T12:00:00Z")!
        let midnight = c.startOfDay(for: now)
        let original = Feeding(time: midnight.addingTimeInterval(-60), formulaML: 60, breastMilkML: 0)
        let topoff = Feeding(time: midnight.addingTimeInterval(60), formulaML: 15, breastMilkML: 5)
        let combined = FeedingPlan.addingTopUp(topoff, to: original)!
        let breast = Feeding(time: midnight.addingTimeInterval(3600), formulaML: 0, breastMilkML: 40)
        let future = Feeding(time: now.addingTimeInterval(600), formulaML: 500, breastMilkML: 0)
        let today = FeedingAnalytics([combined, breast, future], dayCount: 1, now: now, calendar: c)
        precondition(today.days.count == 1 && today.totalML == 60 && today.formulaML == 15 && today.breastML == 45)
        precondition(today.count == 2 && today.averageBottle == 30 && today.days[0].count == 2)
        precondition(today.mixedCount == 1 && today.breastOnlyCount == 1 && today.formulaOnlyCount == 0)
        precondition(today.averageGap == nil && today.hourly.reduce(0, { $0 + $1.count }) == 1)
        precondition(today.previousTotalML == 60 && today.changePercent == 0)
        let week = FeedingAnalytics([combined, breast], dayCount: 7, now: now, calendar: c)
        precondition(week.totalML == 120 && week.count == 2 && week.activeDays == 2)
        precondition(abs(week.averagePerDay - 120 / 7.0) < 0.0001)
        precondition(abs(week.rolling.last!.averageML - 120 / 7.0) < 0.0001)
        let empty = FeedingAnalytics([], dayCount: 30, now: now, calendar: c)
        precondition(empty.days.count == 30 && empty.totalML == 0 && empty.averageBottle == nil && empty.changePercent == nil)
        let all = FeedingAnalytics([combined, breast], dayCount: nil, now: now, calendar: c)
        precondition(all.days.count == 2 && all.totalML == 120)
        let ninety = FeedingAnalytics([combined, breast], dayCount: 90, now: now, calendar: c)
        precondition(ninety.chartBuckets(calendar: c).reduce(0, { $0 + $1.totalML }) == 120)
        // Calendar-day boundaries survive daylight saving time, without assuming 86400-second days.
        var dst = Calendar(identifier: .gregorian); dst.timeZone = TimeZone(identifier: "America/New_York")!
        let dstNow = ISO8601DateFormatter().date(from: "2026-11-02T17:00:00Z")!
        let dstStats = FeedingAnalytics([], dayCount: 7, now: dstNow, calendar: dst)
        precondition(dstStats.days.count == 7 && Set(dstStats.days.map(\.date)).count == 7)
        print("Analytics tests passed: milk split, midnight top-offs, unique counts, future exclusion, averages, comparison, rolling trend, empty/all-time ranges, bucket totals, DST")
    }
}
