import Foundation

// Run on macOS or Linux: swiftc TeddysFeedings/Models.swift TeddysFeedings/SpokenFeedingParser.swift Tests/ParserSmokeTests.swift -o /tmp/teddy-parser-tests
@main
struct ParserSmokeTests {
    static func main() throws {
        let now = ISO8601DateFormatter().date(from: "2026-10-25T21:30:00Z")!
        var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(secondsFromGMT: 0)!
        let mixed = try SpokenFeedingParser.parse("I fed Teddy 3 ounces of formula and 1 ounce of breast milk at 8:15 PM", now: now, calendar: c)
        precondition(abs(mixed.formulaML - 88.72) < 0.05)
        precondition(abs(mixed.breastMilkML - 29.57) < 0.05)
        precondition(c.component(.hour, from: mixed.time) == 20)
        precondition(c.component(.minute, from: mixed.time) == 15)

        let breast = try SpokenFeedingParser.parse("Teddy drank 75 ml breast milk", now: now, calendar: c)
        precondition(abs(breast.breastMilkML - 75) < 0.01)
        precondition(breast.formulaML == 0)
        let reverse = try SpokenFeedingParser.parse("formula 2oz and breast milk 35 ml at 7 am", now: now, calendar: c)
        precondition(abs(reverse.formulaML - 59.147) < 0.01)
        precondition(abs(reverse.breastMilkML - 35) < 0.01)
        let noTime = try SpokenFeedingParser.parse("2.5 ounces of formula", now: now, calendar: c)
        precondition(noTime.time == now)

        do {
            _ = try SpokenFeedingParser.parse("3 oz of formula and breast milk", now: now, calendar: c)
            fatalError("An ambiguous mixed bottle should not be silently split")
        } catch SpokenFeedingError.ambiguousMixedVolume { }
        do {
            _ = try SpokenFeedingParser.parse("3 oz formula at 25:99", now: now, calendar: c)
            fatalError("Invalid time should fail")
        } catch SpokenFeedingError.invalidTime { }
        let natural = try SpokenFeedingParser.parse("Teddy drank three and a half ounces of formula at 8:15 PM", now: now, calendar: c)
        precondition(abs(natural.formulaML - 103.507) < 0.01)
        let words = try SpokenFeedingParser.parse("Teddy drank two ounces of breast milk at 7 AM", now: now, calendar: c)
        precondition(abs(words.breastMilkML - 59.147) < 0.01)
        do {
            _ = try SpokenFeedingParser.parse("Teddy drank 3 oz formula at banana", now: now, calendar: c)
            fatalError("An unrecognized explicit time must not silently become now")
        } catch SpokenFeedingError.invalidTime { }
        let last = Feeding(time: now.addingTimeInterval(-3600), formulaML: VolumeUnit.ounces.toMilliliters(2), breastMilkML: VolumeUnit.ounces.toMilliliters(1))
        let older = Feeding(time: now.addingTimeInterval(-7200), formulaML: 120, breastMilkML: 0)
        let future = Feeding(time: now.addingTimeInterval(3600), formulaML: 999, breastMilkML: 0)
        let message = FeedingReminderMessage.text(feedings: [older, future, last], unit: .ounces, now: now)
        precondition(message.contains("Formula: 2 oz") && message.contains("Breast milk: 1 oz") && message.contains("Total: 3 oz"))
        precondition(message.contains(last.time.formatted(date: .abbreviated, time: .shortened)))
        let metric = FeedingReminderMessage.text(feedings: [older], unit: .milliliters, now: now)
        precondition(metric.contains("Formula: 120 mL") && metric.contains("Breast milk: 0 mL"))
        precondition(FeedingReminderMessage.text(feedings: [], unit: .ounces, now: now).contains("No previous feeding"))
        let birthday = c.date(byAdding: .month, value: -1, to: now)!
        let ageGuide = AgeFeedingGuide.text(birthDate: birthday, unit: .ounces, now: now, calendar: c)
        precondition(ageGuide.contains("3–4 oz") && ageGuide.contains("1 month"))
        precondition(AgeFeedingGuide.text(birthDate: nil, unit: .ounces, now: now).contains("birth date"))
        precondition(AgeFeedingGuide.text(birthDate: now.addingTimeInterval(1000), unit: .ounces, now: now).contains("birth date"))
        let newborn = AgeFeedingGuide.text(birthDate: now, unit: .ounces, now: now, calendar: c)
        precondition(newborn.contains("0.5 oz"))
        let olderBirthday = c.date(byAdding: .month, value: -12, to: now)!
        precondition(AgeFeedingGuide.text(birthDate: olderBirthday, unit: .ounces, now: now, calendar: c).contains("after infancy"))
        // Preserve old logs/settings when optional fields are introduced.
        let oldJSON = "{\"id\":\"11111111-1111-1111-1111-111111111111\",\"time\":0,\"formulaML\":60,\"breastMilkML\":30,\"notes\":\"old record\"}".data(using: .utf8)!
        let migrated = try JSONDecoder().decode(Feeding.self, from: oldJSON)
        precondition(migrated.totalML == 90 && migrated.offeredTotalML == nil && migrated.lastMilkAt == migrated.time)
        let oldSettings = try JSONDecoder().decode(TeddySettings.self, from: "{}".data(using: .utf8)!)
        precondition(oldSettings.clinicianTarget == nil && oldSettings.reminderSoundEnabled)
        var original = Feeding(time: now.addingTimeInterval(-120), formulaML: 60, breastMilkML: 30, notes: "Original", offeredFormulaML: 90, offeredBreastMilkML: 30)
        let extra = Feeding(time: now, formulaML: 15, breastMilkML: 0, offeredFormulaML: 30, offeredBreastMilkML: 0)
        let combined = FeedingPlan.addingTopUp(extra, to: original)!
        precondition(combined.id == original.id && combined.time == original.time && combined.lastMilkAt == now)
        precondition(combined.totalML == 105 && combined.offeredTotalML == 150 && combined.notes.contains("Original"))
        precondition(combined.topUps?.count == 1)
        let midnight = c.startOfDay(for: now)
        let beforeMidnight = Feeding(time: midnight.addingTimeInterval(-60), formulaML: 60, breastMilkML: 0)
        let afterMidnight = Feeding(time: midnight.addingTimeInterval(60), formulaML: 15, breastMilkML: 5)
        let overnight = FeedingPlan.addingTopUp(afterMidnight, to: beforeMidnight)!
        precondition(overnight.milk(on: midnight, calendar: c).formula == 15 && overnight.milk(on: midnight, calendar: c).breast == 5)
        precondition(overnight.milk(on: midnight.addingTimeInterval(-86400), calendar: c).formula == 60)
        let roundTrip = try JSONDecoder().decode(Feeding.self, from: JSONEncoder().encode(combined))
        precondition(roundTrip == combined)
        original.offeredFormulaML = nil
        precondition(FeedingPlan.addingTopUp(extra, to: original)?.offeredTotalML == nil)
        let earlierTopUp = Feeding(time: original.time.addingTimeInterval(-1), formulaML: 10, breastMilkML: 0)
        precondition(FeedingPlan.addingTopUp(earlierTopUp, to: original) == nil)
        let target = ClinicianFeedingTarget(minimumML: 80, maximumML: 100)
        precondition(target.isValid && !ClinicianFeedingTarget(minimumML: 100, maximumML: 80).isValid)
        let planned = FeedingPlan.message(feedings: [], unit: .milliliters, birthDate: birthday, target: target, now: now)
        precondition(planned.contains("80 mL to 100 mL") && !planned.contains("Next bottle guide"))
        let sample = [30.0, 60, 90, 120].map { Feeding(time: now.addingTimeInterval(-3600), formulaML: $0, breastMilkML: 0) }
        precondition(FeedingPlan.typicalML(sample, now: now) == 75)
        precondition(FeedingPlan.typicalML(Array(sample.prefix(2)), now: now) == nil)
        let oldSample = sample.map { f in var copy = f; copy.time = now.addingTimeInterval(-8 * 86400); return copy }
        precondition(FeedingPlan.typicalML(oldSample, now: now) == nil)
        print("Feeding-plan tests passed (migration, offered/consumed, top-up identity/time, roundtrip, unknown offered, target priority, recent median).")
        print("Age guide tests passed (missing/future birthday, newborn, month, after infancy).")
        print("Reminder tests passed (latest past feeding, mixed bottle, timestamp, units, zero amount, empty history).")
        print("Parser tests passed (mixed, milliliters, reverse syntax, default time, ambiguity, invalid time).")
    }
}
