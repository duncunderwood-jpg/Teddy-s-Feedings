import Foundation

// Run on macOS or Linux: swiftc TeddysFeedings/Models.swift TeddysFeedings/SpokenFeedingParser.swift Tests/ParserSmokeTests.swift -o /tmp/teddy-parser-tests
@main
struct ParserSmokeTests {
    static func main() throws {
        let now = ISO8601DateFormatter().date(from: "2026-10-25T21:30:00Z")!
        var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(secondsFromGMT: 0)!
        let mixed = try SpokenFeedingParser.parse("I fed Teddy 3 ounces of formula and 1 ounce of breast milk at 8:15 PM", now: now, calendar: c)
        precondition(abs(mixed.formulaML - 88.72) < 0.05)
        precondition(abs(mixed.breastMilkML - 29.57) < 0.05)
        precondition(c.component(.hour, from: mixed.time) == 20)
        precondition(c.component(.minute, from: mixed.time) == 15)

        let breast = try SpokenFeedingParser.parse("Teddy drank 75 ml breast milk", now: now, calendar: c)
        precondition(abs(breast.breastMilkML - 75) < 0.01)
        precondition(breast.formulaML == 0)
        let reverse = try SpokenFeedingParser.parse("formula 2oz and breast milk 35 ml at 7 am", now: now, calendar: c)
        precondition(abs(reverse.formulaML - 59.147) < 0.01)
        precondition(abs(reverse.breastMilkML - 35) < 0.01)
        let noTime = try SpokenFeedingParser.parse("2.5 ounces of formula", now: now, calendar: c)
        precondition(noTime.time == now)

        do {
            _ = try SpokenFeedingParser.parse("3 oz of formula and breast milk", now: now, calendar: c)
            fatalError("An ambiguous mixed bottle should not be silently split")
        } catch SpokenFeedingError.ambiguousMixedVolume { }
        do {
            _ = try SpokenFeedingParser.parse("3 oz formula at 25:99", now: now, calendar: c)
            fatalError("Invalid time should fail")
        } catch SpokenFeedingError.invalidTime { }
        let natural = try SpokenFeedingParser.parse("Teddy drank three and a half ounces of formula at 8:15 PM", now: now, calendar: c)
        precondition(abs(natural.formulaML - 103.507) < 0.01)
        let words = try SpokenFeedingParser.parse("Teddy drank two ounces of breast milk at 7 AM", now: now, calendar: c)
        precondition(abs(words.breastMilkML - 59.147) < 0.01)
        do {
            _ = try SpokenFeedingParser.parse("Teddy drank 3 oz formula at banana", now: now, calendar: c)
            fatalError("An unrecognized explicit time must not silently become now")
        } catch SpokenFeedingError.invalidTime { }
        print("Parser tests passed (mixed, milliliters, reverse syntax, default time, ambiguity, invalid time).")
    }
}
