import Foundation

// Run on macOS or Linux: swiftc TeddysFeedings/Models.swift TeddysFeedings/SpokenFeedingParser.swift Tests/ParserSmokeTests.swift -o /tmp/teddy-parser-tests
@main
struct ParserSmokeTests {
    static func main() throws {
        let now = ISO8601DateFormatter().date(from: "2026-10-25T21:30:00Z")!
        var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(secondsFromGMT: 0)!
        let mixed = try SpokenFeedingParser.parse("I fed Teddy 3 ounces of formula and 1 ounce of breast milk at 8:15 PM", now: now, calendar: c)
        precondition(abs(mixed.formulaML - 88.72) < 0.05)
        precondition(abs(mixed.breastMilkML - 29.57) < 0.05)
        precondition(c.component(.hour, from: mixed.time) == 20)
        precondition(c.component(.minute, from: mixed.time) == 15)

        let breast = try SpokenFeedingParser.parse("Teddy drank 75 ml breast milk", now: now, calendar: c)
        precondition(abs(breast.breastMilkML - 75) < 0.01)
        precondition(breast.formulaML == 0)
        let reverse = try SpokenFeedingParser.parse("formula 2oz and breast milk 35 ml at 7 am", now: now, calendar: c)
        precondition(abs(reverse.formulaML - 59.147) < 0.01)
        precondition(abs(reverse.breastMilkML - 35) < 0.01)
        let noTime = try SpokenFeedingParser.parse("2.5 ounces of formula", now: now, calendar: c)
        precondition(noTime.time == now)

        for phrase in ["Log 3 ounces of formula", "Log three ounces of formula", "Log 90 ml breast milk", "Log 2 ounces formula and 1 ounce breast milk"] {
            let automatic = try SpokenFeedingParser.parse(phrase, now: now, calendar: c)
            precondition(automatic.time == now)
        }
        let half = try SpokenFeedingParser.parse("Log .5 oz formula", now: now, calendar: c)
        precondition(abs(half.formulaML - VolumeUnit.ounces.toMilliliters(0.5)) < 0.001)
        do { _ = try SpokenFeedingParser.parse("Log -3 oz formula"); fatalError("Negative milk must fail") }
        catch SpokenFeedingError.invalidVolume { }
        let earlier = Feeding(time: now.addingTimeInterval(-3600), formulaML: VolumeUnit.ounces.toMilliliters(2), breastMilkML: 0)
        let newBottle = Feeding(time: now, formulaML: VolumeUnit.ounces.toMilliliters(2), breastMilkML: VolumeUnit.ounces.toMilliliters(1))
        let later = Feeding(time: now.addingTimeInterval(3600), formulaML: 900, breastMilkML: 0)
        let comparison = SiriFeedingConfirmation.text(for: newBottle, history: [newBottle, later, earlier], unit: .ounces)
        precondition(comparison.contains("2 ounces of formula and 1 ounce of breast milk"))
        precondition(comparison.contains("1 ounce more than his last logged feeding") && comparison.contains("Looks like Teddy wanted a little more milk"))
        let smaller = Feeding(time: now, formulaML: VolumeUnit.ounces.toMilliliters(1.5), breastMilkML: 0)
        precondition(SiriFeedingConfirmation.text(for: smaller, history: [earlier], unit: .ounces).contains("0.5 ounces less"))
        var equal = earlier; equal.id = UUID(); equal.time = now
        precondition(SiriFeedingConfirmation.text(for: equal, history: [earlier], unit: .ounces).contains("same amount"))
        precondition(!SiriFeedingConfirmation.text(for: newBottle, history: [newBottle, later], unit: .ounces).contains("last logged feeding"))
        let metricOld = Feeding(time: now.addingTimeInterval(-60), formulaML: 90, breastMilkML: 0)
        let metricNew = Feeding(time: now, formulaML: 60, breastMilkML: 0)
        precondition(SiriFeedingConfirmation.text(for: metricNew, history: [metricOld], unit: .milliliters).contains("30 milliliters less"))
        do {
            _ = try SpokenFeedingParser.parse("3 oz of formula and breast milk", now: now, calendar: c)
            fatalError("An ambiguous mixed bottle should not be silently split")
        } catch SpokenFeedingError.ambiguousMixedVolume { }
        do {
            _ = try SpokenFeedingParser.parse("3 oz formula at 25:99", now: now, calendar: c)
            fatalError("Invalid time should fail")
        } catch SpokenFeedingError.invalidTime { }
        let natural = try SpokenFeedingParser.parse("Teddy drank three and a half ounces of formula at 8:15 PM", now: now, calendar: c)
        precondition(abs(natural.formulaML - 103.507) < 0.01)
        let words = try SpokenFeedingParser.parse("Teddy drank two ounces of breast milk at 7 AM", now: now, calendar: c)
        precondition(abs(words.breastMilkML - 59.147) < 0.01)
        do {
            _ = try SpokenFeedingParser.parse("Teddy drank 3 oz formula at banana", now: now, calendar: c)
            fatalError("An unrecognized explicit time must not silently become now")
        } catch SpokenFeedingError.invalidTime { }
        let last = Feeding(time: now.addingTimeInterval(-3600), formulaML: VolumeUnit.ounces.toMilliliters(2), breastMilkML: VolumeUnit.ounces.toMilliliters(1))
        let older = Feeding(time: now.addingTimeInterval(-7200), formulaML: 120, breastMilkML: 0)
        let future = Feeding(time: now.addingTimeInterval(3600), formulaML: 999, breastMilkML: 0)
        let message = FeedingReminderMessage.text(feedings: [older, future, last], unit: .ounces, now: now)
        precondition(message.contains("Formula: 2 oz") && message.contains("Breast milk: 1 oz") && message.contains("Total: 3 oz"))
        precondition(message.contains(last.time.formatted(date: .abbreviated, time: .shortened)))
        let metric = FeedingReminderMessage.text(feedings: [older], unit: .milliliters, now: now)
        precondition(metric.contains("Formula: 120 mL") && metric.contains("Breast milk: 0 mL"))
        precondition(FeedingReminderMessage.text(feedings: [], unit: .ounces, now: now).contains("No previous feeding"))
        let birthday = c.date(byAdding: .month, value: -1, to: now)!
        let ageGuide = AgeFeedingGuide.text(birthDate: birthday, unit: .ounces, now: now, calendar: c)
        precondition(ageGuide.contains("3–4 oz") && ageGuide.contains("1 month"))
        precondition(AgeFeedingGuide.text(birthDate: nil, unit: .ounces, now: now).contains("birth date"))
        precondition(AgeFeedingGuide.text(birthDate: now.addingTimeInterval(1000), unit: .ounces, now: now).contains("birth date"))
        let newborn = AgeFeedingGuide.text(birthDate: now, unit: .ounces, now: now, calendar: c)
        precondition(newborn.contains("0.5 oz"))
        let olderBirthday = c.date(byAdding: .month, value: -12, to: now)!
        precondition(AgeFeedingGuide.text(birthDate: olderBirthday, unit: .ounces, now: now, calendar: c).contains("after infancy"))
        // Preserve old logs/settings when optional fields are introduced.
        let oldJSON = "{\"id\":\"11111111-1111-1111-1111-111111111111\",\"time\":0,\"formulaML\":60,\"breastMilkML\":30,\"notes\":\"old record\"}".data(using: .utf8)!
        let migrated = try JSONDecoder().decode(Feeding.self, from: oldJSON)
        precondition(migrated.totalML == 90 && migrated.offeredTotalML == nil && migrated.lastMilkAt == migrated.time)
        let oldSettings = try JSONDecoder().decode(TeddySettings.self, from: "{}".data(using: .utf8)!)
        precondition(oldSettings.clinicianTarget == nil && oldSettings.reminderSoundEnabled)
        var original = Feeding(time: now.addingTimeInterval(-120), formulaML: 60, breastMilkML: 30, notes: "Original", offeredFormulaML: 90, offeredBreastMilkML: 30)
        let extra = Feeding(time: now, formulaML: 15, breastMilkML: 0, offeredFormulaML: 30, offeredBreastMilkML: 0)
        let combined = FeedingPlan.addingTopUp(extra, to: original)!
        precondition(combined.id == original.id && combined.time == original.time && combined.lastMilkAt == now)
        precondition(combined.totalML == 105 && combined.offeredTotalML == 150 && combined.notes.contains("Original"))
        precondition(combined.topUps?.count == 1)
        let midnight = c.startOfDay(for: now)
        let beforeMidnight = Feeding(time: midnight.addingTimeInterval(-60), formulaML: 60, breastMilkML: 0)
        let afterMidnight = Feeding(time: midnight.addingTimeInterval(60), formulaML: 15, breastMilkML: 5)
        let overnight = FeedingPlan.addingTopUp(afterMidnight, to: beforeMidnight)!
        precondition(overnight.milk(on: midnight, calendar: c).formula == 15 && overnight.milk(on: midnight, calendar: c).breast == 5)
        precondition(overnight.milk(on: midnight.addingTimeInterval(-86400), calendar: c).formula == 60)
        let roundTrip = try JSONDecoder().decode(Feeding.self, from: JSONEncoder().encode(combined))
        precondition(roundTrip == combined)
        original.offeredFormulaML = nil
        precondition(FeedingPlan.addingTopUp(extra, to: original)?.offeredTotalML == nil)
        let earlierTopUp = Feeding(time: original.time.addingTimeInterval(-1), formulaML: 10, breastMilkML: 0)
        precondition(FeedingPlan.addingTopUp(earlierTopUp, to: original) == nil)
        let target = ClinicianFeedingTarget(minimumML: 80, maximumML: 100)
        precondition(target.isValid && !ClinicianFeedingTarget(minimumML: 100, maximumML: 80).isValid)
        let planned = FeedingPlan.message(feedings: [], unit: .milliliters, birthDate: birthday, target: target, now: now)
        precondition(planned.contains("80 mL to 100 mL") && !planned.contains("Next bottle guide"))
        let sample = [30.0, 60, 90, 120].map { Feeding(time: now.addingTimeInterval(-3600), formulaML: $0, breastMilkML: 0) }
        precondition(FeedingPlan.typicalML(sample, now: now) == 75)
        precondition(FeedingPlan.typicalML(Array(sample.prefix(2)), now: now) == nil)
        let oldSample = sample.map { f in var copy = f; copy.time = now.addingTimeInterval(-8 * 86400); return copy }
        precondition(FeedingPlan.typicalML(oldSample, now: now) == nil)
        print("Feeding-plan tests passed (migration, offered/consumed, top-up identity/time, roundtrip, unknown offered, target priority, recent median).")
        print("Age guide tests passed (missing/future birthday, newborn, month, after infancy).")
        print("Reminder tests passed (latest past feeding, mixed bottle, timestamp, units, zero amount, empty history).")
        let pumped = try PumpingSpeechParser.parse("I pumped three and a half ounces")
        precondition(abs(pumped - VolumeUnit.ounces.toMilliliters(3.5)) < 0.001)
        let metricPumped = try PumpingSpeechParser.parse("I pumped 90 ml"); precondition(metricPumped == 90)
        let defaultMetric = try PumpingSpeechParser.parse("90", defaultUnit: .milliliters); precondition(defaultMetric == 90)
        let leadingHalf = try PumpingSpeechParser.parse("I pumped .5 ounces"); precondition(abs(leadingHalf - VolumeUnit.ounces.toMilliliters(0.5)) < 0.001)
        let commaHalf = try PumpingSpeechParser.parse("I pumped 0,5 oz"); precondition(abs(commaHalf - VolumeUnit.ounces.toMilliliters(0.5)) < 0.001)
        let zeroPumped = try PumpingSpeechParser.parse("I pumped zero ounces"); precondition(zeroPumped == 0)
        for invalid in ["I pumped -3 ounces", "I pumped 2 ounces and 1 ounce", "I pumped a lot", "I pumped 3000 ml"] {
            do { _ = try PumpingSpeechParser.parse(invalid); fatalError("Invalid pumping amount accepted") }
            catch { }
        }
        let pump = PumpingSession(endedAt: now, amountML: 90)
        precondition(pump.durationMinutes == 30 && pump.startedAt == now.addingTimeInterval(-1800))
        precondition(pump.isValid(now: now))
        precondition(!PumpingSession(endedAt: now.addingTimeInterval(120), amountML: 90).isValid(now: now))
        precondition(!PumpingSession(endedAt: now, amountML: -1).isValid(now: now))
        precondition(!PumpingSession(endedAt: now, amountML: 90, durationMinutes: 20).isValid(now: now))
        let pumpCopy = try JSONDecoder().decode(PumpingSession.self, from: JSONEncoder().encode(pump))
        precondition(pumpCopy == pump)
        let weekPumps = PumpingMath.days([pump], now: now, calendar: c)
        precondition(weekPumps.count == 7 && weekPumps.reduce(0, { $0 + $1.amountML }) == 90)
        precondition(weekPumps.filter({ $0.count > 0 }).count == 1)
        let startOfDay = c.startOfDay(for: now)
        let firstPump = PumpingSession(endedAt: startOfDay.addingTimeInterval(5 * 60), amountML: 30)
        let secondPump = PumpingSession(endedAt: startOfDay.addingTimeInterval(29 * 60), amountML: 60)
        let thirdPump = PumpingSession(endedAt: startOfDay.addingTimeInterval(30 * 60), amountML: 15)
        let halfHours = PumpingMath.halfHours([firstPump, secondPump, thirdPump], day: now, calendar: c)
        precondition(halfHours.count == 2 && halfHours[0].amountML == 90 && halfHours[1].amountML == 15)
        precondition(PumpingMath.percentage(25, total: 100).contains("25") && PumpingMath.percentage(0, total: 0) == "—")
        var pumpSettings = try JSONDecoder().decode(TeddySettings.self, from: Data("{}".utf8))
        precondition(!pumpSettings.pumpingRemindersEnabled && pumpSettings.pumpingReminderIntervalMinutes == 180 && pumpSettings.pumpingReminderSoundEnabled)
        precondition(PumpingReminderPlan.due(sessions: [pump], settings: pumpSettings, now: now) == nil)
        pumpSettings.pumpingRemindersEnabled = true
        precondition(PumpingReminderPlan.due(sessions: [], settings: pumpSettings, now: now) == nil)
        let futurePump = PumpingSession(endedAt: now.addingTimeInterval(3600), amountML: 900)
        let oldPump = PumpingSession(endedAt: now.addingTimeInterval(-3600), amountML: 30)
        precondition(PumpingReminderPlan.due(sessions: [oldPump, futurePump, pump], settings: pumpSettings, now: now) == now.addingTimeInterval(10800))
        pumpSettings.pumpingReminderIntervalMinutes = 120
        precondition(PumpingReminderPlan.due(sessions: [pump], settings: pumpSettings, now: now) == now.addingTimeInterval(7200))
        precondition(PumpingReminderPlan.due(sessions: [oldPump], settings: pumpSettings, now: now) == now.addingTimeInterval(3600))
        let pumpingMessage = PumpingReminderPlan.message(sessions: [futurePump, pump], unit: .milliliters, now: now)
        precondition(pumpingMessage.contains("90 mL") && pumpingMessage.contains("30-minute"))
        let roundtripSettings = try JSONDecoder().decode(TeddySettings.self, from: JSONEncoder().encode(pumpSettings))
        precondition(roundtripSettings == pumpSettings)
        print("Pumping tests passed (speech units, decimals, invalid/multiple amounts, zero, session validation/roundtrip, seven days, half-hour boundaries, percentages).")
        print("Parser tests passed (mixed, milliliters, reverse syntax, default time, ambiguity, invalid time).")
    }
}
