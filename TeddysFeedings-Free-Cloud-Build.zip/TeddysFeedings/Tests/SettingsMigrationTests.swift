import Foundation

@main
struct SettingsMigrationTests {
    static func main() throws {
        // Prior iOS versions did not contain reminderSoundEnabled.
        let oldSettings = #"{"babyName":"Teddy","unit":"oz","remindersEnabled":true,"reminderIntervalMinutes":180}"#
        let migrated = try JSONDecoder().decode(TeddySettings.self, from: Data(oldSettings.utf8))
        precondition(migrated.babyName == "Teddy")
        precondition(migrated.remindersEnabled)
        precondition(migrated.reminderSoundEnabled)
        let fresh = try JSONDecoder().decode(TeddySettings.self, from: JSONEncoder().encode(TeddySettings()))
        precondition(fresh.reminderSoundEnabled)
        precondition(VolumeUnit.milliliters.display(118.0) == "118 mL")
        precondition(VolumeUnit.ounces.display(88.7205886875) == "3 oz")
        print("Settings migration and unit display tests passed")
    }
}
