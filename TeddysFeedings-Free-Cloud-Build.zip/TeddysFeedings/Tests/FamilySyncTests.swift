import Foundation

@main
struct FamilySyncTests {
    static func main() throws {
        let localBottle = Feeding(time: Date(), formulaML: 90, breastMilkML: 0)
        let localPump = PumpingSession(endedAt: Date(), amountML: 60)
        let excluded = FamilyJournalSeed(feedings: [localBottle], pumping: [localPump], confirmedRealRecords: false)
        precondition(excluded.feedings.isEmpty && excluded.pumping.isEmpty)
        let included = FamilyJournalSeed(feedings: [localBottle], pumping: [localPump], confirmedRealRecords: true)
        precondition(included.feedings == [localBottle] && included.pumping == [localPump])
        var ledger = FamilySyncLedger()
        ledger.stage(id: "feeding_A", payload: "first", author: "Duncan")
        let sent = ledger.pending[0]
        var accepted = sent.value; accepted.revision = 1
        ledger.acknowledge(id: sent.id, sent: sent, remote: accepted)
        precondition(ledger.pending.isEmpty && ledger.records[sent.id]?.baseRevision == 1)
        ledger.stage(id: sent.id, payload: "second", author: "Duncan")
        let second = ledger.pending[0]
        ledger.stage(id: sent.id, payload: "third", author: "Duncan")
        var acceptedSecond = second.value; acceptedSecond.revision = 2
        // Listener may observe our old upload before its completion callback.
        ledger.receive(id: sent.id, remote: acceptedSecond)
        ledger.acknowledge(id: sent.id, sent: second, remote: acceptedSecond)
        precondition(ledger.pending.count == 1 && ledger.conflicts.isEmpty)
        precondition(ledger.pending[0].baseRevision == 2 && ledger.pending[0].value.payload == "third")
        var other = acceptedSecond; other.revision = 3; other.operation = "other-phone"; other.payload = "other edit"
        ledger.receive(id: sent.id, remote: other)
        precondition(ledger.conflicts.count == 1 && ledger.pending.isEmpty)
        precondition(ledger.records[sent.id]?.value.payload == "third")
        ledger.resolve(id: sent.id, keepLocal: true)
        precondition(ledger.pending[0].baseRevision == 3 && ledger.pending[0].value.payload == "third")
        var newer = other; newer.revision = 4; newer.operation = "another-edit"; newer.deleted = true
        ledger.receive(id: sent.id, remote: newer)
        ledger.resolve(id: sent.id, keepLocal: false)
        precondition(ledger.pending.isEmpty && ledger.records[sent.id]?.value.deleted == true)
        // Deleted IDs remain as tombstones; stale remote data cannot resurrect them.
        ledger.receive(id: sent.id, remote: accepted)
        precondition(ledger.records[sent.id]?.value.deleted == true)
        ledger.stage(id: "pumping_B", payload: "pump", author: "Caregiver")
        let restored = try JSONDecoder().decode(FamilySyncLedger.self, from: JSONEncoder().encode(ledger))
        precondition(restored.pending.count == 1 && restored.records.count == 2)
        var independent = FamilySyncLedger()
        independent.stage(id: "feeding_A", payload: "local", author: "A")
        independent.receive(id: "feeding_B", remote: accepted)
        precondition(independent.records.count == 2 && independent.conflicts.isEmpty && independent.pending.count == 1)
        print("Family sync ledger tests passed: acknowledgement, concurrent edits, conflict choices, tombstones, independent records, durable outbox")
    }
}
