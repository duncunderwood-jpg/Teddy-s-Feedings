# Teddy’s Feedings 1.4

Original 2.2-second synthesized baby-rattle notification sound, bundled as mono 16-bit PCM WAV. Reminder sounds continue to respect the app toggle, notification permissions, Silent Mode and Focus.

Tapping a feeding reminder or test notification opens the app to “It’s feeding time for Teddy 🧸” with Log feeding and Not now buttons. The callback retains the request during cold launch. Opening the app normally does not show this message. Log feeding opens a blank editor and does not save anything automatically.

Existing pending reminders adopt the new sound and message on launch while preserving their next due date. Sound Preview and the five-second test notification are in Settings. Real notification sound and tap behavior require on-device testing.

Reminder message reads the latest saved feeding at opening, with date/time, formula amount, breast-milk amount (including zero), total, and the selected oz/mL unit. Suggestion follows hunger cues, without prescribing volume. Handles empty history and ignores future entries.

Age-based total bottle guide uses the stored birth date: first two calendar days about 0.5 oz; rest of first month 1–2 oz; one completed month 3–4 oz; two completed months 4–5 oz; 3–11 months 6–8 oz. Educational ranges from AAP/Nemours, not personalized targets. Months use calendar arithmetic; missing/future DOB requests correction; age >=12 months requests clinician plan. No formula/breast-milk split recommendation or automatic volume entry. Units honor preference. Source links and limitations appear in Settings.
