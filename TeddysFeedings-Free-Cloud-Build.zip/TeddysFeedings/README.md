**Free native iOS install:** See `FREE-WINDOWS-INSTALL.md` and use the `ios-free-ipa` workflow.

# Teddy's Feedings — native iOS v1.1 🧸

**START HERE:** [INSTALL-WINDOWS-AND-IPHONE.md](INSTALL-WINDOWS-AND-IPHONE.md). Includes a cloud Mac build path that does not require owning a Mac. A real iPhone install still requires Apple's build/signing process. This project is updated to include volume units on the seven-day chart, configurable sound, native notification banners/Lock Screen alerts and a five-second test notification. The original version 1 guide is retained below for deeper details.

---

# 🧸 Teddy’s Feedings — iPhone App Project

A private, teddy-bear-themed feeding log made for Theodore ("Teddy"). Built in **SwiftUI** with **Apple App Intents / Siri Shortcuts**, **Swift Charts**, and **local iPhone notifications**. No external accounts, server, subscriptions, or third-party packages.

## What is included

- **Home**: time since last feed, last feeding time, today's total milk and feeding count, formula and expressed milk breakdown, reminders, and quick-start buttons.
- **Log**: formula and expressed breast milk in one entry, time/date editing, notes, volumes in oz or mL, editable historical entries.
- **History**: today / seven days / all time, feeding intervals, edit, delete with confirmation, time-stamped logs.
- **Insights**: seven-day stacked milk intake chart and total / average intervals.
- **Reminders**: configurable 90/120/150/180/210/240-minute local notifications, automatically rescheduled after a log. Starts *off* and requests permission if enabled. These are check-ins, not fixed medical schedules.
- **Siri**: log via phrase + spoken details, dedicated formula and breast-milk shortcut actions.
- **Export**: CSV for pediatrician visits or safekeeping.
- **Privacy**: device-only local storage in UserDefaults, no networking or external analytics. Back up CSV before changing phones or deleting the app.

## Install on an iPhone — one-time setup

**Requirements:** a Mac with Xcode 16 or later, an iPhone with iOS 17 or later, a Lightning/USB-C connection or paired Wi‑Fi device, and an Apple ID for local development signing. An Apple Developer paid account is **not** required just to run on your own supported iPhone with Xcode's personal team (Apple provisioning restrictions apply). We haven't compiled or signed an `.ipa` in this environment because Xcode and Apple's signing tools are only available on a Mac.

1. Unzip `TeddysFeedings-iOS-Project.zip` on your **Mac**.
2. Double-click `TeddysFeedings.xcodeproj` to open in Xcode.
3. In Xcode, select the **TeddysFeedings** project and the **TeddysFeedings** target, then open **Signing & Capabilities**. Select your Apple team (add your Apple ID in Xcode Settings → Accounts if necessary).
4. Change **Bundle Identifier** to a unique reverse-domain string if Xcode requests it, such as `com.yourfamily.teddysfeedings`.
5. Connect and trust your iPhone, choose it at the top of Xcode, and tap **Run (▶)**. Follow iPhone prompts for **Developer Mode** or trusting the developer if shown.
6. Launch **Teddy's Feedings** on the phone. You can adjust units and check-in intervals under **Settings**.

To distribute an app to relatives or through the App Store, you would need an Apple Developer Program membership, properly signed distribution builds, and/or TestFlight. This zip contains the **full editable app source project**, **not** a pre-signed, directly installable `.ipa`.

## Siri guide

The app registers these *App Shortcuts* after installation:

- **Log Teddy's Feeding** (mixed formula and breast milk, optional spoken time).
- **Log Teddy Formula** (specified formula ounces and optional time).
- **Log Teddy Breast Milk** (specified breast-milk ounces and optional time).

A reliably structured workflow is:

1. Say **“Hey Siri, log Teddy's feeding in Teddy's Feedings.”**
2. When prompted, say **“I fed Teddy 3 ounces of formula and 1 ounce of breast milk at 8:15 PM.”**
3. Siri reports that the feeding was saved, and the entry is in the app history.

The app's parser understands:

- “3 oz formula and 1 oz breast milk at 8 PM”
- “formula 2 ounces and breast milk 35 ml at 7:30 am”
- “75 mL of breast milk” (logs now)
- “2 ounces of formula yesterday at 9 PM”

**Important Siri limitation:** Apple's ability to interpret the entire command directly as *one utterance*, for example “Hey Siri, I fed Teddy 3 ounces of formula and 1 ounce of breast milk at 8 PM”, varies with Siri, iOS, and your Shortcuts configuration. No independent third-party app can guarantee that exact free-form phrase will always invoke its intent. The **invocation followed by spoken details** is the supported approach. You can also configure your own named shortcut in Apple's Shortcuts app (for example, **Teddy Feeding**) and add **Log Teddy's Feeding** as its action.

The app's spoken parser needs a separate amount for each milk type in a mixed bottle. “3 oz formula and breast milk” is not auto-split, to avoid creating inaccurate records. Omitting a time uses now. Spoken times are resolved in your device's current timezone, using the most recent matching past time if the date is omitted.

## Feeding reference (information, not a prescription)

- [CDC formula feeding: how much and how often](https://www.cdc.gov/infant-toddler-nutrition/formula-feeding/how-much-and-how-often.html)
- [CDC breastfeeding: how much and how often](https://www.cdc.gov/infant-toddler-nutrition/breastfeeding/how-much-and-how-often.html)
- [AAP (HealthyChildren): amount and schedule of formula feedings](https://www.healthychildren.org/English/ages-stages/baby/formula-feeding/Pages/amount-and-schedule-of-formula-feedings.aspx)

Formula-fed newborns may take **1–2 oz every 2–3 hours** in the first days; breastfed newborns often feed **8–12 times in 24 hours**; most formula-fed babies gradually space feeds out in the first months. The app deliberately has **no hard daily minimum, maximum, or feeding requirement**: Teddy's hunger/fullness cues and individualized pediatric guidance matter more than automated averages or reminders. Especially for young or medically vulnerable newborns, follow a pediatrician-specific feeding plan.

## Technical notes and QA

- App target: Swift 5 / iOS 17+ / SwiftUI / App Intents / Charts / UserNotifications.
- Milk quantities are stored internally in mL as `Double`; UI conversion uses `29.5735295625 mL` per US fl oz. Changing display units leaves history intact.
- Data is stored on-device under `teddy.feedings.v1`; a separate key stores settings.
- Two Siri actions can log a single milk type. The free-speech action saves both milk components as one feeding.
- Local reminder notifications only work after explicit permission; no reminder means no scheduled alert. iOS may delay notification delivery.
- The parser's Foundation-only tests can run with:
  `swiftc TeddysFeedings/Models.swift TeddysFeedings/SpokenFeedingParser.swift Tests/ParserSmokeTests.swift -o /tmp/teddy-tests && /tmp/teddy-tests`
- Parser tests were run successfully and the Xcode project file syntax was validated, but a full **iOS build / simulator and physical-device Siri test has not been performed** without macOS/Xcode; resolve any platform-specific build issues in Xcode before distributing.
- Source is fully editable. No data sharing/cloud backup or multiple caregivers live sync is included in this version.

Designed with care for Teddy. 🧸
