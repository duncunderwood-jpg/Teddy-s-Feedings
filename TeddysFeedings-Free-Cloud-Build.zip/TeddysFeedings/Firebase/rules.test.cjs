const { initializeTestEnvironment, assertSucceeds, assertFails } = require('@firebase/rules-unit-testing');
const { doc, getDoc, getDocs, collection, setDoc, updateDoc, deleteDoc, writeBatch, runTransaction, serverTimestamp, Timestamp } = require('firebase/firestore');
const fs = require('fs');
(async () => {
 const env = await initializeTestEnvironment({projectId:'demo-teddy-family',firestore:{rules:fs.readFileSync(__dirname+'/firestore.rules','utf8')}});
 try {
 const auth = (uid,email,verified=true) => env.authenticatedContext(uid,{email,email_verified:verified}).firestore();
 const owner = auth('owner','duncan@example.com'), wife = auth('partner','caregiver@example.com'), stranger = auth('outsider','stranger@example.com');
 const unverified = auth('unverified','caregiver@example.com',false), anon=env.unauthenticatedContext().firestore();
 const family='family-one', code='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
 const member=(db,uid)=>doc(db,`families/${family}/members/${uid}`);
 const familyRef=db=>doc(db,`families/${family}`);
 const recordID='feeding_11111111-1111-4111-8111-111111111111';
 const record=db=>doc(db,`families/${family}/records/${recordID}`);
 const value=(uid,revision=1)=>({payload:'{}',deleted:false,revision,operation:'11111111-1111-4111-8111-111111111111',author:'Caregiver',updatedBy:uid,updatedAt:serverTimestamp()});
 const createFamily = async () => runTransaction(owner, async tx => {
   const pointer=await tx.get(doc(owner,'users/owner'));
   if(pointer.exists())return pointer.data().familyID;
   tx.set(familyRef(owner),{ownerUID:'owner',createdAt:serverTimestamp()});
   tx.set(member(owner,'owner'),{name:'Duncan',invite:'owner'});
   tx.set(doc(owner,'users/owner'),{familyID:family});return family;
 });
 await assertSucceeds(createFamily());
 if(await createFamily()!==family)throw Error('Existing family was replaced');
 await assertSucceeds(setDoc(record(owner),value('owner')));
 await assertFails(getDoc(record(anon))); await assertFails(getDoc(record(stranger))); await assertFails(getDoc(record(unverified)));
 await assertFails(getDocs(collection(owner,'families')));
 await assertFails(getDoc(doc(stranger,'users/owner')));
 await assertFails(setDoc(member(stranger,'outsider'),{name:'Bad',invite:'owner'}));
 const invitation={familyID:family,ownerUID:'owner',email:'caregiver@example.com',expiresAt:Timestamp.fromMillis(Date.now()+3600000),usedBy:''};
 await assertSucceeds(setDoc(doc(owner,`invitations/${code}`),invitation));
 await assertFails(getDoc(doc(stranger,`invitations/${code}`)));
 await assertFails(getDoc(doc(unverified,`invitations/${code}`)));
 await assertSucceeds(getDoc(doc(wife,`invitations/${code}`)));
 await assertFails(updateDoc(doc(wife,`invitations/${code}`),{usedBy:'partner'})); // must atomically create membership
 await assertSucceeds(runTransaction(wife,async tx=>{
   await tx.get(doc(wife,'users/partner'));
   await tx.get(doc(wife,`invitations/${code}`));
   tx.update(doc(wife,`invitations/${code}`),{usedBy:'partner'});
   tx.set(member(wife,'partner'),{name:'Caregiver',invite:code});
   tx.set(doc(wife,'users/partner'),{familyID:family});
 }));
 await assertSucceeds(getDoc(record(wife))); await assertSucceeds(getDocs(collection(wife,`families/${family}/records`)));
 await assertSucceeds(updateDoc(record(wife),value('partner',2)));
 await assertFails(updateDoc(record(owner),value('owner',2))); // stale revision
 await assertFails(updateDoc(record(wife),{revision:3,updatedBy:'owner',updatedAt:serverTimestamp()}));
 await assertFails(deleteDoc(record(wife)));
 await assertSucceeds(updateDoc(record(owner),{...value('owner',3),deleted:true}));
 await assertFails(deleteDoc(member(wife,'owner')));
 await assertFails(updateDoc(familyRef(wife),{ownerUID:'partner'}));
 await assertFails(setDoc(doc(stranger,'users/outsider'),{familyID:family}));
 await assertSucceeds(deleteDoc(member(owner,'partner')));
 await assertFails(getDoc(record(wife))); await assertFails(updateDoc(record(wife),value('partner',4)));
 // A consumed invitation cannot recreate revoked membership.
 await assertFails(setDoc(member(wife,'partner'),{name:'Again',invite:code}));
 const expired='bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb';
 await env.withSecurityRulesDisabled(async ctx=>setDoc(doc(ctx.firestore(),`invitations/${expired}`),{...invitation,expiresAt:Timestamp.fromMillis(Date.now()-1000)}));
 const expiredJoin=writeBatch(wife); expiredJoin.update(doc(wife,`invitations/${expired}`),{usedBy:'partner'}); expiredJoin.set(member(wife,'partner'),{name:'Expired',invite:expired});
 await assertFails(expiredJoin.commit());
 console.log('PASS: family bootstrap, verified email-bound atomic join, isolation, revision checks, tombstones, owner controls, revocation, replay protection, expiration.');
 } finally { await env.cleanup(); }
})().catch(e=>{console.error(e);process.exitCode=1});
