# Teddy’s Feedings — Family sharing

Prepared for Firebase project `teddys-feedings`, iOS bundle `com.teddyfamily.teddysfeedings`.
Uses Email/Password Authentication and the default Cloud Firestore database. No Cloud Functions, Storage, Messaging, paid Apple entitlements, or Firebase billing upgrade is required by this implementation. Firebase free quotas still apply.

## One-time Firebase step

In Firebase Console → Teddy’s Feedings → Firestore Database → Rules, replace the existing rules with the complete contents of `firestore.rules`, then Publish. These are family-scoped rules, not public test rules. Email/Password sign-in must already be enabled. Do not enable App Check enforcement until its compatibility with your sideloaded build has been configured and tested.

Alternatively, with an authorized Firebase CLI session, from this Firebase directory:
`firebase deploy --only firestore:rules --project teddys-feedings`

## First phone

Install the newly built IPA over the existing app using the same Apple ID/signing identity and bundle identifier. Do not delete the app first: legacy entries are on the phone.
Open Settings → Family sharing → Create a new account. Enter your display name, email and password. Open the verification email, then Check verification.
Choose Create shared family. This explicitly copies this phone’s current feeding/pumping records into the private shared family, preserving record UUIDs. Its local-only journal remains intact separately.
Use Invite caregiver and enter the other caregiver’s email. Share the generated code yourself. It expires after 48 hours and can be used once. The recipient must use and verify that exact email address.

## Second phone

Install the same build. Create an account using the invited email, verify it, paste the invitation code, and choose Join family. The shared journal opens. Existing local-only records on that phone are kept separately; they are not silently uploaded or merged. Signing out returns to that phone’s local-only journal.

## Daily use

Feedings, pumping, baby nickname, birthdate, and clinician-entered bottle target are shared. Volume units and reminder preferences stay local to each phone. A remote feeding updates each phone’s local reminder schedule when it is received; this is not remote push notification delivery.
The app listens for shared changes while running. Pull to refresh on Home, History, Insights, or Pumping forces a server read. Last refreshed records a successful server refresh, not a local cache read. Pending entries and errors are visible.
Offline saves are durable in a family-specific local outbox. Retry occurs when opening/foregrounding the app, pulling to refresh, saving an entry, or every 30 seconds while the app is running. iOS suspension can delay uploads; keep the app open to complete a refresh. Siri attempts an upload after saving, but an offline/Siri-terminated request may stay pending until the app is opened.
Different record IDs merge. Simultaneous edits/deletes to the same ID produce a conflict with both versions retained locally. In Family sharing choose Keep shared version or Use this phone’s version. A stale open editor cannot overwrite a newly received version. Deletions use tombstones, so stale offline copies do not resurrect records silently.
Owner can remove caregivers or revoke the current invitation. Previously downloaded data cannot be erased remotely. Local pending/conflicted changes must be handled before sign-out; caches are separated by family and retained on the device.

## Validation status

Passed local Firestore Emulator tests: initial owner bootstrap; verified email-bound atomic invitation claim; unauthorized, anonymous, and unverified access denial; no public family/invitation listing; revision enforcement; deletion tombstones; owner-only removal; revoked access; used/expired invitation rejection.
All Swift files parsed with a syntax parser (DEBUG directives normalized for one existing parser limitation); package/config/YAML/shell/archive checks passed. This does not replace Xcode compilation.
Codemagic build #11 succeeded: native iPhone compilation, parser tests, family-sync ledger tests, packaging, and lullaby checks passed. Initial simulator screenshots did not show the intended tabs; a DEBUG-only review correction is queued in build #12. Real-device Siri and two-device end-to-end sync still need checking after installation and rule publication. No production Firebase data was written during emulator testing.

Before relying on sharing, test one feeding from each phone, one pumping session, pull refresh both ways, an offline entry followed by reconnection, and one simultaneous edit to check the conflict screen. Confirm the resulting totals agree on both phones.

## Version 1.7 validation
Codemagic build #14 produced version 1.7 (build 11). Parser, family-ledger and feeding-analytics executables passed. iPhone and simulator compilation passed; the six main screens were captured after readiness checks and reviewed. Firebase configuration and family rules are unchanged. Feedback opens a native Mail or default email-app draft; the user must send it. Real-device email delivery, Siri recognition and two-phone end-to-end sync have not been exercised by this cloud build.
