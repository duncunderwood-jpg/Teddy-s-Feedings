# 🧸 Install the native Teddy's Feedings iOS app — Windows PC + iPhone

This is a **real iOS app source project**, not a Home Screen website. Siri and notification permissions run through Apple's native frameworks.

## What is ready now

- SwiftUI Home, Feeding Log, History, Insights, Settings.
- Recording of formula, expressed breast milk, or both; timestamps and intervals.
- Seven-day chart showing e.g. **3.5 oz** or **104 mL** above each day's stacked bar and units on the Y axis.
- Siri actions via Apple App Intents and the Shortcuts app.
- Native `UNUserNotificationCenter` feeding check-in after the latest saved feeding, with iOS Lock Screen / banner delivery and sound if enabled. Works with the app closed once the app is installed and notification permission is granted; iPhone's Focus and notification preferences still apply.
- A **Send test notification** button schedules a local alert 5 seconds in the future.
- Existing version 1 native settings are automatically migrated. **Records stored in the previous web app are not automatically imported** into this native app.
- `codemagic.yaml` with **unsigned build check** and **signed TestFlight** workflows.

## The important installation limitation

You cannot open a Swift/Xcode source ZIP and install it directly as a native app from Safari. Apple requires the app to be **compiled on macOS and signed** before it can be installed on a physical iPhone. You **do not have to own a Mac**; a cloud Mac build service such as Codemagic can compile it for you.

To distribute via **TestFlight**, you need an **Apple Developer Program membership ($99/year in the U.S.)** and matching Apple distribution signing credentials. The cloud builder might charge separately. The app itself has no subscription or backend. TestFlight beta builds have an expiration period; for durable availability, publish a production App Store release (private/unlisted distribution still follows Apple's review requirements).

## Setup from a Windows PC

1. Unzip this folder. Create your own private GitHub repository. Upload everything INSIDE `TeddysFeedings` so `codemagic.yaml` and `TeddysFeedings.xcodeproj` are at the repository root.
2. Create an account at https://codemagic.io and connect that repository.
3. Select workflow **Verify Teddy's Feedings (unsigned)**. This verifies the iOS project compiles in a real cloud Mac/Xcode environment, without needing a paid Apple Developer account. The unsigned `.app` **cannot be installed on an iPhone**; it is a build-validation artifact only.
4. Enroll in the Apple Developer Program: https://developer.apple.com/programs/enroll/ (only necessary for distribution and TestFlight).
5. Choose a unique bundle identifier you control; the placeholder `com.teddyfamily.teddysfeedings` is used in this project, in the Xcode build configuration AND `codemagic.yaml` and must match the App Store Connect app record and signing profile. Replace it consistently if Apple reports it unavailable.
6. In App Store Connect, create the app record and a dedicated App Store Connect API key. Follow Codemagic's own setup: https://docs.codemagic.io/yaml-code-signing/signing-ios/ . **Do not share private API keys/passwords in chat or commit them to GitHub.**
7. In Codemagic, save the App Store Connect API key as a Developer Portal integration, set up an Apple Distribution certificate and App Store provisioning profile (Codemagic can help create/fetch them), and change `YOUR_APP_STORE_CONNECT_INTEGRATION_NAME` in `codemagic.yaml` to your integration's name.
8. Select **Build and publish Teddy's Feedings to TestFlight**. After successful processing in App Store Connect, add yourself as a tester and open the invitation in the **TestFlight** app on your iPhone.
9. On Teddy's Feedings → **Settings**, enable reminders, enable sound, choose a check-in interval and tap **Send test notification**. In iPhone Settings → Notifications → Teddy's Feedings, allow **Banners**, **Lock Screen**, and **Sounds**. If Focus or Silent Mode restricts audible alerts, adjust those as desired.
10. In Apple's **Shortcuts** app, find **Log Teddy's Feeding** and try Siri with “Hey Siri, log Teddy's feeding in Teddy's Feedings.” Answer, for example: “3 ounces of formula and 1 ounce of breast milk at 8:15 PM.” You can also invoke “Hey Siri, I fed Teddy in Teddy's Feedings” and then answer the prompt.

**Important:** The single-utterance phrase “Hey Siri, I fed Teddy 3 ounces of formula and 1 ounce of breast milk at 8:15 PM” may or may not be recognized directly by Siri. Native App Intents make voice logging possible, but Apple's Siri controls phrase matching. The documented and more reliable flow is shortcut invocation followed by a volume/time prompt.

## Quality / what hasn't been verified

- The model and parser compile on Swift/Linux and parser regression tests pass.
- Swift files pass syntax parsing; Xcode project property-list structure is validated.
- **The full iOS compile, signed IPA, TestFlight submission, notification delivery, and Siri interaction still need to be verified on a macOS Xcode builder and actual iPhone.** These cannot be tested from this environment.
- If a cloud build surfaces SDK-specific errors, fix them before attempting TestFlight publication.

## Privacy and feeding guidance

Records are stored locally on the iPhone; the app does not send them to a server or synchronize with caregivers. Export a CSV backup before uninstalling. Reminder intervals are optional check-ins, **not** instructions to feed on a rigid clock. Follow Teddy's hunger/fullness cues and individualized pediatric guidance.

Relevant references:
- https://developer.apple.com/documentation/appintents
- https://developer.apple.com/documentation/usernotifications
- https://docs.codemagic.io/yaml-quick-start/first-signed-build/
