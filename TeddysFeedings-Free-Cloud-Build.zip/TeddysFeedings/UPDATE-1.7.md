# Teddy’s Feedings 1.7
- Bottle and pump illustrated logging buttons, distinct formula/breast-milk icons, blush/rose pumping journal, high-contrast next-bottle panel and prominent top-off button.
- Six visible navigation destinations, with Feeding Guide immediately before Settings.
- Upper-right feedback sheet opens a user-reviewed email to duncunderwood@gmail.com using native Mail or mailto with share fallback; no automatic email or records attached.
- History clipboard opens copy/share summary; formula/breast-milk volumes and percentages, complete bottle-type counts and midnight-aware totals.
- 7/30/90-day and all-time insights: stacked volume, milk-mix donut, 7-day rolling average, feeding frequency, hourly starts, comparisons and expanded statistics. Missing days are explicitly treated as zero logged volume, not confirmed absence of feeding.
- Settings has a real Add caregiver button and accurate cloud/local storage copy. Text buttons use obvious indigo/rose action colors.
- Existing data and Firebase family rules retained. New analytics executable tests cover midnight top-offs, future exclusion, counts, averaging, rolling trends, comparison windows, empty/all-time data, buckets and DST. Codemagic build #14 passed (version 1.7, build 11): speech parsing, sync-conflict handling, feeding analytics, native iPhone compilation, packaging, and simulator screen-readiness checks. Reviewed Home, History, Insights, Pumping, Feeding Guide and Settings screenshots; corrected feedback/header overlap. Real-device email delivery and two-phone sync still require an on-device check.
