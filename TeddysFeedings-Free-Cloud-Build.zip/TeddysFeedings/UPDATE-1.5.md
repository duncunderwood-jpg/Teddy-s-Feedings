# Teddy’s Feedings 1.5
- Optional offered formula and breast milk are stored separately from milk actually drank; totals always use consumed amounts.
- User-entered clinician target range takes priority over age guidance. Never auto-fills a medical target.
- Recent usual bottle is the median of up to ten sessions in the last seven days, shown only after three sessions and labeled as history.
- Top-ups merge into the same session while preserving original start time, notes, and ID; reminder uses latest milk time.
- Missing/deleted original feeding prevents saving an orphaned edit or top-up and retains the open form.
- Exports include offered amounts and latest top-up time; old records and settings migrate without losing data.
- Targeted simulator review replaces repeating every screen in both appearances. Tests and iPhone compile remain mandatory.
