# Install Teddy's Feedings at no charge (Windows + iPhone)

This project can be built using **a free Codemagic cloud Mac**, with **no Apple Developer Program membership**. The output of the included `ios-free-ipa` workflow is an **unsigned** `.ipa`, which Sideloadly can sign and install using a regular, free Apple Account on your own iPhone.

**Important:** This is a testing / personal-use method, not TestFlight or an App Store release. It cannot be guaranteed to support all app entitlements (especially Siri/App Intents) under Apple's free personal provisioning. Local scheduled notifications should be tested on device. Neither the cloud build nor the Siri/notification features have been verified on a physical iPhone yet.

## 1. Build the iOS IPA for free

1. On your Windows PC, extract this ZIP.
2. Create a **private** repository in GitHub. Upload everything **inside** the `TeddysFeedings` folder (not the enclosing folder) so `codemagic.yaml` and `TeddysFeedings.xcodeproj` are at the root.
3. Create a free **personal** account at https://codemagic.io and connect your GitHub repo.
4. Choose workflow **FREE - Build iPhone IPA (unsigned, for Sideloadly)** (`ios-free-ipa`). Select the free `mac_mini_m2` machine. **Do not select the paid TestFlight workflow.**
5. Run the build. If compilation succeeds, download the `Teddy-Feedings-unsigned.ipa` artifact from your Codemagic build page. Keep the file; this is not yet signed by Apple.

Codemagic's free individual plan currently includes **500 macOS M2 build minutes per month**, resetting monthly. Review the account's free minutes and billing settings before enabling any paid options.

## 2. Sign and install using Windows

1. Get Sideloadly from https://sideloadly.io/ and follow its current Windows prerequisites (Apple iTunes/iCloud web installers may be required).
2. Connect your iPhone over USB, unlock it, tap **Trust**, and turn on **Developer Mode** under Settings > Privacy & Security if prompted. Restart if requested.
3. In Sideloadly, select your iPhone, choose the downloaded `Teddy-Feedings-unsigned.ipa`, and sign using a **free Apple Account** you control. Consider creating a separate Apple Account for development rather than using a primary one; never share login credentials in a chat or with an unknown site.
4. Complete installation and follow iOS instructions to trust your personal developer profile, if prompted.
5. Launch Teddy's Feedings and enable notifications. In Settings > Notifications > Teddy's Feedings, permit Lock Screen, Banners and Sounds. Use **Send test notification** in the app to confirm alerts. Check the Shortcuts app for Teddy's feeding actions and test them with Siri.

## Restrictions that matter

- **Seven-day signing limit:** With a free Apple account, apps generally stop opening after seven days unless re-signed/refreshed. Keep Sideloadly's automatic refresh configured with the PC reachable, or manually reinstall with the same Apple Account and bundle ID before expiry. Back up any important feeding data separately.
- **Three-app limit:** Free Apple provisioning usually allows three sideloaded apps on one iPhone at once.
- **Siri:** The App Intents code is included, but free provisioning and sideloading may restrict entitlements or recognition. *Do not rely on hands-free Siri logging until it has been demonstrated on your phone.*
- **Reminders:** Local iOS notifications do not require push notifications or a server; iPhone notification permissions, Focus, and sound settings still control display and audibility. Validate on device.
- **No TestFlight or App Store:** Apple Developer Program membership is required to distribute that way. This route is for the owner's device only.
- **Privacy:** Feeding data is saved locally. The source code is uploaded to the build service, but not your feeding log. Keep repository private. Avoid uploading credentials or personal records.

## If build fails

Read the Codemagic Xcode build log and fix the exact Swift/Xcode errors. A packaged `.ipa` does not prove the program or Siri shortcuts work until tested on an iPhone. Cloud builder uses latest Xcode and the target is iOS 17+.

Sources: https://docs.codemagic.io/billing/pricing/ · https://docs.codemagic.io/yaml-basic-configuration/yaml-getting-started/ · https://sideloadly.io/faq.html · https://developer.apple.com/help/account/membership/program-enrollment
