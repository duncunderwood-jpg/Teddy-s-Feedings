import SwiftUI
import Charts

struct DailyMilk: Identifiable {
    var id: Date { date }
    let date: Date
    var formulaML: Double
    var breastML: Double
    var count: Int
    var totalML: Double { formulaML + breastML }
}

struct InsightsView: View {
    @EnvironmentObject private var store: FeedingStore
    private var days: [DailyMilk] {
        let calendar = Calendar.current
        return (0..<7).reversed().compactMap { offset -> DailyMilk? in
            guard let date = calendar.date(byAdding: .day, value: -offset, to: calendar.startOfDay(for: .now)) else { return nil }
            let feeds = store.feedings.filter { let milk = $0.milk(on: date, calendar: calendar); return milk.formula + milk.breast > 0 }
            return DailyMilk(date: date,
                             formulaML: feeds.reduce(0) { $0 + $1.milk(on: date, calendar: calendar).formula },
                             breastML: feeds.reduce(0) { $0 + $1.milk(on: date, calendar: calendar).breast }, count: feeds.count)
        }
    }
    private var weekFeeds: [Feeding] {
        store.feedings.filter { $0.lastMilkAt >= Calendar.current.date(byAdding: .day, value: -6, to: Calendar.current.startOfDay(for: .now))! && $0.time <= Date() }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Little milestones")
                            .font(.system(size: 27, weight: .heavy, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        Text("Your last seven days together")
                            .font(.system(size: 13, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                    }.padding(.top, 16)
                    TeddyCard {
                        Text("Daily milk volume")
                            .font(.system(size: 18, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        if weekFeeds.isEmpty {
                            TeddyEmptyState(title: "Little bottles, growing milestones", message: "Teddy’s milk totals will appear after his first feeding.")
                        } else {
                            Text("Amounts shown on bars in \(store.settings.unit.symbol)")
                                .font(.system(size: 11, design: .rounded))
                                .foregroundStyle(TeddyTheme.muted)
                            Chart {
                                ForEach(days) { day in
                                    BarMark(x: .value("Day", day.date, unit: .day),
                                            y: .value("Formula", store.settings.unit.fromMilliliters(day.formulaML)))
                                        .foregroundStyle(by: .value("Milk", "Formula"))
                                        .cornerRadius(4)
                                    BarMark(x: .value("Day", day.date, unit: .day),
                                            y: .value("Breast milk", store.settings.unit.fromMilliliters(day.breastML)))
                                        .foregroundStyle(by: .value("Milk", "Breast milk"))
                                        .cornerRadius(4)
                                    if day.totalML > 0 {
                                        PointMark(x: .value("Day", day.date, unit: .day),
                                                  y: .value("Total", store.settings.unit.fromMilliliters(day.totalML)))
                                            .opacity(0)
                                            .annotation(position: .top, spacing: 3) {
                                                Text(store.settings.unit.display(day.totalML))
                                                    .font(.system(size: 10, weight: .bold, design: .rounded))
                                                    .foregroundStyle(TeddyTheme.cocoa)
                                                    .fixedSize()
                                            }
                                    }
                                }
                            }
                            .chartForegroundStyleScale(["Formula": TeddyTheme.honey, "Breast milk": TeddyTheme.sage])
                            .chartYAxis {
                                AxisMarks(position: .leading) { mark in
                                    AxisGridLine()
                                    AxisTick()
                                    AxisValueLabel {
                                        if let value = mark.as(Double.self) {
                                            let digits = store.settings.unit == .ounces ? 1 : 0
                                            Text("\(value.formatted(.number.precision(.fractionLength(0...digits)))) \(store.settings.unit.symbol)")
                                                .font(.system(size: 10))
                                        }
                                    }
                                }
                            }
                            .chartXAxis {
                                AxisMarks(values: .stride(by: .day)) { _ in
                                    AxisValueLabel(format: .dateTime.weekday(.narrow))
                                }
                            }
                            .frame(height: 230)
                            .accessibilityLabel("Last seven days of feeding. Volume labels are shown in \(store.settings.unit.symbol).")
                        }
                    }
                    TeddyCard {
                        Text("7-day summary")
                            .font(.system(size: 18, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        Divider()
                        summaryRow("Logged feedings", "\(weekFeeds.count)")
                        summaryRow("Total milk", store.settings.unit.display(days.reduce(0) { $0 + $1.totalML }))
                        summaryRow("Formula", store.settings.unit.display(days.reduce(0) { $0 + $1.formulaML }))
                        summaryRow("Expressed breast milk", store.settings.unit.display(days.reduce(0) { $0 + $1.breastML }))
                        summaryRow("Average time between feedings", FeedingMath.averageGap(weekFeeds).map(FeedingMath.intervalText) ?? "—")
                    }
                    TeddyCard {
                        Label("What these numbers mean", systemImage: "heart.text.square")
                            .font(.system(size: 16, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        Text("These are historical patterns, not feeding goals. A growth spurt or cluster feeding can change when Teddy is hungry. Keep following his cues and your pediatrician's care plan.")
                            .font(.system(size: 13, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                    }
                }.padding(.horizontal, 18).padding(.bottom, 18)
            }
            .scrollBounceBehavior(.always)
            .refreshable { store.reload() }
            .background(TeddyTheme.cream.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
        }
    }
    private func summaryRow(_ label: String, _ value: String) -> some View {
        HStack {
            Text(label).font(.system(size: 13, design: .rounded)).foregroundStyle(TeddyTheme.muted)
            Spacer(minLength: 5)
            Text(value).font(.system(size: 13, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
        }
    }
}
