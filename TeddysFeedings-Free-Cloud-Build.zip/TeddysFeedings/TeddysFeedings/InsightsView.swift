import SwiftUI
import Charts

struct InsightsView: View {
    @EnvironmentObject private var store: FeedingStore
    @SceneStorage("teddy.insights.period") private var period = 0
    private var analytics: FeedingAnalytics { FeedingAnalytics(store.feedings, dayCount: [7, 30, 90, nil][period]) }
    private var title: String { ["7-day", "30-day", "90-day", "All-time"][period] }
    private var unit: VolumeUnit { store.settings.unit }
    private var buckets: [MilkDay] { analytics.chartBuckets() }
    private var scale: Double { max(1, unit.fromMilliliters(buckets.map(\.totalML).max() ?? 0) * 1.28) }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Teddy’s growing story").font(.system(size: 27, weight: .heavy, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                    Text("Small moments, a clearer long-term picture").font(.subheadline).foregroundStyle(TeddyTheme.muted)
                    TeddySegmentedPicker(label: "Insight period", selection: $period, options: [("7 days", 0), ("30 days", 1), ("90 days", 2), ("All time", 3)])
                    totalsCard
                    if analytics.count == 0 {
                        TeddyEmptyState(title: "His story starts with a bottle", message: "Log a feeding to see milk mix, trends, and daily rhythms.")
                    } else {
                        volumeChart
                        mixChart
                        trendChart
                        frequencyChart
                        hourlyChart
                        detailCard
                    }
                    TeddyCard {
                        Label("A little perspective", systemImage: "heart.fill").font(.headline)
                        Text("These charts show what was logged, not how much Teddy should eat. Blank days may mean missing logs. Daily averages include every calendar day in the selected range, including today’s partial day. Follow his cues and pediatrician’s plan.").font(.caption).foregroundStyle(TeddyTheme.muted)
                    }
                }.padding(18)
            }.scrollBounceBehavior(.always).refreshable { await store.refreshShared() }
                .background(TeddyTheme.cream.ignoresSafeArea()).toolbar(.hidden, for: .navigationBar)
        }
    }
    private var totalsCard: some View {
        let a = analytics
        return TeddyCard {
            Text("\(title) snapshot").font(.system(.title3, design: .rounded, weight: .bold))
            stat("Total milk", unit.display(a.totalML))
            stat("Formula", "\(unit.display(a.formulaML)) · \(PumpingMath.percentage(a.formulaML, total: a.totalML))")
            stat("Breast milk", "\(unit.display(a.breastML)) · \(PumpingMath.percentage(a.breastML, total: a.totalML))")
            Divider()
            stat("Logged feedings", "\(a.count)")
            stat("Average milk per day", unit.display(a.averagePerDay))
            stat("Average milk per feeding in range", a.averageBottle.map(unit.display) ?? "—")
            stat("Days with logged milk", "\(a.activeDays) of \(a.days.count)")
            if period < 3 {
                stat("Volume vs previous \(a.days.count) days", a.changePercent.map { String(format: "%+.1f%%", $0) } ?? "No earlier volume")
                Text("Includes today so far; the previous period is complete. This comparison is not a growth assessment.").font(.caption2).foregroundStyle(TeddyTheme.muted)
            }
        }
    }
    private var volumeChart: some View {
        TeddyCard {
            Text(analytics.days.count > 180 ? "Milk volume by month" : analytics.days.count > 30 ? "Milk volume by week" : "Daily milk volume").font(.headline)
            Text("Formula and breast milk stacked together · \(unit.symbol)").font(.caption).foregroundStyle(TeddyTheme.muted)
            Chart {
                ForEach(buckets) { day in
                    BarMark(x: .value("Date", day.date), y: .value("Formula", unit.fromMilliliters(day.formulaML)))
                        .foregroundStyle(by: .value("Milk", "Formula"))
                        .annotation(position: .overlay) { barLabel(day.formulaML) }
                    BarMark(x: .value("Date", day.date), y: .value("Breast milk", unit.fromMilliliters(day.breastML)))
                        .foregroundStyle(by: .value("Milk", "Breast milk"))
                        .annotation(position: .overlay) { barLabel(day.breastML) }
                    if analytics.days.count <= 7 && day.totalML > 0 {
                        PointMark(x: .value("Date", day.date), y: .value("Total", unit.fromMilliliters(day.totalML))).opacity(0)
                            .annotation(position: .top, spacing: 4) {
                                Text(unit.display(day.totalML)).font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa).fixedSize()
                            }
                    }
                }
            }.chartForegroundStyleScale(["Formula": TeddyTheme.brown, "Breast milk": TeddyTheme.rose])
                .chartYScale(domain: 0...scale).chartYAxisLabel(unit.symbol)
                .chartXAxis { AxisMarks(values: .automatic(desiredCount: 5)) { value in AxisValueLabel(format: .dateTime.month(.abbreviated).day()) } }
                .frame(height: 230)
            if analytics.days.count > 30 { Text("The first and last buckets may be partial. Totals cover only the selected dates.").font(.caption2).foregroundStyle(TeddyTheme.muted) }
        }
    }
    @ViewBuilder private func barLabel(_ ml: Double) -> some View {
        if analytics.days.count <= 7 && ml > 0 {
            Text(unit.display(ml)).font(.system(size: 9, weight: .bold, design: .rounded)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.65)
        }
    }
    private var mixChart: some View {
        TeddyCard {
            Text("What’s in his bottles?").font(.headline)
            HStack(spacing: 20) {
                Chart {
                    if analytics.formulaML > 0 { SectorMark(angle: .value("Formula", analytics.formulaML), innerRadius: .ratio(0.62)).foregroundStyle(TeddyTheme.brown) }
                    if analytics.breastML > 0 { SectorMark(angle: .value("Breast milk", analytics.breastML), innerRadius: .ratio(0.62)).foregroundStyle(TeddyTheme.rose) }
                }.frame(width: 115, height: 115).accessibilityLabel("Milk volume proportions in the selected period")
                VStack(alignment: .leading, spacing: 12) {
                    mixLegend("Formula", analytics.formulaML, kind: .formula)
                    mixLegend("Breast milk", analytics.breastML, kind: .breast)
                }
            }
            Text("Volume share, including mixed bottles. Pumped milk is separate until logged as drunk.").font(.caption2).foregroundStyle(TeddyTheme.muted)
        }
    }
    private func mixLegend(_ text: String, _ amount: Double, kind: MilkIconKind) -> some View {
        HStack(spacing: 8) {
            MilkTypeIcon(kind: kind).frame(width: 21, height: 24)
            VStack(alignment: .leading) {
                Text(text).font(.caption)
                Text(PumpingMath.percentage(amount, total: analytics.totalML)).font(.headline)
                Text(unit.display(amount)).font(.caption).foregroundStyle(TeddyTheme.muted)
            }
        }
    }
    private var trendChart: some View {
        let a = analytics
        let stride = a.days.count > 180 ? 7 : 1
        let points = a.rolling.enumerated().filter { $0.offset.isMultiple(of: stride) || $0.offset == a.rolling.count - 1 }.map(\.element)
        return TeddyCard {
            Text("The bigger picture").font(.headline)
            Text("7-day rolling average of milk per day").font(.caption).foregroundStyle(TeddyTheme.muted)
            Chart(points) { point in
                AreaMark(x: .value("Date", point.date), y: .value("Daily average", unit.fromMilliliters(point.averageML))).foregroundStyle(TeddyTheme.paleSage)
                LineMark(x: .value("Date", point.date), y: .value("Daily average", unit.fromMilliliters(point.averageML))).foregroundStyle(TeddyTheme.accent).lineStyle(StrokeStyle(lineWidth: 3))
            }.chartYScale(domain: .automatic(includesZero: true)).chartYAxisLabel(unit.symbol).frame(height: 180)
            Text("Each point includes that day and the preceding six calendar days, including unlogged days as zero. Long histories sample this trend weekly. This is not a feeding target.").font(.caption2).foregroundStyle(TeddyTheme.muted)
        }
    }
    private var frequencyChart: some View {
        TeddyCard {
            Text("Bottle rhythm").font(.headline)
            Text(analytics.days.count > 30 ? "Feeding records per chart bucket" : "Feeding records per day").font(.caption).foregroundStyle(TeddyTheme.muted)
            Chart(buckets) { day in
                BarMark(x: .value("Date", day.date), y: .value("Feedings", day.count)).foregroundStyle(TeddyTheme.sage).cornerRadius(3)
            }.chartYAxisLabel("Feedings").frame(height: 160)
            Text("Each bucket counts a bottle once. A bottle with a top-off across two buckets appears in both; the period-wide count counts it once.").font(.caption2).foregroundStyle(TeddyTheme.muted)
        }
    }
    private var hourlyChart: some View {
        TeddyCard {
            Text("When bottle breaks happen").font(.headline)
            Text("Feeding starts by hour · this phone’s local time").font(.caption).foregroundStyle(TeddyTheme.muted)
            Chart(analytics.hourly) { hour in
                BarMark(x: .value("Hour", hour.hour), y: .value("Feedings", hour.count)).foregroundStyle(TeddyTheme.action).cornerRadius(2)
            }.chartXScale(domain: -0.5...23.5)
                .chartXAxis { AxisMarks(values: [0, 6, 12, 18, 23]) { value in
                    AxisValueLabel { if let hour = value.as(Int.self) { Text(hour == 0 ? "12a" : hour == 6 ? "6a" : hour == 12 ? "12p" : hour == 18 ? "6p" : "11p") } }
                } }.frame(height: 160)
        }
    }
    private var detailCard: some View {
        let a = analytics
        return TeddyCard {
            Text("A few more little details").font(.headline)
            stat("Average interval", a.averageGap.map(FeedingMath.intervalText) ?? "—")
            stat("Longest recorded interval", a.longestGap.map(FeedingMath.intervalText) ?? "—")
            stat("Largest logged bottle", a.largestBottle.map(unit.display) ?? "—")
            stat("Formula-only bottles", "\(a.formulaOnlyCount)")
            stat("Breast-milk-only bottles", "\(a.breastOnlyCount)")
            stat("Mixed bottles", "\(a.mixedCount)")
            if let peak = a.peak { stat("Highest logged milk day", "\(peak.date.shortFeedingDate) · \(unit.display(peak.totalML))") }
            Text("Intervals use feeding start times within this range. A long gap may be an unlogged bottle; it is not a recommendation to wait that long.").font(.caption2).foregroundStyle(TeddyTheme.muted)
        }
    }
    private func stat(_ label: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label).font(.subheadline).foregroundStyle(TeddyTheme.muted)
            Spacer(minLength: 12)
            Text(value).font(.system(.subheadline, design: .rounded, weight: .bold)).foregroundStyle(TeddyTheme.cocoa).multilineTextAlignment(.trailing)
        }
    }
}
