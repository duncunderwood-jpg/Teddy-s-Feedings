import Foundation
import Combine
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore

@MainActor
final class FamilySyncService: ObservableObject {
    static let shared = FamilySyncService()
    @Published private(set) var signedIn = false
    @Published private(set) var verified = false
    @Published private(set) var email = ""
    @Published private(set) var familyID: String?
    @Published private(set) var owner = false
    @Published private(set) var busy = false
    @Published private(set) var syncing = false
    @Published private(set) var pendingCount = 0
    @Published private(set) var conflicts: [FamilySyncRecord] = []
    @Published private(set) var lastSynced: Date?
    @Published private(set) var syncError: String?
    @Published var message: String?
    @Published private(set) var invitationCode: String?
    @Published private(set) var members: [FamilyMember] = []
    private var ledger = FamilySyncLedger()
    private var applying = false
    private var listener: ListenerRegistration?
    private var membershipListener: ListenerRegistration?
    private var authHandle: AuthStateDidChangeListenerHandle?
    private var uid: String?
    private var profileName = "Caregiver"
    private var retryTask: Task<Void, Never>?
    private let defaults = UserDefaults.standard
    nonisolated static var storagePrefix: String {
        guard let family = UserDefaults.standard.string(forKey: "teddy.activeFamily") else { return "teddy" }
        return "teddy.family.\(family)"
    }
    private var db: Firestore { Firestore.firestore() }
    private var ledgerKey: String { "teddy.sync.\(familyID ?? "none")" }

    private init() {
        // Also works when Siri launches an AppIntent before the application delegate.
        if FirebaseApp.app() == nil { FirebaseApp.configure() }
        let cachedUser = Auth.auth().currentUser
        uid = cachedUser?.uid; signedIn = cachedUser != nil
        verified = cachedUser?.isEmailVerified ?? false; email = cachedUser?.email ?? ""
        profileName = cachedUser?.displayName?.isEmpty == false ? cachedUser!.displayName! : "Caregiver"
        // Persisted namespace prevents a Siri save going to the wrong local journal on cold start.
        familyID = defaults.string(forKey: "teddy.activeFamily")
        loadLedger()
        authHandle = Auth.auth().addStateDidChangeListener { [weak self] _, user in
            Task { @MainActor in await self?.authenticationChanged(user) }
        }
    }
    private func authenticationChanged(_ user: User?) async {
        listener?.remove(); membershipListener?.remove(); retryTask?.cancel()
        uid = user?.uid; signedIn = user != nil; verified = user?.isEmailVerified ?? false; email = user?.email ?? ""
        guard let user else {
            // Auth can expire; retain the private family cache rather than mixing it with legacy data.
            owner = false; members = []; return
        }
        if let activeUser = defaults.string(forKey: "teddy.activeFamilyUser"), familyID != nil, activeUser != user.uid {
            try? Auth.auth().signOut()
            message = "Sign back in with the account previously connected on this phone to upload its pending records, then sign out from Family sharing before switching accounts."
            return
        }
        profileName = user.displayName?.isEmpty == false ? user.displayName! : "Caregiver"
        guard verified else { return }
        do {
            let pointer = try await db.collection("users").document(user.uid).getDocument(source: .server)
            guard uid == user.uid else { return }
            if let family = pointer.data()?["familyID"] as? String {
                try await activate(family)
            } else if familyID != nil {
                message = "This account has no family connected. Sign out before using another account on this phone."
            }
        } catch { message = friendly(error) }
    }
    func authenticate(email: String, password: String, name: String, create: Bool) async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do {
            let result: AuthDataResult
            if create {
                result = try await Auth.auth().createUser(withEmail: email.trimmingCharacters(in: .whitespacesAndNewlines), password: password)
                let change = result.user.createProfileChangeRequest()
                change.displayName = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(60))
                try await change.commitChanges()
                try await result.user.sendEmailVerification()
                message = "Check your email to verify your account, then tap Check verification."
            } else {
                result = try await Auth.auth().signIn(withEmail: email.trimmingCharacters(in: .whitespacesAndNewlines), password: password)
            }
            await authenticationChanged(result.user)
        } catch { message = friendly(error) }
    }
    func checkVerification() async {
        do {
            guard let user = Auth.auth().currentUser else { return }
            try await user.reload(); _ = try await user.getIDToken(forcingRefresh: true)
            await authenticationChanged(Auth.auth().currentUser)
            if !verified { message = "Open the verification link in your email first." }
        } catch { message = friendly(error) }
    }
    func resendVerification() async {
        do { try await Auth.auth().currentUser?.sendEmailVerification(); message = "Verification email sent." }
        catch { message = friendly(error) }
    }
    func resetPassword(_ email: String) async {
        do { try await Auth.auth().sendPasswordReset(withEmail: email.trimmingCharacters(in: .whitespacesAndNewlines)); message = "If this email has an account, a password reset email will arrive." }
        catch { message = friendly(error) }
    }
    func signOut() {
        guard !syncing, !busy, ledger.pending.isEmpty, ledger.conflicts.isEmpty else {
            message = "Refresh to upload pending entries and resolve any conflicts before signing out."; return
        }
        do {
            try Auth.auth().signOut()
            listener?.remove(); membershipListener?.remove(); retryTask?.cancel()
            familyID = nil; uid = nil; signedIn = false; owner = false; invitationCode = nil; members = []
            defaults.removeObject(forKey: "teddy.activeFamily")
            defaults.removeObject(forKey: "teddy.activeFamilyUser")
            ledger = FamilySyncLedger(); lastSynced = nil; updateCounts()
            changed()
        } catch { message = friendly(error) }
    }
    func createFamily() async {
        guard let uid, verified, familyID == nil, !busy else { return }
        busy = true; defer { busy = false }
        do {
            let proposedFamily = UUID().uuidString
            let userRef = db.collection("users").document(uid)
            let familyRef = db.collection("families").document(proposedFamily)
            let memberRef = familyRef.collection("members").document(uid)
            let displayName = profileName
            let result = try await db.runTransaction { transaction, errorPointer -> Any? in
                do {
                    let pointer = try transaction.getDocument(userRef)
                    if let existing = pointer.data()?["familyID"] as? String {
                        return ["family": existing, "created": false] as [String: Any]
                    }
                    transaction.setData(["ownerUID": uid, "createdAt": FieldValue.serverTimestamp()], forDocument: familyRef)
                    transaction.setData(["name": displayName, "invite": "owner"], forDocument: memberRef)
                    transaction.setData(["familyID": proposedFamily], forDocument: userRef)
                    return ["family": proposedFamily, "created": true] as [String: Any]
                } catch { errorPointer?.pointee = error as NSError; return nil }
            }
            guard let result = result as? [String: Any], let family = result["family"] as? String else { return }
            if result["created"] as? Bool != true {
                try await activate(family); await refresh(); return
            }
            // Copy this phone's existing journal once, retaining UUIDs to avoid duplicate import.
            let feedings = FeedingRepository.readFeedings()
            let pumping = PumpingRepository.read()
            let settings = FeedingRepository.readSettings()
            try await activate(family)
            applying = true
            FeedingRepository.saveFeedings(feedings)
            PumpingRepository.replaceFromSync(pumping)
            FeedingRepository.saveSettings(settings)
            applying = false
            captureLocal(); await refresh()
        } catch { applying = false; message = friendly(error) }
    }
    private func activate(_ family: String) async throws {
        guard let uid else { return }
        let member = try await db.collection("families").document(family).collection("members").document(uid).getDocument(source: .server)
        guard member.exists else { throw FamilyError("Your access to this family has ended. Your cached journal is retained on this phone.") }
        let familyDocument = try await db.collection("families").document(family).getDocument(source: .server)
        let preferences = FeedingRepository.readSettings()
        let nextSettingsKey = "teddy.family.\(family).settings.v1"
        if defaults.data(forKey: nextSettingsKey) == nil {
            var local = TeddySettings()
            local.unit = preferences.unit; local.remindersEnabled = preferences.remindersEnabled
            local.reminderIntervalMinutes = preferences.reminderIntervalMinutes; local.reminderSoundEnabled = preferences.reminderSoundEnabled
            if let data = try? JSONEncoder().encode(local) { defaults.set(data, forKey: nextSettingsKey) }
        }
        familyID = family; defaults.set(family, forKey: "teddy.activeFamily")
        defaults.set(uid, forKey: "teddy.activeFamilyUser")
        owner = familyDocument.data()?["ownerUID"] as? String == uid
        profileName = member.data()?["name"] as? String ?? profileName
        loadLedger(); changed()
        listen(family)
        retryTask?.cancel()
        retryTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(30))
                guard !Task.isCancelled else { return }
                if let self, !self.ledger.pending.isEmpty { await self.refresh() }
            }
        }
    }
    func invite(email: String) async {
        guard let familyID, let uid, owner, !busy else { return }
        busy = true; defer { busy = false }
        let address = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard address.contains("@"), address.count <= 254 else { message = "Enter the caregiver’s email address."; return }
        do {
            let code = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
            try await db.collection("invitations").document(code).setData([
                "familyID": familyID, "ownerUID": uid, "email": address,
                "expiresAt": Timestamp(date: Date().addingTimeInterval(48 * 3600)), "usedBy": ""
            ])
            invitationCode = code
            message = "Invitation ready for \(address). Share the code with them. It expires in 48 hours and can be used once."
        } catch { message = friendly(error) }
    }
    func revokeInvitation() async {
        guard let code = invitationCode else { return }
        do { try await db.collection("invitations").document(code).delete(); invitationCode = nil; message = "Invitation revoked." }
        catch { message = friendly(error) }
    }
    func join(code: String) async {
        guard let uid, verified, familyID == nil, !busy else { return }
        busy = true; defer { busy = false }
        let cleaned = code.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard cleaned.count == 32, cleaned.allSatisfy({ $0.isHexDigit }) else { message = "Paste the complete 32-character invitation code."; return }
        do {
            let invitation = db.collection("invitations").document(cleaned)
            let userRef = db.collection("users").document(uid)
            let displayName = profileName
            let database = db
            let result = try await db.runTransaction { transaction, errorPointer -> Any? in
                do {
                    let pointer = try transaction.getDocument(userRef)
                    guard pointer.data()?["familyID"] == nil else {
                        throw FamilyError("This account already has a family. Sign in to open its existing journal.")
                    }
                    let snapshot = try transaction.getDocument(invitation)
                    guard let data = snapshot.data(), let family = data["familyID"] as? String,
                          let expiration = data["expiresAt"] as? Timestamp, expiration.dateValue() > Date(),
                          data["usedBy"] as? String == "" else { throw FamilyError("This invitation is expired or already used.") }
                    transaction.updateData(["usedBy": uid], forDocument: invitation)
                    transaction.setData(["name": displayName, "invite": cleaned], forDocument: database.collection("families").document(family).collection("members").document(uid))
                    transaction.setData(["familyID": family], forDocument: userRef)
                    return family
                } catch { errorPointer?.pointee = error as NSError; return nil }
            }
            guard let family = result as? String else { return }
            try await activate(family)
            await refresh()
            message = "Connected. Your previous local-only entries remain separate; the shared family journal is now open."
        } catch { message = friendly(error) }
    }
    func canRemove(_ member: FamilyMember) -> Bool { owner && member.id != uid }
    func removeMember(_ member: FamilyMember) async {
        guard owner, let familyID, member.id != uid else { return }
        do {
            try await db.collection("families").document(familyID).collection("members").document(member.id).delete()
            message = "Caregiver access removed. Records already downloaded to their phone cannot be remotely erased."
        } catch { message = friendly(error) }
    }
    private func listen(_ family: String) {
        listener?.remove(); membershipListener?.remove()
        listener = db.collection("families").document(family).collection("records").addSnapshotListener { [weak self] snapshot, error in
            Task { @MainActor in
                guard let self, self.familyID == family else { return }
                if let error { self.syncError = self.friendly(error); return }
                guard let snapshot else { return }
                self.consume(snapshot)
            }
        }
        membershipListener = db.collection("families").document(family).collection("members").addSnapshotListener { [weak self] snapshot, _ in
            Task { @MainActor in
                guard let self, self.familyID == family, let snapshot else { return }
                self.members = snapshot.documents.map { FamilyMember(id: $0.documentID, name: $0.data()["name"] as? String ?? "Caregiver") }.sorted { $0.name < $1.name }
            }
        }
    }
    func captureLocal() {
        guard familyID != nil, !applying else { return }
        var active = Set<String>()
        for feeding in FeedingRepository.readFeedings() {
            let id = "feeding_\(feeding.id.uuidString)"; active.insert(id)
            if let payload = FamilySyncLedger.encode(feeding) { ledger.stage(id: id, payload: payload, author: profileName) }
        }
        for session in PumpingRepository.read() {
            let id = "pumping_\(session.id.uuidString)"; active.insert(id)
            if let payload = FamilySyncLedger.encode(session) { ledger.stage(id: id, payload: payload, author: profileName) }
        }
        let removed = ledger.records.values.filter { ($0.id.hasPrefix("feeding_") || $0.id.hasPrefix("pumping_")) && !active.contains($0.id) && !$0.value.deleted }
        for record in removed { ledger.stage(id: record.id, payload: record.value.payload, deleted: true, author: profileName) }
        if let payload = FamilySyncLedger.encode(SharedBabyProfile(FeedingRepository.readSettings())) {
            ledger.stage(id: "profile_baby", payload: payload, author: profileName)
        }
        persist()
        Task { await refresh() }
    }
    var siriSyncNote: String {
        guard familyID != nil else { return "" }
        return ledger.pending.isEmpty && ledger.conflicts.isEmpty ? "" : " Saved on this phone; family sync still needs attention in the app."
    }
    func author(kind: String, id: UUID) -> String? { ledger.records["\(kind)_\(id.uuidString)"]?.value.author }
    func resolve(_ id: String, keepLocal: Bool) async {
        ledger.resolve(id: id, keepLocal: keepLocal); persist(); applyLedger(); await refresh()
    }
    func refresh() async {
        guard let family = familyID, let uid, verified, !syncing else { return }
        syncing = true; defer { syncing = false }
        do {
            // Server read proves current membership; offline reads never claim a successful refresh.
            let member = try await db.collection("families").document(family).collection("members").document(uid).getDocument(source: .server)
            guard member.exists else { throw FamilyError("Family access has been removed. Your local entries are retained.") }
            // No local Firestore writes are queued: the durable ledger owns the outbox and conflict decisions.
            for sent in ledger.pending {
                guard familyID == family, self.uid == uid else { return }
                let ref = db.collection("families").document(family).collection("records").document(sent.id)
                let result = try await db.runTransaction({ transaction, errorPointer -> Any? in
                    do {
                        let existing = try transaction.getDocument(ref)
                        let remote = Self.remote(existing.data())
                        if let remote, remote.revision != sent.baseRevision {
                            return Self.dictionary(remote)
                        }
                        if remote == nil && sent.baseRevision != 0 {
                            throw FamilyError("A shared record is missing. Refresh again before editing it.")
                        }
                        var accepted = sent.value; accepted.revision = sent.baseRevision + 1
                        var fields = Self.dictionary(accepted)
                        fields["updatedBy"] = uid; fields["updatedAt"] = FieldValue.serverTimestamp()
                        transaction.setData(fields, forDocument: ref)
                        return Self.dictionary(accepted)
                    } catch { errorPointer?.pointee = error as NSError; return nil }
                })
                if let fields = result as? [String: Any], let accepted = Self.remote(fields) {
                    ledger.acknowledge(id: sent.id, sent: sent, remote: accepted); persist()
                }
            }
            let snapshot = try await db.collection("families").document(family).collection("records").getDocuments(source: .server)
            guard familyID == family, self.uid == uid else { return }
            consume(snapshot)
            syncError = nil
            lastSynced = Date(); defaults.set(lastSynced, forKey: ledgerKey + ".lastSynced")
        } catch { syncError = friendly(error) }
    }
    private func consume(_ snapshot: QuerySnapshot) {
        for document in snapshot.documents {
            if let remote = Self.remote(document.data()) { ledger.receive(id: document.documentID, remote: remote) }
        }
        persist(); applyLedger()
    }
    private func applyLedger() {
        applying = true; defer { applying = false }
        let current = ledger.records.values.filter { !$0.value.deleted }
        let feedings: [Feeding] = current.filter { $0.id.hasPrefix("feeding_") }.compactMap { FamilySyncLedger.decode($0.value.payload, as: Feeding.self) }
        let pumping: [PumpingSession] = current.filter { $0.id.hasPrefix("pumping_") }.compactMap { FamilySyncLedger.decode($0.value.payload, as: PumpingSession.self) }
        FeedingRepository.saveFeedings(feedings)
        PumpingRepository.replaceFromSync(pumping)
        if let record = ledger.records["profile_baby"], let profile = FamilySyncLedger.decode(record.value.payload, as: SharedBabyProfile.self) {
            var settings = FeedingRepository.readSettings()
            settings.babyName = profile.babyName; settings.birthDate = profile.birthDate; settings.clinicianTarget = profile.clinicianTarget
            FeedingRepository.saveSettings(settings)
        }
        changed()
    }
    private func loadLedger() {
        ledger = defaults.data(forKey: ledgerKey).flatMap { try? JSONDecoder().decode(FamilySyncLedger.self, from: $0) } ?? FamilySyncLedger()
        lastSynced = defaults.object(forKey: ledgerKey + ".lastSynced") as? Date
        updateCounts()
    }
    private func persist() {
        if let data = try? JSONEncoder().encode(ledger) { defaults.set(data, forKey: ledgerKey) }
        updateCounts()
    }
    private func updateCounts() { pendingCount = ledger.pending.count; conflicts = ledger.conflicts }
    private func changed() { NotificationCenter.default.post(name: .teddyFeedingsChanged, object: nil) }
    nonisolated private static func dictionary(_ record: FamilyRemoteRecord) -> [String: Any] {
        ["payload": record.payload, "deleted": record.deleted, "revision": record.revision, "operation": record.operation, "author": record.author]
    }
    nonisolated private static func remote(_ data: [String: Any]?) -> FamilyRemoteRecord? {
        guard let data, let payload = data["payload"] as? String, let deleted = data["deleted"] as? Bool,
              let revision = data["revision"] as? Int, let operation = data["operation"] as? String,
              let author = data["author"] as? String else { return nil }
        return FamilyRemoteRecord(payload: payload, deleted: deleted, revision: revision, operation: operation, author: author)
    }
    private func friendly(_ error: Error) -> String {
        let ns = error as NSError
        if ns.domain == FirestoreErrorDomain {
            if ns.code == FirestoreErrorCode.permissionDenied.rawValue { return "Family sync is not authorized. Check your invitation, email verification, and Firebase family security rules. Local entries are retained." }
            if ns.code == FirestoreErrorCode.unavailable.rawValue { return "Offline. Entries are saved on this phone and will upload when the connection returns. Pull to refresh to retry." }
        }
        return error.localizedDescription
    }
}

struct FamilyMember: Identifiable { let id: String; let name: String }
struct FamilyError: LocalizedError { var errorDescription: String?; init(_ message: String) { errorDescription = message } }
