import SwiftUI

struct FamilySharingView: View {
    @ObservedObject private var sync = FamilySyncService.shared
    @State private var email = ""
    @State private var password = ""
    @State private var name = ""
    @State private var creatingAccount = false
    @State private var inviteEmail = ""
    @State private var joinCode = ""
    @State private var removing: FamilyMember?
    @State private var confirmCreate = false
    @State private var importRealRecords = false
    var body: some View {
        Form {
            Section {
                Text("Share Teddy’s feedings, pumping sessions, birthdate, and bottle target with authorized caregivers. Each phone keeps its own units and reminder preferences.")
                Text("Pull down on Home, History, Insights, or Pumping to retrieve the latest shared entries. Offline changes stay on this phone until uploaded.").font(.caption)
            }
            if !sync.signedIn {
                Section(creatingAccount ? "Create caregiver account" : "Caregiver sign-in") {
                    if creatingAccount { TextField("Your display name", text: $name).textContentType(.name) }
                    TextField("Email", text: $email).textContentType(.emailAddress).keyboardType(.emailAddress).textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("Password", text: $password).textContentType(creatingAccount ? .newPassword : .password)
                    Button(creatingAccount ? "Create account" : "Sign in") {
                        Task { await sync.authenticate(email: email, password: password, name: name, create: creatingAccount); password = "" }
                    }.disabled(email.isEmpty || password.isEmpty || (creatingAccount && name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) || sync.busy)
                    Toggle("Create a new account", isOn: $creatingAccount)
                    Button("Reset password") { Task { await sync.resetPassword(email) } }.disabled(email.isEmpty)
                }
            } else if !sync.verified {
                Section("Verify your email") {
                    Text(sync.email)
                    Text("Open the verification email before creating or joining a family.")
                    Button("Check verification") { Task { await sync.checkVerification() } }
                    Button("Resend verification email") { Task { await sync.resendVerification() } }
                    Button("Sign out") { sync.signOut() }
                }
            } else if sync.familyID == nil {
                Section("Start sharing") {
                    Text("Create the family on the phone with the accurate records. On the other phone, choose Join family below. Joining never uploads its old local entries.")
                    Toggle("Include this phone’s existing REAL entries", isOn: $importRealRecords)
                    Text(importRealRecords ? "This will upload all existing feeding and pumping entries on this phone. Check that they are accurate first." : "The shared journal will start empty. Existing local entries stay separate on this phone.").font(.caption)
                    Button("Create shared family") { confirmCreate = true }.disabled(sync.busy)
                }
                Section("Join an existing family") {
                    TextField("Invitation code", text: $joinCode).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Text("Joining opens the shared journal. Existing local-only entries are retained separately and are not automatically uploaded.").font(.caption)
                    Button("Join family") { Task { await sync.join(code: joinCode) } }.disabled(sync.busy || joinCode.isEmpty)
                }
                Section { Text(sync.email); Button("Sign out") { sync.signOut() } }
            } else {
                Section("Sync status") {
                    FamilySyncStatus()
                    Button("Refresh shared data") { Task { await sync.refresh() } }.disabled(sync.syncing)
                    Text("Changes to different entries merge. If two caregivers edit the same entry, review both versions below.").font(.caption)
                }
                if !sync.conflicts.isEmpty {
                    Section("Changes needing review") {
                        ForEach(sync.conflicts) { record in
                            VStack(alignment: .leading, spacing: 10) {
                                Text(record.id.hasPrefix("feeding_") ? "Feeding changed on both phones" : record.id.hasPrefix("pumping_") ? "Pumping session changed on both phones" : "Baby profile changed on both phones").font(.headline)
                                Text("This phone: " + description(record.value, id: record.id)).font(.caption)
                                if let remote = record.conflict { Text("Shared version: " + description(remote, id: record.id)).font(.caption) }
                                Button("Keep shared version") { Task { await sync.resolve(record.id, keepLocal: false) } }
                                Button("Use this phone’s version") { Task { await sync.resolve(record.id, keepLocal: true) } }
                            }
                        }
                    }
                }
                Section("Caregivers") {
                    ForEach(sync.members) { member in
                        HStack {
                            Text(member.name)
                            Spacer()
                            if sync.canRemove(member) { Button("Remove", role: .destructive) { removing = member }.font(.caption) }
                        }
                    }
                    if sync.owner {
                        TextField("Caregiver’s email", text: $inviteEmail).keyboardType(.emailAddress).textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button("Invite caregiver") { Task { await sync.invite(email: inviteEmail) } }.disabled(sync.busy || inviteEmail.isEmpty)
                        if let code = sync.invitationCode {
                            Text(code).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                            ShareLink("Share invitation code", item: code)
                            Text("The recipient must sign in using the invited email address and verify it. Code expires in 48 hours.").font(.caption)
                            Button("Revoke this invitation", role: .destructive) { Task { await sync.revokeInvitation() } }
                        }
                    }
                }
                Section {
                    Text(sync.email)
                    Button("Sign out") { sync.signOut() }.disabled(sync.syncing || sync.busy)
                    Text("Signing out returns to this phone’s local-only journal. Shared records remain in the family’s private cache on this phone.").font(.caption)
                }
            }
            if sync.busy { Section { ProgressView("Working…") } }
            if let message = sync.message {
                Section("Status") {
                    Text(message).font(.callout)
                    Button("Dismiss message") { sync.message = nil }
                }
            }
        }
        .navigationTitle("Family sharing").navigationBarTitleDisplayMode(.inline)
        .refreshable { await sync.refresh() }
        .confirmationDialog(importRealRecords ? "Create family and upload this phone’s real records?" : "Create an empty shared family?", isPresented: $confirmCreate, titleVisibility: .visible) {
            Button("Create shared family") { Task { await sync.createFamily(importExistingRealRecords: importRealRecords) } }
        }
        .confirmationDialog("Remove this caregiver’s access?", isPresented: Binding(get: { removing != nil }, set: { if !$0 { removing = nil } }), titleVisibility: .visible) {
            Button("Remove caregiver", role: .destructive) { if let removing { Task { await sync.removeMember(removing) } }; removing = nil }
        }
    }
    private func description(_ value: FamilyRemoteRecord, id: String) -> String {
        if value.deleted { return "Deleted by \(value.author)" }
        let unit = FeedingRepository.readSettings().unit
        if id.hasPrefix("feeding_"), let feeding = FamilySyncLedger.decode(value.payload, as: Feeding.self) {
            return "\(feeding.time.formatted(date: .abbreviated, time: .shortened)), formula \(unit.display(feeding.formulaML)), breast milk \(unit.display(feeding.breastMilkML)); \(value.author)"
        }
        if id.hasPrefix("pumping_"), let session = FamilySyncLedger.decode(value.payload, as: PumpingSession.self) {
            return "\(session.endedAt.formatted(date: .abbreviated, time: .shortened)), \(unit.display(session.amountML)), \(session.durationMinutes) min; \(value.author)"
        }
        if let profile = FamilySyncLedger.decode(value.payload, as: SharedBabyProfile.self) {
            return "\(profile.babyName), birthdate \(profile.birthDate?.formatted(date: .abbreviated, time: .omitted) ?? "not set"), target \(profile.clinicianTarget?.display(unit: unit) ?? "not set"); \(value.author)"
        }
        return value.author
    }
}

struct FamilySyncStatus: View {
    @ObservedObject private var sync = FamilySyncService.shared
    var body: some View {
        if sync.familyID != nil {
            VStack(alignment: .leading, spacing: 4) {
                Label(title, systemImage: sync.syncing ? "arrow.triangle.2.circlepath" : "person.2.fill")
                    .font(.system(.caption, design: .rounded, weight: .semibold))
                if let date = sync.lastSynced { Text("Last refreshed \(date.formatted(date: .abbreviated, time: .shortened))").font(.caption2) }
                if let message = sync.syncError { Text(message).font(.caption2).lineLimit(3) }
                if !sync.conflicts.isEmpty { Text("Review conflicting changes in Settings → Family sharing.").font(.caption2) }
            }.foregroundStyle(TeddyTheme.cocoa).accessibilityElement(children: .combine)
        }
    }
    private var title: String {
        if !sync.signedIn { return "Sign in to resume family sync" }
        if sync.syncing { return "Refreshing shared journal…" }
        if !sync.conflicts.isEmpty { return "\(sync.conflicts.count) changes need review" }
        if sync.pendingCount > 0 { return "\(sync.pendingCount) changes saved on this phone, waiting to sync" }
        return "Shared family journal"
    }
}
