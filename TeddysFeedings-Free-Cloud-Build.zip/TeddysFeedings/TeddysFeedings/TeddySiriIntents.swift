import Foundation
import AppIntents

struct LogTeddySpokenFeeding: AppIntent {
    static var title: LocalizedStringResource = "Log Teddy's Feeding"
    static var description = IntentDescription("Record Teddy's formula and/or expressed breast milk by describing a feeding out loud.")
    static var openAppWhenRun = false

    @Parameter(title: "What did Teddy drink?", requestValueDialog: "How much formula or breast milk did Teddy drink, and at what time?")
    var feedingDescription: String

    static var parameterSummary: some ParameterSummary {
        Summary("Record Teddy's feeding: \(\.$feedingDescription)")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let parsed: ParsedSpokenFeeding
        do { parsed = try SpokenFeedingParser.parse(feedingDescription) }
        catch { return .result(dialog: IntentDialog("I could not log the feeding: \(error.localizedDescription)")) }
        let formula = parsed.formulaML, breast = parsed.breastMilkML, timestamp = parsed.time
        await MainActor.run {
            FeedingRepository.insert(Feeding(time: timestamp, formulaML: formula, breastMilkML: breast))
        }
        let parts = [formula > 0 ? VolumeUnit.ounces.display(formula) + " formula" : "",
                     breast > 0 ? VolumeUnit.ounces.display(breast) + " breast milk" : ""]
            .filter { !$0.isEmpty }.joined(separator: " and ")
        return .result(dialog: IntentDialog("Saved Teddy’s feeding: \(parts) at \(timestamp.shortFeedingTime)."))
    }
}

struct LogTeddyFormula: AppIntent {
    static var title: LocalizedStringResource = "Log Teddy Formula"
    static var description = IntentDescription("Quickly save Teddy's formula volume in fluid ounces.")
    static var openAppWhenRun = false

    @Parameter(title: "Formula ounces", requestValueDialog: "How many ounces of formula?")
    var ounces: Double
    @Parameter(title: "Feeding time") var feedingTime: Date?

    static var parameterSummary: some ParameterSummary {
        Summary("Log \(\.$ounces) ounces of Teddy's formula")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        guard ounces > 0, ounces <= 33.8 else {
            return .result(dialog: "Please give a formula volume greater than zero and less than 34 ounces.")
        }
        let date = feedingTime ?? Date()
        guard date <= Date().addingTimeInterval(60) else { return .result(dialog: "The feeding time must be in the past.") }
        await MainActor.run { FeedingRepository.insert(Feeding(time: date, formulaML: VolumeUnit.ounces.toMilliliters(ounces), breastMilkML: 0)) }
        return .result(dialog: IntentDialog("Saved \(ounces) ounces of formula for Teddy at \(date.shortFeedingTime)."))
    }
}

struct LogTeddyBreastMilk: AppIntent {
    static var title: LocalizedStringResource = "Log Teddy Breast Milk"
    static var description = IntentDescription("Quickly save Teddy's expressed breast milk volume in fluid ounces.")
    static var openAppWhenRun = false

    @Parameter(title: "Breast milk ounces", requestValueDialog: "How many ounces of breast milk?")
    var ounces: Double
    @Parameter(title: "Feeding time") var feedingTime: Date?

    static var parameterSummary: some ParameterSummary {
        Summary("Log \(\.$ounces) ounces of Teddy's breast milk")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        guard ounces > 0, ounces <= 33.8 else { return .result(dialog: "Please give an amount between zero and 34 ounces.") }
        let date = feedingTime ?? Date()
        guard date <= Date().addingTimeInterval(60) else { return .result(dialog: "The feeding time must be in the past.") }
        await MainActor.run { FeedingRepository.insert(Feeding(time: date, formulaML: 0, breastMilkML: VolumeUnit.ounces.toMilliliters(ounces))) }
        return .result(dialog: IntentDialog("Saved \(ounces) ounces of breast milk for Teddy at \(date.shortFeedingTime)."))
    }
}

struct TeddyShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: LogTeddySpokenFeeding(), phrases: [
            "Log Teddy's feeding in \(.applicationName)",
            "Record Teddy's bottle in \(.applicationName)",
            "Track Teddy's milk in \(.applicationName)",
            "I fed Teddy in \(.applicationName)"
        ], shortTitle: "Log Teddy Feeding", systemImageName: "water.waves")
        AppShortcut(intent: LogTeddyFormula(), phrases: [
            "Log Teddy formula in \(.applicationName)",
            "Record Teddy's formula in \(.applicationName)"
        ], shortTitle: "Log Teddy Formula", systemImageName: "drop.fill")
        AppShortcut(intent: LogTeddyBreastMilk(), phrases: [
            "Log Teddy breast milk in \(.applicationName)",
            "Record Teddy breast milk in \(.applicationName)"
        ], shortTitle: "Log Teddy Breast Milk", systemImageName: "heart.fill")
    }
}
