import Foundation
import AppIntents

struct LogTeddySpokenFeeding: AppIntent {
    static var title: LocalizedStringResource = "Teddy drank"
    static var description = IntentDescription("Record Teddy's formula and/or expressed breast milk by describing a feeding out loud.")
    static var openAppWhenRun = false

    @Parameter(title: "What did Teddy drink?", requestValueDialog: "What did Teddy drink? For example, 3 ounces of formula. You can leave the time out to log now.")
    var feedingDescription: String

    static var parameterSummary: some ParameterSummary {
        Summary("Record Teddy's feeding: \(\.$feedingDescription)")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let journalScope = await MainActor.run { FamilySyncService.storagePrefix }
        let parsed: ParsedSpokenFeeding
        do { parsed = try SpokenFeedingParser.parse(feedingDescription) }
        catch { return .result(dialog: IntentDialog("I could not log the feeding: \(error.localizedDescription)")) }
        let formula = parsed.formulaML, breast = parsed.breastMilkML, timestamp = parsed.time
        let feeding = Feeding(time: timestamp, formulaML: formula, breastMilkML: breast)
        let saved = await MainActor.run {
            guard FamilySyncService.storagePrefix == journalScope else { return false }
            FeedingRepository.insert(feeding)
            return FeedingRepository.readFeedings().contains { $0.id == feeding.id }
        }
        guard saved else {
            return .result(dialog: "I couldn't save that feeding. Please open Teddy's Feedings and try again.")
        }
        let confirmation = await MainActor.run {
            SiriFeedingConfirmation.text(for: feeding, history: FeedingRepository.readFeedings(), unit: FeedingRepository.readSettings().unit)
        }
        await FamilySyncService.shared.refresh()
        let scopeNote = await FamilySyncService.shared.siriSyncNote
        return .result(dialog: IntentDialog("\(confirmation)\(scopeNote)"))
    }
}

struct LogTeddyFormula: AppIntent {
    static var title: LocalizedStringResource = "Log Teddy Formula"
    static var description = IntentDescription("Quickly save Teddy's formula volume in fluid ounces.")
    static var openAppWhenRun = false

    @Parameter(title: "Formula ounces", requestValueDialog: "How many ounces of formula?")
    var ounces: Double
    @Parameter(title: "Feeding time") var feedingTime: Date?

    static var parameterSummary: some ParameterSummary {
        Summary("Log \(\.$ounces) ounces of Teddy's formula")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let journalScope = await MainActor.run { FamilySyncService.storagePrefix }
        guard ounces > 0, ounces <= 33.8 else {
            return .result(dialog: "Please give a formula volume greater than zero and less than 34 ounces.")
        }
        let date = feedingTime ?? Date()
        guard date <= Date().addingTimeInterval(60) else { return .result(dialog: "The feeding time must be in the past.") }
        let feeding = Feeding(time: date, formulaML: VolumeUnit.ounces.toMilliliters(ounces), breastMilkML: 0)
        let saved = await MainActor.run {
            guard FamilySyncService.storagePrefix == journalScope else { return false }
            FeedingRepository.insert(feeding)
            return FeedingRepository.readFeedings().contains { $0.id == feeding.id }
        }
        guard saved else { return .result(dialog: "The journal changed or the entry could not be saved. Please retry in the intended journal.") }
        await FamilySyncService.shared.refresh()
        let scopeNote = await FamilySyncService.shared.siriSyncNote
        let confirmation = await MainActor.run {
            SiriFeedingConfirmation.text(for: feeding, history: FeedingRepository.readFeedings(), unit: FeedingRepository.readSettings().unit)
        }
        return .result(dialog: IntentDialog("\(confirmation)\(scopeNote)"))
    }
}

struct LogTeddyBreastMilk: AppIntent {
    static var title: LocalizedStringResource = "Log Teddy Breast Milk"
    static var description = IntentDescription("Quickly save Teddy's expressed breast milk volume in fluid ounces.")
    static var openAppWhenRun = false

    @Parameter(title: "Breast milk ounces", requestValueDialog: "How many ounces of breast milk?")
    var ounces: Double
    @Parameter(title: "Feeding time") var feedingTime: Date?

    static var parameterSummary: some ParameterSummary {
        Summary("Log \(\.$ounces) ounces of Teddy's breast milk")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let journalScope = await MainActor.run { FamilySyncService.storagePrefix }
        guard ounces > 0, ounces <= 33.8 else { return .result(dialog: "Please give an amount between zero and 34 ounces.") }
        let date = feedingTime ?? Date()
        guard date <= Date().addingTimeInterval(60) else { return .result(dialog: "The feeding time must be in the past.") }
        let feeding = Feeding(time: date, formulaML: 0, breastMilkML: VolumeUnit.ounces.toMilliliters(ounces))
        let saved = await MainActor.run {
            guard FamilySyncService.storagePrefix == journalScope else { return false }
            FeedingRepository.insert(feeding)
            return FeedingRepository.readFeedings().contains { $0.id == feeding.id }
        }
        guard saved else { return .result(dialog: "The journal changed or the entry could not be saved. Please retry in the intended journal.") }
        await FamilySyncService.shared.refresh()
        let scopeNote = await FamilySyncService.shared.siriSyncNote
        let confirmation = await MainActor.run {
            SiriFeedingConfirmation.text(for: feeding, history: FeedingRepository.readFeedings(), unit: FeedingRepository.readSettings().unit)
        }
        return .result(dialog: IntentDialog("\(confirmation)\(scopeNote)"))
    }
}

struct LogPumping: AppIntent {
    static var title: LocalizedStringResource = "Log pumping"
    static var description = IntentDescription("Save expressed milk collected during a 30-minute pumping session, with the current time as its end.")
    static var openAppWhenRun = false
    @Parameter(title: "Pumping amount", requestValueDialog: "How much did you pump? Say, I pumped 3 ounces.")
    var pumpingAmount: String
    static var parameterSummary: some ParameterSummary { Summary("Log pumping: \(\.$pumpingAmount)") }
    func perform() async throws -> some IntentResult & ProvidesDialog {
        let journalScope = await MainActor.run { FamilySyncService.storagePrefix }
        let unit = await MainActor.run { FeedingRepository.readSettings().unit }
        let amount: Double
        do { amount = try PumpingSpeechParser.parse(pumpingAmount, defaultUnit: unit) }
        catch { return .result(dialog: IntentDialog("I couldn’t log pumping. \(error.localizedDescription)")) }
        let session = PumpingSession(endedAt: Date(), amountML: amount)
        let saved = await MainActor.run {
            guard FamilySyncService.storagePrefix == journalScope else { return false }
            return PumpingRepository.save(session)
        }
        guard saved else { return .result(dialog: "I couldn’t save that pumping session. Please open Teddy’s Feedings and try again.") }
        await FamilySyncService.shared.refresh()
        let syncNote = await FamilySyncService.shared.siriSyncNote
        return .result(dialog: IntentDialog("Saved \(unit.display(amount)) pumped at \(session.endedAt.shortFeedingTime), for a 30-minute session.\(syncNote)"))
    }
}

struct MilkBottleEntity: AppEntity {
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Milk bottle"
    static var defaultQuery = MilkBottleQuery()
    let formulaML: Double
    let breastMilkML: Double
    var id: String { "\(formulaML):\(breastMilkML)" }
    var displayRepresentation: DisplayRepresentation {
        let parts = [formulaML > 0 ? SiriFeedingConfirmation.amount(formulaML, unit: .ounces) + " formula" : "",
                     breastMilkML > 0 ? SiriFeedingConfirmation.amount(breastMilkML, unit: .ounces) + " breast milk" : ""].filter { !$0.isEmpty }.joined(separator: " and ")
        return DisplayRepresentation(title: "\(parts)")
    }
}
struct MilkBottleQuery: EntityStringQuery {
    func entities(for identifiers: [String]) async throws -> [MilkBottleEntity] {
        identifiers.compactMap { identifier in
            let values = identifier.split(separator: ":").compactMap { Double($0) }
            guard values.count == 2, values.allSatisfy({ $0.isFinite && $0 >= 0 }), values[0] + values[1] > 0, values[0] + values[1] <= 1000 else { return nil }
            return MilkBottleEntity(formulaML: values[0], breastMilkML: values[1])
        }
    }
    func entities(matching string: String) async throws -> [MilkBottleEntity] {
        let parsed = try SpokenFeedingParser.parse(string)
        return [MilkBottleEntity(formulaML: parsed.formulaML, breastMilkML: parsed.breastMilkML)]
    }
    func suggestedEntities() async throws -> [MilkBottleEntity] { [] }
}
struct LogFeedingNow: AppIntent {
    static var title: LocalizedStringResource = "Log milk now"
    static var description = IntentDescription("Log the amount and milk type at the current time. Siri repeats the saved entry and compares the total with the previous logged feeding.")
    static var openAppWhenRun = false
    @Parameter(title: "Bottle", requestValueDialog: "How much and which milk? For example, 3 ounces of formula.")
    var bottle: MilkBottleEntity
    static var parameterSummary: some ParameterSummary { Summary("Log \(\.$bottle) now") }
    func perform() async throws -> some IntentResult & ProvidesDialog {
        let scope = await MainActor.run { FamilySyncService.storagePrefix }
        guard bottle.formulaML.isFinite, bottle.breastMilkML.isFinite, bottle.formulaML >= 0, bottle.breastMilkML >= 0,
              bottle.formulaML + bottle.breastMilkML > 0, bottle.formulaML + bottle.breastMilkML <= 1000 else {
            return .result(dialog: "Please give a milk amount greater than zero and up to 1000 milliliters.")
        }
        let feeding = Feeding(time: Date(), formulaML: bottle.formulaML, breastMilkML: bottle.breastMilkML)
        let confirmation: String? = await MainActor.run {
            guard FamilySyncService.storagePrefix == scope else { return nil }
            FeedingRepository.insert(feeding)
            guard FeedingRepository.readFeedings().contains(where: { $0.id == feeding.id }) else { return nil }
            return SiriFeedingConfirmation.text(for: feeding, history: FeedingRepository.readFeedings(), unit: FeedingRepository.readSettings().unit)
        }
        guard let confirmation else { return .result(dialog: "I couldn’t save that feeding. Please open Teddy’s Feedings and try again.") }
        await FamilySyncService.shared.refresh()
        let syncNote = await FamilySyncService.shared.siriSyncNote
        return .result(dialog: IntentDialog("\(confirmation)\(syncNote)"))
    }
}

struct TeddyShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: LogFeedingNow(), phrases: [
            "Log \(\.$bottle) in \(.applicationName)",
            "Log milk in \(.applicationName)"
        ], shortTitle: "Log milk now", systemImageName: "drop.fill")
        AppShortcut(intent: LogPumping(), phrases: [
            "Log pumping in \(.applicationName)",
            "I pumped milk in \(.applicationName)",
            "Record pumping in \(.applicationName)"
        ], shortTitle: "Log pumping", systemImageName: "drop.circle.fill")
        AppShortcut(intent: LogTeddySpokenFeeding(), phrases: [
            "Teddy drank in \(.applicationName)",
            "Log a bottle in \(.applicationName)",
            "Log Teddy's feeding in \(.applicationName)",
            "Record Teddy's bottle in \(.applicationName)",
            "Track Teddy's milk in \(.applicationName)",
            "I fed Teddy in \(.applicationName)"
        ], shortTitle: "Teddy drank", systemImageName: "water.waves")
        AppShortcut(intent: LogTeddyFormula(), phrases: [
            "Log Teddy formula in \(.applicationName)",
            "Record Teddy's formula in \(.applicationName)"
        ], shortTitle: "Log Teddy Formula", systemImageName: "drop.fill")
        AppShortcut(intent: LogTeddyBreastMilk(), phrases: [
            "Log Teddy breast milk in \(.applicationName)",
            "Record Teddy breast milk in \(.applicationName)"
        ], shortTitle: "Log Teddy Breast Milk", systemImageName: "heart.fill")
    }
}
