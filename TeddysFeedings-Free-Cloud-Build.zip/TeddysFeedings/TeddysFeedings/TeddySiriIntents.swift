import Foundation
import AppIntents

struct LogTeddySpokenFeeding: AppIntent {
    static var title: LocalizedStringResource = "Teddy drank"
    static var description = IntentDescription("Record Teddy's formula and/or expressed breast milk by describing a feeding out loud.")
    static var openAppWhenRun = false

    @Parameter(title: "What did Teddy drink?", requestValueDialog: "What did Teddy drink? For example, Teddy drank 3 ounces of formula at 8:15 PM.")
    var feedingDescription: String

    static var parameterSummary: some ParameterSummary {
        Summary("Record Teddy's feeding: \(\.$feedingDescription)")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let parsed: ParsedSpokenFeeding
        do { parsed = try SpokenFeedingParser.parse(feedingDescription) }
        catch { return .result(dialog: IntentDialog("I could not log the feeding: \(error.localizedDescription)")) }
        let formula = parsed.formulaML, breast = parsed.breastMilkML, timestamp = parsed.time
        let feeding = Feeding(time: timestamp, formulaML: formula, breastMilkML: breast)
        let saved = await MainActor.run {
            FeedingRepository.insert(feeding)
            return FeedingRepository.readFeedings().contains { $0.id == feeding.id }
        }
        guard saved else {
            return .result(dialog: "I couldn't save that feeding. Please open Teddy's Feedings and try again.")
        }
        let parts = [formula > 0 ? VolumeUnit.ounces.display(formula) + " formula" : "",
                     breast > 0 ? VolumeUnit.ounces.display(breast) + " breast milk" : ""]
            .filter { !$0.isEmpty }.joined(separator: " and ")
        await FamilySyncService.shared.refresh()
        return .result(dialog: IntentDialog("Logged. Teddy drank \(parts) on \(timestamp.formatted(date: .abbreviated, time: .omitted)) at \(timestamp.shortFeedingTime)."))
    }
}

struct LogTeddyFormula: AppIntent {
    static var title: LocalizedStringResource = "Log Teddy Formula"
    static var description = IntentDescription("Quickly save Teddy's formula volume in fluid ounces.")
    static var openAppWhenRun = false

    @Parameter(title: "Formula ounces", requestValueDialog: "How many ounces of formula?")
    var ounces: Double
    @Parameter(title: "Feeding time") var feedingTime: Date?

    static var parameterSummary: some ParameterSummary {
        Summary("Log \(\.$ounces) ounces of Teddy's formula")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        guard ounces > 0, ounces <= 33.8 else {
            return .result(dialog: "Please give a formula volume greater than zero and less than 34 ounces.")
        }
        let date = feedingTime ?? Date()
        guard date <= Date().addingTimeInterval(60) else { return .result(dialog: "The feeding time must be in the past.") }
        await MainActor.run { FeedingRepository.insert(Feeding(time: date, formulaML: VolumeUnit.ounces.toMilliliters(ounces), breastMilkML: 0)) }
        await FamilySyncService.shared.refresh()
        return .result(dialog: IntentDialog("Saved \(ounces) ounces of formula for Teddy at \(date.shortFeedingTime)."))
    }
}

struct LogTeddyBreastMilk: AppIntent {
    static var title: LocalizedStringResource = "Log Teddy Breast Milk"
    static var description = IntentDescription("Quickly save Teddy's expressed breast milk volume in fluid ounces.")
    static var openAppWhenRun = false

    @Parameter(title: "Breast milk ounces", requestValueDialog: "How many ounces of breast milk?")
    var ounces: Double
    @Parameter(title: "Feeding time") var feedingTime: Date?

    static var parameterSummary: some ParameterSummary {
        Summary("Log \(\.$ounces) ounces of Teddy's breast milk")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        guard ounces > 0, ounces <= 33.8 else { return .result(dialog: "Please give an amount between zero and 34 ounces.") }
        let date = feedingTime ?? Date()
        guard date <= Date().addingTimeInterval(60) else { return .result(dialog: "The feeding time must be in the past.") }
        await MainActor.run { FeedingRepository.insert(Feeding(time: date, formulaML: 0, breastMilkML: VolumeUnit.ounces.toMilliliters(ounces))) }
        await FamilySyncService.shared.refresh()
        return .result(dialog: IntentDialog("Saved \(ounces) ounces of breast milk for Teddy at \(date.shortFeedingTime)."))
    }
}

struct LogPumping: AppIntent {
    static var title: LocalizedStringResource = "Log pumping"
    static var description = IntentDescription("Save expressed milk collected during a 30-minute pumping session, with the current time as its end.")
    static var openAppWhenRun = false
    @Parameter(title: "Pumping amount", requestValueDialog: "How much did you pump? Say, I pumped 3 ounces.")
    var pumpingAmount: String
    static var parameterSummary: some ParameterSummary { Summary("Log pumping: \(\.$pumpingAmount)") }
    func perform() async throws -> some IntentResult & ProvidesDialog {
        let unit = await MainActor.run { FeedingRepository.readSettings().unit }
        let amount: Double
        do { amount = try PumpingSpeechParser.parse(pumpingAmount, defaultUnit: unit) }
        catch { return .result(dialog: IntentDialog("I couldn’t log pumping. \(error.localizedDescription)")) }
        let session = PumpingSession(endedAt: Date(), amountML: amount)
        let saved = await MainActor.run { PumpingRepository.save(session) }
        guard saved else { return .result(dialog: "I couldn’t save that pumping session. Please open Teddy’s Feedings and try again.") }
        await FamilySyncService.shared.refresh()
        let syncNote = await FamilySyncService.shared.siriSyncNote
        return .result(dialog: IntentDialog("Saved \(unit.display(amount)) pumped at \(session.endedAt.shortFeedingTime), for a 30-minute session.\(syncNote)"))
    }
}

struct TeddyShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: LogPumping(), phrases: [
            "Log pumping in \(.applicationName)",
            "I pumped milk in \(.applicationName)",
            "Record pumping in \(.applicationName)"
        ], shortTitle: "Log pumping", systemImageName: "drop.circle.fill")
        AppShortcut(intent: LogTeddySpokenFeeding(), phrases: [
            "Teddy drank in \(.applicationName)",
            "Log a bottle in \(.applicationName)",
            "Log Teddy's feeding in \(.applicationName)",
            "Record Teddy's bottle in \(.applicationName)",
            "Track Teddy's milk in \(.applicationName)",
            "I fed Teddy in \(.applicationName)"
        ], shortTitle: "Teddy drank", systemImageName: "water.waves")
        AppShortcut(intent: LogTeddyFormula(), phrases: [
            "Log Teddy formula in \(.applicationName)",
            "Record Teddy's formula in \(.applicationName)"
        ], shortTitle: "Log Teddy Formula", systemImageName: "drop.fill")
        AppShortcut(intent: LogTeddyBreastMilk(), phrases: [
            "Log Teddy breast milk in \(.applicationName)",
            "Record Teddy breast milk in \(.applicationName)"
        ], shortTitle: "Log Teddy Breast Milk", systemImageName: "heart.fill")
    }
}
