import SwiftUI
import Charts

struct PumpingView: View {
    @EnvironmentObject private var store: FeedingStore
    @State private var draft: PumpingSession?
    @State private var editingExisting = false
    @State private var deleting: PumpingSession?
    @State private var exportURL: URL?
    @State private var showingMore = false
    private var days: [PumpingBucket] { PumpingMath.days(store.pumpingSessions) }
    private var total: Double { days.reduce(0) { $0 + $1.amountML } }
    private var count: Int { days.reduce(0) { $0 + $1.count } }
    private var weekMinutes: Int {
        guard let first = days.first?.date else { return 0 }
        return store.pumpingSessions.filter { $0.endedAt >= first && $0.endedAt <= Date() }.reduce(0) { $0 + $1.durationMinutes }
    }
    private var today: [PumpingSession] { store.pumpingSessions.filter { Calendar.current.isDateInToday($0.endedAt) && $0.endedAt <= Date() } }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header
                    Button {
                        editingExisting = false
                        draft = PumpingSession(endedAt: Date(), amountML: 0)
                    } label: {
                        Label("Log pumping session", systemImage: "plus.circle.fill")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .frame(maxWidth: .infinity).padding(18).foregroundStyle(.white)
                            .background(TeddyTheme.accent, in: RoundedRectangle(cornerRadius: 19))
                    }.buttonStyle(.plain)
                    todaySummary
                    dailyChart
                    halfHourChart
                    weeklySummary
                    recentSessions
                    siriHelp
                }.padding(.horizontal, 18).padding(.vertical, 16)
            }
            .scrollBounceBehavior(.always)
            .safeAreaInset(edge: .top, spacing: 0) { FamilySyncStatus().frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 18).padding(.vertical, 4).background(TeddyTheme.cream) }
            .refreshable { await store.refreshShared(); exportURL = PumpingRepository.exportCSV() }
            .background(TeddyTheme.cream.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .sheet(item: $draft) { session in
                PumpingEditor(session: session, editing: editingExisting).environmentObject(store).preferredColorScheme(.light)
            }
            .confirmationDialog("Delete this pumping session?", isPresented: Binding(
                get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                Button("Delete session", role: .destructive) {
                    if let session = deleting {
                        if !PumpingRepository.delete(session) { store.notificationMessage = "This pumping session changed since you selected it. Refresh and review it before deleting." }
                        store.reload()
                    }
                    deleting = nil
                }
            } message: { Text("This removes the pumping entry only. Feeding logs stay as they are.") }
            .onAppear { exportURL = PumpingRepository.exportCSV() }
            .onChange(of: store.pumpingSessions) { _, _ in exportURL = PumpingRepository.exportCSV() }
        }
    }
    private var header: some View {
        HStack(spacing: 12) {
            BearFace(size: 58)
            VStack(alignment: .leading, spacing: 4) {
                Text("Pumping journal").font(.system(size: 27, weight: .heavy, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                Text("Every little drop, lovingly logged").font(.system(size: 13, design: .rounded)).foregroundStyle(TeddyTheme.muted)
            }
        }
    }
    private var todaySummary: some View {
        TeddyCard {
            Text("Today").font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
            row("Milk pumped", store.settings.unit.display(today.reduce(0) { $0 + $1.amountML }))
            row("Sessions", "\(today.count)")
            row("Time pumping", "\(today.reduce(0) { $0 + $1.durationMinutes }) min")
            Text("Sessions default to 30 minutes. Time is the session’s end; its start is calculated from the duration. Pumped milk is tracked separately from feeding totals.")
                .font(.caption).foregroundStyle(TeddyTheme.muted)
        }
    }
    private var dailyChart: some View {
        TeddyCard {
            Text("Milk pumped · last 7 days").font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
            if count == 0 {
                Text("Your pumping totals will appear here after your first session.").font(.subheadline).foregroundStyle(TeddyTheme.muted)
            } else {
                Chart(days) { day in
                    BarMark(x: .value("Day", day.date, unit: .day), y: .value("Pumped", store.settings.unit.fromMilliliters(day.amountML)))
                        .foregroundStyle(TeddyTheme.accent).cornerRadius(5)
                        .annotation(position: .top, spacing: 3) {
                            if day.amountML > 0 {
                                Text(store.settings.unit.display(day.amountML)).font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                            }
                        }
                }
                .chartXAxis { AxisMarks(values: .stride(by: .day)) { _ in AxisValueLabel(format: .dateTime.weekday(.narrow)) } }
                .chartYAxisLabel(store.settings.unit.symbol)
                .chartYScale(domain: 0...max(1, store.settings.unit.fromMilliliters(days.map(\.amountML).max() ?? 0) * 1.18))
                .frame(height: 220)
                .accessibilityLabel("Daily milk pumped in \(store.settings.unit.symbol), including days without sessions.")
            }
        }
    }
    private var halfHourChart: some View {
        TeddyCard {
            Text("Today · 30-minute intervals").font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
            Text("Amounts are grouped by the half-hour in which each session ended.").font(.caption).foregroundStyle(TeddyTheme.muted)
            let buckets = PumpingMath.halfHours(store.pumpingSessions)
            if buckets.isEmpty {
                Text("No sessions logged today.").font(.subheadline).foregroundStyle(TeddyTheme.muted)
            } else {
                Chart(buckets) { bucket in
                    BarMark(x: .value("Ended", bucket.date.formatted(date: .omitted, time: .shortened)), y: .value("Pumped", store.settings.unit.fromMilliliters(bucket.amountML)))
                        .foregroundStyle(TeddyTheme.sage).cornerRadius(4)
                        .annotation(position: .top) {
                            Text(store.settings.unit.display(bucket.amountML)).font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        }
                }
                .chartYAxisLabel(store.settings.unit.symbol).frame(height: 190)
            }
        }
    }
    private var weeklySummary: some View {
        TeddyCard {
            Text("7-day pumping insights").font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
            Divider()
            row("Total pumped", store.settings.unit.display(total))
            row("Sessions", "\(count)")
            row("Time pumping", "\(weekMinutes) min")
            row("Average per day", store.settings.unit.display(total / 7))
            row("Average per session", count > 0 ? store.settings.unit.display(total / Double(count)) : "—")
            row("Days with sessions", "\(days.filter { $0.count > 0 }.count) of 7")
            if let best = days.filter({ $0.count > 0 }).max(by: { $0.amountML < $1.amountML }) {
                row("Highest-volume day", "\(best.date.shortFeedingDate) · \(store.settings.unit.display(best.amountML))")
            }
            Text("Daily averages include all seven days. Amounts are historical records, not production goals.").font(.caption).foregroundStyle(TeddyTheme.muted)
            if let exportURL {
                ShareLink(item: exportURL) { Label("Export pumping CSV", systemImage: "square.and.arrow.up") }.font(.subheadline)
            }
            Button("Refresh export") { exportURL = PumpingRepository.exportCSV() }.font(.caption)
        }
    }
    private var recentSessions: some View {
        TeddyCard {
            Text("Pumping sessions").font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
            if store.pumpingSessions.isEmpty {
                Text("Log the amount after pumping, or ask Siri to log it for you.").font(.subheadline).foregroundStyle(TeddyTheme.muted)
            } else {
                ForEach(Array(store.pumpingSessions.prefix(showingMore ? store.pumpingSessions.count : 20))) { session in
                    Button {
                        editingExisting = true
                        draft = session
                    } label: {
                        HStack {
                            BottleIcon().frame(width: 17, height: 27).foregroundStyle(TeddyTheme.accent)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(store.settings.unit.display(session.amountML)).font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                                if let author = FamilySyncService.shared.author(kind: "pumping", id: session.id) {
                                    Text("Last saved by \(author)").font(.caption2).foregroundStyle(TeddyTheme.muted)
                                }
                                Text("\(session.endedAt.shortFeedingDate) · \(session.startedAt.shortFeedingTime)–\(session.endedAt.shortFeedingTime) · \(session.durationMinutes) min")
                                    .font(.caption).foregroundStyle(TeddyTheme.muted)
                            }
                            Spacer()
                            Image(systemName: "pencil").foregroundStyle(TeddyTheme.accent)
                        }.padding(.vertical, 7)
                    }.buttonStyle(.plain).contextMenu {
                        Button("Edit session", systemImage: "pencil") { editingExisting = true; draft = session }
                        Button("Delete session", systemImage: "trash", role: .destructive) { deleting = session }
                    }
                    Divider()
                }
                if store.pumpingSessions.count > 20 {
                    Button(showingMore ? "Show latest 20" : "Show all sessions") { showingMore.toggle() }
                }
            }
        }
    }
    private var siriHelp: some View {
        TeddyCard {
            Label("Hands-free pumping log", systemImage: "waveform").font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
            Text("Say ‘Hey Siri, Log pumping in Teddy’s Feedings.’ Then say ‘I pumped 3 ounces.’")
                .font(.subheadline).foregroundStyle(TeddyTheme.cocoa)
            Text("For the shorter ‘Hey Siri, Log pumping’ trigger: create a personal shortcut named Log pumping in Apple Shortcuts. Add Dictate Text, then Teddy’s Feedings → Log pumping. Set Pumping amount to Dictated Text. Say the trigger, pause for dictation, then ‘I pumped 3 ounces’.")
                .font(.caption).foregroundStyle(TeddyTheme.muted)
            Text("Siri logs the current time as the session end, uses a 30-minute duration, and confirms the saved amount and time. Say ounces or milliliters; if you omit units, your app measurement setting is used.")
                .font(.caption).foregroundStyle(TeddyTheme.muted)
        }
    }
    private func row(_ title: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.system(.subheadline, design: .rounded)).foregroundStyle(TeddyTheme.muted)
            Spacer(minLength: 10)
            Text(value).font(.system(.subheadline, design: .rounded, weight: .bold)).foregroundStyle(TeddyTheme.cocoa).multilineTextAlignment(.trailing)
        }
    }
}

struct PumpingEditor: View {
    @EnvironmentObject private var store: FeedingStore
    @Environment(\.dismiss) private var dismiss
    let session: PumpingSession
    let editing: Bool
    @State private var amount = ""
    @State private var endedAt = Date()
    @State private var minutes = 30
    @State private var notes = ""
    @State private var saveError = false
    @FocusState private var amountFocused: Bool
    private var ml: Double? {
        guard let number = Double(amount.replacingOccurrences(of: ",", with: ".")), number.isFinite, number >= 0 else { return nil }
        return store.settings.unit.toMilliliters(number)
    }
    private var canSave: Bool { ml.map { $0 <= 2000 } ?? false }
    var body: some View {
        NavigationStack {
            Form {
                Section("Milk pumped") {
                    LabeledContent("Amount (\(store.settings.unit.symbol))") {
                        TextField("0", text: $amount).keyboardType(.decimalPad).multilineTextAlignment(.trailing).focused($amountFocused)
                    }
                    Text("Zero is allowed for a session with no collected milk.").font(.caption).foregroundStyle(TeddyTheme.muted)
                }
                Section("Session time") {
                    DatePicker("Ended at", selection: $endedAt, in: ...Date(), displayedComponents: [.date, .hourAndMinute])
                    Stepper("Duration: \(minutes) minutes", value: $minutes, in: 30...180, step: 30)
                    Text("Started at \(endedAt.addingTimeInterval(-Double(minutes) * 60).formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption).foregroundStyle(TeddyTheme.muted)
                }
                Section("Notes (optional)") { TextField("Comfort, pump settings, or other notes", text: $notes, axis: .vertical) }
                Section {
                    Text("Pumped milk is logged separately. This entry does not mean Teddy drank it.").font(.caption).foregroundStyle(TeddyTheme.muted)
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle(editing ? "Edit pumping" : "Log pumping").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { Button("Save") { save() }.disabled(!canSave) }
                ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { amountFocused = false } }
            }
            .onAppear {
                endedAt = session.endedAt; minutes = session.durationMinutes; notes = session.notes
                amount = editing ? store.settings.unit.fromMilliliters(session.amountML).formatted(.number.precision(.fractionLength(0...3))) : ""
            }
            .alert("Couldn’t save pumping session", isPresented: $saveError) { Button("OK", role: .cancel) {} } message: {
                Text("Check the amount and time. If another caregiver changed or deleted this session, cancel and reopen its latest version. Your entered details are still here.")
            }
        }.tint(TeddyTheme.accent)
    }
    private func save() {
        guard let ml, canSave else { return }
        if editing && PumpingRepository.read().first(where: { $0.id == session.id }) != session { saveError = true; return }
        var result = session
        result.endedAt = endedAt; result.amountML = ml; result.durationMinutes = minutes
        result.notes = String(notes.trimmingCharacters(in: .whitespacesAndNewlines).prefix(2000))
        if PumpingRepository.save(result, editing: editing) { store.reload(); dismiss() } else { saveError = true }
    }
}
