import SwiftUI
import AppIntents
import UserNotifications
import UIKit

// Keep native banners and sounds visible even when the app is open.
final class TeddyNotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let settings = FeedingRepositoryNotificationPreferences.readSoundEnabled()
        completionHandler(settings ? [.banner, .list, .sound] : [.banner, .list])
    }
}

// The delegate is registered at application launch, before notifications can arrive.
final class TeddyAppDelegate: NSObject, UIApplicationDelegate {
    private let notificationDelegate = TeddyNotificationDelegate()

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().delegate = notificationDelegate
        return true
    }
}

// A nonisolated read is used in the notification delegate callback.
private enum FeedingRepositoryNotificationPreferences {
    static func readSoundEnabled() -> Bool {
        guard let data = UserDefaults.standard.data(forKey: "teddy.settings.v1"),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let enabled = json["reminderSoundEnabled"] as? Bool else { return true }
        return enabled
    }
}

@main
struct TeddysFeedingsApp: App {
    @UIApplicationDelegateAdaptor(TeddyAppDelegate.self) private var appDelegate
    @StateObject private var store = FeedingStore()
    @Environment(\.scenePhase) private var scenePhase
    @State private var currentDraft: FeedingDraft?
    @State private var currentTab = 0

    init() {
        TeddyShortcuts.updateAppShortcutParameters()
    }

    var body: some Scene {
        WindowGroup {
            TabView(selection: $currentTab) {
                HomeView { draft in currentDraft = draft }
                    .tabItem { Label("Home", systemImage: "house.fill") }.tag(0)
                HistoryView { draft in currentDraft = draft }
                    .tabItem { Label("History", systemImage: "clock.arrow.circlepath") }.tag(1)
                InsightsView()
                    .tabItem { Label("Insights", systemImage: "chart.bar.fill") }.tag(2)
                SettingsView()
                    .tabItem { Label("Settings", systemImage: "gearshape.fill") }.tag(3)
            }
            .preferredColorScheme(.light)
            .foregroundStyle(TeddyTheme.cocoa)
            .tint(TeddyTheme.accent)
            .toolbarBackground(TeddyTheme.paper, for: .tabBar)
            .toolbarBackground(.visible, for: .tabBar)
            .toolbarColorScheme(.light, for: .tabBar)
            .environmentObject(store)
            .sheet(item: $currentDraft) { draft in
                FeedingEditor(draft: draft).environmentObject(store).preferredColorScheme(.light)
            }
            .alert("Reminders unavailable", isPresented: Binding(
                get: { store.notificationMessage != nil },
                set: { if !$0 { store.notificationMessage = nil } })) {
                    Button("OK", role: .cancel) { store.notificationMessage = nil }
                } message: { Text(store.notificationMessage ?? "") }
            .onAppear {
                #if DEBUG
                let arguments = ProcessInfo.processInfo.arguments
                if let index = arguments.firstIndex(of: "--screenshot-tab"),
                   arguments.indices.contains(index + 1), let value = Int(arguments[index + 1]),
                   (0...3).contains(value) { currentTab = value }
                #endif
            }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { store.reload() }
            }
        }
    }
}
