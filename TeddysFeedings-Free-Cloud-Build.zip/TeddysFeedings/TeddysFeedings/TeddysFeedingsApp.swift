import SwiftUI
import Combine
import AppIntents
import UserNotifications
import UIKit

// Retains a notification tap even if it arrives before the SwiftUI scene is ready.
@MainActor
final class FeedingReminderPresentation: ObservableObject {
    static let shared = FeedingReminderPresentation()
    @Published var isPresented = false
}

// Keep native banners and sounds visible even when the app is open.
final class TeddyNotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let settings = FeedingRepositoryNotificationPreferences.readSoundEnabled()
        completionHandler(settings ? [.banner, .list, .sound] : [.banner, .list])
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let id = response.notification.request.identifier
        guard response.actionIdentifier == UNNotificationDefaultActionIdentifier,
              id == "teddy.nextFeeding" || id.hasPrefix("teddy.test.") else {
            completionHandler()
            return
        }
        Task { @MainActor in
            FeedingReminderPresentation.shared.isPresented = true
            completionHandler()
        }
    }

}

// The delegate is registered at application launch, before notifications can arrive.
final class TeddyAppDelegate: NSObject, UIApplicationDelegate {
    private let notificationDelegate = TeddyNotificationDelegate()

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().delegate = notificationDelegate
        return true
    }
}

// A nonisolated read is used in the notification delegate callback.
private enum FeedingRepositoryNotificationPreferences {
    static func readSoundEnabled() -> Bool {
        guard let data = UserDefaults.standard.data(forKey: FamilySyncService.storagePrefix + ".settings.v1"),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let enabled = json["reminderSoundEnabled"] as? Bool else { return true }
        return enabled
    }
}

@main
struct TeddysFeedingsApp: App {
    @UIApplicationDelegateAdaptor(TeddyAppDelegate.self) private var appDelegate
    @StateObject private var store = FeedingStore()
    @StateObject private var feedingReminder = FeedingReminderPresentation.shared
    @Environment(\.scenePhase) private var scenePhase
    @State private var currentDraft: FeedingDraft?
    @State private var currentTab = 0

    init() {
        TeddyShortcuts.updateAppShortcutParameters()
    }

    var body: some Scene {
        WindowGroup {
            TabView(selection: $currentTab) {
                HomeView { draft in currentDraft = draft }
                    .tabItem { Label("Home", systemImage: "house.fill") }.tag(0)
                HistoryView { draft in currentDraft = draft }
                    .tabItem { Label("History", systemImage: "clock.arrow.circlepath") }.tag(1)
                InsightsView()
                    .tabItem { Label("Insights", systemImage: "chart.bar.fill") }.tag(2)
                PumpingView()
                    .tabItem { Label("Pumping", systemImage: "drop.circle.fill") }.tag(4)
                SettingsView()
                    .tabItem { Label("Settings", systemImage: "gearshape.fill") }.tag(3)
            }
            .preferredColorScheme(.light)
            .foregroundStyle(TeddyTheme.cocoa)
            .tint(TeddyTheme.accent)
            .toolbarBackground(TeddyTheme.paper, for: .tabBar)
            .toolbarBackground(.visible, for: .tabBar)
            .toolbarColorScheme(.light, for: .tabBar)
            .environmentObject(store)
            .sheet(item: $currentDraft) { draft in
                FeedingEditor(draft: draft).environmentObject(store).preferredColorScheme(.light)
            }
            .alert("It’s feeding time for Teddy 🧸", isPresented: $feedingReminder.isPresented) {
                Button("Log feeding") {
                    currentTab = 0
                    currentDraft = FeedingDraft()
                }
                Button("Not now", role: .cancel) { }
            } message: {
                Text(FeedingReminderMessage.text(feedings: FeedingRepository.readFeedings(), unit: FeedingRepository.readSettings().unit, birthDate: FeedingRepository.readSettings().birthDate, clinicianTarget: FeedingRepository.readSettings().clinicianTarget))
            }
            .task {
                _ = FamilySyncService.shared
                await store.refreshShared()
                await ReminderService.upgradePendingReminderSound()
            }
            .alert("Teddy’s Feedings", isPresented: Binding(
                get: { store.notificationMessage != nil },
                set: { if !$0 { store.notificationMessage = nil } })) {
                    Button("OK", role: .cancel) { store.notificationMessage = nil }
                } message: { Text(store.notificationMessage ?? "") }
            .onAppear {
                #if DEBUG
                if ProcessInfo.processInfo.arguments.contains("--review-demo") {
                    var settings = TeddySettings()
                    settings.birthDate = Calendar.current.date(byAdding: .month, value: -1, to: Date())
                    FeedingRepository.saveSettings(settings)
                    let examples = (0..<7).map { index in
                        let date = Calendar.current.date(byAdding: .day, value: -index, to: Date().addingTimeInterval(-3600))!
                        return Feeding(time: date, formulaML: VolumeUnit.ounces.toMilliliters(Double(5 + index)), breastMilkML: VolumeUnit.ounces.toMilliliters(Double(2 + index % 3)), notes: "Simulator example")
                    }
                    FeedingRepository.saveFeedings(examples)
                    var pumpingExamples: [PumpingSession] = []
                    for offset in 0..<7 {
                        for slot in 0..<3 {
                            let time = Calendar.current.date(byAdding: .day, value: -offset, to: Date().addingTimeInterval(-Double(60 + slot * 180) * 60))!
                            pumpingExamples.append(PumpingSession(endedAt: time, amountML: VolumeUnit.ounces.toMilliliters(Double(2 + slot)), notes: "Simulator example"))
                        }
                    }
                    PumpingRepository.seedForReview(pumpingExamples)
                    store.reload()
                }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-plan") { currentTab = 3 }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-topup"), let last = store.mostRecent { currentDraft = FeedingDraft.topUp(for: last) }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-editor"), let last = store.mostRecent { currentDraft = FeedingDraft(feeding: last) }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-reminder") { feedingReminder.isPresented = true }
                let arguments = ProcessInfo.processInfo.arguments
                if let index = arguments.firstIndex(of: "--screenshot-tab"),
                   arguments.indices.contains(index + 1), let value = Int(arguments[index + 1]),
                   (0...4).contains(value) { currentTab = value }
                #endif
            }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { Task { await store.refreshShared() } }
            }
        }
    }
}
