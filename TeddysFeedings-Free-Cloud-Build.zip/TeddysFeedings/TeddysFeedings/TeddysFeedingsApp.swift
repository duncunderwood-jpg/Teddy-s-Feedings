import SwiftUI
import Combine
import AppIntents
import UserNotifications
import UIKit

// Retains a notification tap even if it arrives before the SwiftUI scene is ready.
@MainActor
final class FeedingReminderPresentation: ObservableObject {
    static let shared = FeedingReminderPresentation()
    @Published var isPresented = false
}

// Keep native banners and sounds visible even when the app is open.
final class TeddyNotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let settings = FeedingRepositoryNotificationPreferences.readSoundEnabled()
        completionHandler(settings ? [.banner, .list, .sound] : [.banner, .list])
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let id = response.notification.request.identifier
        guard response.actionIdentifier == UNNotificationDefaultActionIdentifier,
              id == "teddy.nextFeeding" || id.hasPrefix("teddy.test.") else {
            completionHandler()
            return
        }
        Task { @MainActor in
            FeedingReminderPresentation.shared.isPresented = true
            completionHandler()
        }
    }

}

// The delegate is registered at application launch, before notifications can arrive.
final class TeddyAppDelegate: NSObject, UIApplicationDelegate {
    private let notificationDelegate = TeddyNotificationDelegate()

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().delegate = notificationDelegate
        return true
    }
}

// A nonisolated read is used in the notification delegate callback.
private enum FeedingRepositoryNotificationPreferences {
    static func readSoundEnabled() -> Bool {
        guard let data = UserDefaults.standard.data(forKey: FamilySyncService.storagePrefix + ".settings.v1"),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let enabled = json["reminderSoundEnabled"] as? Bool else { return true }
        return enabled
    }
}

@main
struct TeddysFeedingsApp: App {
    @UIApplicationDelegateAdaptor(TeddyAppDelegate.self) private var appDelegate
    @StateObject private var store = FeedingStore()
    @StateObject private var feedingReminder = FeedingReminderPresentation.shared
    @Environment(\.scenePhase) private var scenePhase
    @State private var currentDraft: FeedingDraft?
    @State private var currentTab = 0

    init() {
        #if DEBUG
        let arguments = ProcessInfo.processInfo.arguments
        if let index = arguments.firstIndex(of: "--screenshot-tab"),
           arguments.indices.contains(index + 1), let value = Int(arguments[index + 1]), (0...5).contains(value) {
            _currentTab = State(initialValue: value)
        }
        #endif
        TeddyShortcuts.updateAppShortcutParameters()
    }

    var body: some Scene {
        WindowGroup {
            Group {
                switch currentTab {
                case 1: HistoryView { draft in currentDraft = draft }
                case 2: InsightsView()
                case 4: PumpingView()
                case 5: FeedingGuideView()
                case 3: SettingsView()
                default: HomeView { draft in currentDraft = draft }
                }
            }
            .safeAreaInset(edge: .top, spacing: 0) {
                HStack(alignment: .center, spacing: 8) {
                    FamilySyncStatus().frame(maxWidth: .infinity, alignment: .leading)
                    FeedbackButton().fixedSize()
                }.padding(.horizontal, 16).padding(.vertical, 3)
                    .background(currentTab == 4 ? TeddyTheme.blush : TeddyTheme.cream)
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { TeddyTabBar(selection: $currentTab) }
            .buttonStyle(TeddyTextButtonStyle(color: currentTab == 4 ? TeddyTheme.rose : TeddyTheme.action))
            .preferredColorScheme(.light)
            .tint(currentTab == 4 ? TeddyTheme.rose : TeddyTheme.action)
            .toolbarBackground(TeddyTheme.paper, for: .tabBar)
            .toolbarBackground(.visible, for: .tabBar)
            .toolbarColorScheme(.light, for: .tabBar)
            .environmentObject(store)
            .sheet(item: $currentDraft) { draft in
                FeedingEditor(draft: draft).environmentObject(store).preferredColorScheme(.light)
            }
            .alert("It’s feeding time for Teddy 🧸", isPresented: $feedingReminder.isPresented) {
                Button("Log feeding") {
                    currentTab = 0
                    currentDraft = FeedingDraft()
                }
                Button("Not now", role: .cancel) { }
            } message: {
                Text(FeedingReminderMessage.text(feedings: FeedingRepository.readFeedings(), unit: FeedingRepository.readSettings().unit, birthDate: FeedingRepository.readSettings().birthDate, clinicianTarget: FeedingRepository.readSettings().clinicianTarget))
            }
            .task {
                _ = FamilySyncService.shared
                await store.refreshShared()
                await ReminderService.upgradePendingReminderSound()
            }
            .alert("Teddy’s Feedings", isPresented: Binding(
                get: { store.notificationMessage != nil },
                set: { if !$0 { store.notificationMessage = nil } })) {
                    Button("OK", role: .cancel) { store.notificationMessage = nil }
                } message: { Text(store.notificationMessage ?? "") }
            .onAppear {
                #if DEBUG
                if ProcessInfo.processInfo.arguments.contains("--review-demo") {
                    var settings = TeddySettings()
                    settings.birthDate = Calendar.current.date(byAdding: .month, value: -1, to: Date())
                    FeedingRepository.saveSettings(settings)
                    let examples = (0..<7).map { index in
                        let date = Calendar.current.date(byAdding: .day, value: -index, to: Date().addingTimeInterval(-3600))!
                        return Feeding(time: date, formulaML: VolumeUnit.ounces.toMilliliters(Double(5 + index)), breastMilkML: VolumeUnit.ounces.toMilliliters(Double(2 + index % 3)), notes: "Simulator example")
                    }
                    FeedingRepository.saveFeedings(examples)
                    var pumpingExamples: [PumpingSession] = []
                    for offset in 0..<7 {
                        for slot in 0..<3 {
                            let time = Calendar.current.date(byAdding: .day, value: -offset, to: Date().addingTimeInterval(-Double(60 + slot * 180) * 60))!
                            pumpingExamples.append(PumpingSession(endedAt: time, amountML: VolumeUnit.ounces.toMilliliters(Double(2 + slot)), notes: "Simulator example"))
                        }
                    }
                    PumpingRepository.seedForReview(pumpingExamples)
                    store.reload()
                }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-plan") { currentTab = 3 }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-topup"), let last = store.mostRecent { currentDraft = FeedingDraft.topUp(for: last) }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-editor"), let last = store.mostRecent { currentDraft = FeedingDraft(feeding: last) }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-reminder") { feedingReminder.isPresented = true }
                let arguments = ProcessInfo.processInfo.arguments
                if let index = arguments.firstIndex(of: "--screenshot-tab"),
                   arguments.indices.contains(index + 1), let value = Int(arguments[index + 1]),
                   (0...5).contains(value) { currentTab = value }
                #endif
            }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { Task { await store.refreshShared() } }
            }
        }
    }
}


private struct TeddyTabBar: View {
    @Binding var selection: Int
    private let tabs: [(Int, String, String)] = [(0, "Home", "house.fill"), (1, "History", "clock.arrow.circlepath"), (2, "Insights", "chart.bar.fill"), (4, "Pumping", "drop.fill"), (5, "Feed guide", "book.closed.fill"), (3, "Settings", "gearshape.fill")]
    var body: some View {
        HStack(spacing: 0) {
            ForEach(tabs, id: \.0) { tab in
                Button { selection = tab.0 } label: {
                    VStack(spacing: 4) {
                        Group {
                            if tab.0 == 4 { PumpIcon().frame(width: 24, height: 24) }
                            else { Image(systemName: tab.2).font(.system(size: 22, weight: .semibold)).frame(height: 24) }
                        }
                        Text(tab.1).font(.system(size: 10, weight: .semibold, design: .rounded)).lineLimit(1).minimumScaleFactor(0.7)
                    }.foregroundStyle(selection == tab.0 ? (tab.0 == 4 ? TeddyTheme.rose : TeddyTheme.action) : TeddyTheme.muted)
                        .frame(maxWidth: .infinity, minHeight: 57)
                        .background(selection == tab.0 ? (tab.0 == 4 ? TeddyTheme.paleRose : TeddyTheme.paleSage) : .clear, in: RoundedRectangle(cornerRadius: 16))
                }.buttonStyle(.plain).accessibilityAddTraits(selection == tab.0 ? [.isSelected] : [])
                    .accessibilityLabel(tab.0 == 5 ? "Feeding guide" : tab.1)
            }
        }.padding(6).background(TeddyTheme.paper, in: RoundedRectangle(cornerRadius: 23))
            .overlay(RoundedRectangle(cornerRadius: 23).strokeBorder(TeddyTheme.accent.opacity(0.15)))
            .padding(.horizontal, 8).padding(.bottom, 3).background(TeddyTheme.cream.opacity(0.97))
    }
}
