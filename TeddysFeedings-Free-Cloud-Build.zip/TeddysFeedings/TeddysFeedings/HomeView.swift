import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: FeedingStore
    let openEditor: (FeedingDraft) -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(alignment: .center, spacing: 14) {
                        BearFace(size: 75)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("THEODORE EMMONS UNDERWOOD")
                                .font(.system(size: 10, weight: .bold, design: .rounded))
                                .foregroundStyle(TeddyTheme.muted)
                            Text("\(store.settings.babyName)’s Feedings")
                                .font(.system(size: 27, weight: .heavy, design: .rounded))
                                .foregroundStyle(TeddyTheme.cocoa)
                                .minimumScaleFactor(0.75).lineLimit(1)
                        }
                        Spacer(minLength: 0)
                    }.padding(.top, 14)

                    TimelineView(.periodic(from: .now, by: 60)) { context in
                        TeddyCard {
                            HStack(alignment: .top) {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("TIME SINCE LAST FEED")
                                        .font(.system(size: 11, weight: .bold, design: .rounded))
                                        .tracking(1.3).foregroundStyle(TeddyTheme.muted)
                                    Text(store.mostRecent.map { FeedingMath.intervalText(context.date.timeIntervalSince($0.lastMilkAt)) } ?? "—")
                                        .font(.system(size: 44, weight: .heavy, design: .rounded))
                                        .foregroundStyle(TeddyTheme.cocoa)
                                    if let last = store.mostRecent {
                                        Text("Last fed at \(last.lastMilkAt.shortFeedingTime)")
                                            .font(.system(size: 14, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                                    } else {
                                        Text("Log your first feeding to start")
                                            .font(.system(size: 14, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                                    }
                                }
                                Spacer()
                                Image(systemName: "clock")
                                    .font(.system(size: 26, weight: .light))
                                    .foregroundStyle(TeddyTheme.accent)
                                    .padding(13).background(TeddyTheme.paleHoney, in: Circle())
                            }
                            if let next = store.expectedNext {
                                Divider().overlay(TeddyTheme.paleHoney)
                                HStack(spacing: 8) {
                                    Image(systemName: "bell.badge.fill")
                                    Text(next <= context.date
                                         ? "Reminder is due — check feeding cues"
                                         : "Reminder around \(next.shortFeedingTime)")
                                    Spacer()
                                }
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .foregroundStyle(TeddyTheme.sage)
                            }
                        }
                    }

                    Button { openEditor(FeedingDraft()) } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "plus.circle.fill").font(.system(size: 25))
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Log a feeding").font(.system(size: 19, weight: .bold, design: .rounded))
                                Text("Formula, breast milk, or both")
                                    .font(.system(size: 12, design: .rounded)).opacity(0.85)
                            }
                            Spacer()
                            Image(systemName: "arrow.right").fontWeight(.bold)
                        }
                        .foregroundStyle(.white).padding(21)
                        .background(TeddyTheme.accent, in: RoundedRectangle(cornerRadius: 23))
                    }.buttonStyle(.plain).accessibilityHint("Open feeding form")

                    TeddyCard {
                        Label("Next bottle", systemImage: "heart.text.clipboard")
                            .font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        Text(FeedingPlan.message(feedings: store.feedings, unit: store.settings.unit, birthDate: store.settings.birthDate, target: store.settings.clinicianTarget, concise: true))
                            .font(.system(.subheadline, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        if let last = store.mostRecent {
                            Button("Still hungry? Log a top-up") { openEditor(FeedingDraft.topUp(for: last)) }
                                .font(.system(.subheadline, design: .rounded, weight: .semibold))
                            Text("Adds milk to the same feeding; updates the reminder from the top-up time.")
                                .font(.caption).foregroundStyle(TeddyTheme.muted)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        sectionHeading("Today at a glance", caption: Date.now.formatted(.dateTime.weekday(.wide).month(.abbreviated).day()))
                        HStack(spacing: 12) {
                            metricCard(value: "\(store.today.count)", label: "Feedings", icon: "drop.fill")
                            metricCard(value: store.settings.unit.display(store.todayTotalML), label: "Total milk", icon: "baby-bottle")
                        }
                        HStack(spacing: 12) {
                            milkCard("Formula", value: store.todayFormulaML, color: TeddyTheme.honey)
                            milkCard("Breast milk", value: store.todayBreastML, color: TeddyTheme.sage)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        sectionHeading("Quick start", caption: "Opens a prefilled log")
                        HStack(spacing: 10) {
                            quickButton(title: "2 oz", subtitle: "Formula", milk: .formula, ounces: 2)
                            quickButton(title: "3 oz", subtitle: "Formula", milk: .formula, ounces: 3)
                            quickButton(title: "2 oz", subtitle: "Breast milk", milk: .breast, ounces: 2)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        sectionHeading("Recent feedings", caption: "Your latest entries")
                        TeddyCard {
                            if store.feedings.isEmpty {
                                TeddyEmptyState(title: "Ready for Teddy’s first bottle", message: "Log a feeding to begin his little story.")
                            } else {
                                ForEach(Array(store.feedings.prefix(3).enumerated()), id: \.element.id) { index, feeding in
                                    Button { openEditor(FeedingDraft(feeding: feeding)) } label: {
                                        FeedingRow(feeding: feeding, unit: store.settings.unit,
                                                   previous: store.feedings.dropFirst(index + 1).first)
                                    }.buttonStyle(.plain)
                                    if index < min(3, store.feedings.count) - 1 { Divider() }
                                }
                            }
                        }
                    }
                    Text("Gentle reminders, not a medical feeding schedule. Follow Teddy's cues and his pediatrician's advice.")
                        .font(.system(size: 12, design: .rounded))
                        .foregroundStyle(TeddyTheme.muted).padding(.horizontal, 4).padding(.bottom, 12)
                }.padding(.horizontal, 18)
            }
            .scrollBounceBehavior(.always)
            .refreshable { store.reload() }
            .background(TeddyTheme.cream.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
        }
    }
    private func sectionHeading(_ title: String, caption: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.system(size: 19, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
            Spacer()
            Text(caption).font(.system(size: 11, design: .rounded)).foregroundStyle(TeddyTheme.muted)
        }
    }
    private func metricCard(value: String, label: String, icon: String) -> some View {
        TeddyCard {
            Group {
                if icon == "baby-bottle" { BottleIcon().frame(width: 18, height: 27) }
                else { Image(systemName: icon).font(.system(size: 20)) }
            }.foregroundStyle(TeddyTheme.accent).frame(height: 28)
            Text(value).font(.system(size: 25, weight: .heavy, design: .rounded))
                .minimumScaleFactor(0.6).lineLimit(1).foregroundStyle(TeddyTheme.cocoa)
            Text(label).font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
        }
    }
    private func milkCard(_ title: String, value: Double, color: Color) -> some View {
        HStack(spacing: 9) {
            Circle().fill(color).frame(width: 10, height: 10)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 11, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                Text(store.settings.unit.display(value))
                    .font(.system(size: 15, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
            }
            Spacer(minLength: 0)
        }.padding(13).frame(maxWidth: .infinity, alignment: .leading)
            .background(TeddyTheme.paper, in: RoundedRectangle(cornerRadius: 18))
    }
    private enum QuickMilk { case formula, breast }
    private func quickButton(title: String, subtitle: String, milk: QuickMilk, ounces: Double) -> some View {
        Button {
            let ml = ounces * VolumeUnit.ounces.millilitersPerUnit
            openEditor(FeedingDraft(formulaML: milk == .formula ? ml : 0,
                                    breastMilkML: milk == .breast ? ml : 0))
        } label: {
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.system(size: 20, weight: .heavy, design: .rounded))
                Text(subtitle).font(.system(size: 11, design: .rounded))
            }
            .foregroundStyle(TeddyTheme.cocoa).frame(maxWidth: .infinity, alignment: .leading)
            .padding(13).background(TeddyTheme.paleHoney.opacity(0.55), in: RoundedRectangle(cornerRadius: 17))
        }.buttonStyle(.plain)
    }
}
