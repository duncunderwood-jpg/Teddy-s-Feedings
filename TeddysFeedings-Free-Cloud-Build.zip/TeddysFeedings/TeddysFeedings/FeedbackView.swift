import SwiftUI
import MessageUI
import UIKit

struct FeedbackButton: View {
    @State private var showing = false
    var body: some View {
        Button { showing = true } label: {
            Label("Feedback", systemImage: "bubble.left.and.text.bubble.right.fill")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(TeddyTheme.action).padding(.horizontal, 10).frame(minHeight: 44)
                .background(TeddyTheme.action.opacity(0.08), in: Capsule())
        }.buttonStyle(.plain).accessibilityHint("Write an email to Duncan")
            .sheet(isPresented: $showing) { FeedbackView() }
    }
}
struct FeedbackView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var category = "Suggestion"
    @State private var feedback = ""
    @State private var showingMail = false
    @State private var status: String?
    private let address = "duncunderwood@gmail.com"
    private var subject: String { "Teddy’s Feedings — \(category)" }
    private var bodyText: String { feedback.trimmingCharacters(in: .whitespacesAndNewlines) + "\n\nTeddy’s Feedings \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "")" }
    var body: some View {
        NavigationStack {
            Form {
                Section("A little note to make things better") {
                    Picker("About", selection: $category) { ForEach(["Suggestion", "Something isn’t working", "Something I love"], id: \.self) { Text($0) } }
                    TextEditor(text: $feedback).frame(minHeight: 150).accessibilityLabel("Your feedback")
                    Text("Your email draft goes to \(address). Review it and tap Send in your mail app. Feeding records are not attached.").font(.caption)
                }
                Section {
                    Button("Email feedback", systemImage: "envelope.fill") { emailFeedback() }.disabled(feedback.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    if let status {
                        Text(status).font(.caption)
                        Text(address).textSelection(.enabled)
                        ShareLink("Share feedback using another app", item: subject + "\n\n" + bodyText)
                    }
                }
            }
            .navigationTitle("Feedback").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } } }
            .sheet(isPresented: $showingMail) {
                TeddyMailComposer(to: address, subject: subject, messageBody: bodyText) { result, error in
                    showingMail = false
                    if error != nil { status = "Mail could not send this message. Your feedback is still here." }
                    else if result == .sent { status = "Your message was handed to Mail to send. Thank you!" }
                    else if result == .saved { status = "Your email was saved as a draft in Mail." }
                }
            }
        }.tint(TeddyTheme.action).buttonStyle(TeddyTextButtonStyle()).preferredColorScheme(.light)
    }
    private func emailFeedback() {
        if MFMailComposeViewController.canSendMail() { showingMail = true; return }
        var url = URLComponents(); url.scheme = "mailto"; url.path = address
        url.queryItems = [URLQueryItem(name: "subject", value: subject), URLQueryItem(name: "body", value: bodyText)]
        guard let link = url.url else { return }
        UIApplication.shared.open(link, options: [:]) { opened in
            status = opened ? "Your email app opened a draft. Tap Send there to send feedback." : "No email app is available. Set up Mail or use Share feedback below."
        }
    }
}
struct TeddyMailComposer: UIViewControllerRepresentable {
    let to: String; let subject: String; let messageBody: String
    let completion: (MFMailComposeResult, Error?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion) }
    func makeUIViewController(context: Context) -> MFMailComposeViewController {
        let controller = MFMailComposeViewController(); controller.mailComposeDelegate = context.coordinator
        controller.setToRecipients([to]); controller.setSubject(subject); controller.setMessageBody(messageBody, isHTML: false)
        return controller
    }
    func updateUIViewController(_ controller: MFMailComposeViewController, context: Context) {}
    final class Coordinator: NSObject, MFMailComposeViewControllerDelegate {
        let completion: (MFMailComposeResult, Error?) -> Void
        init(_ completion: @escaping (MFMailComposeResult, Error?) -> Void) { self.completion = completion }
        func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) { completion(result, error) }
    }
}
