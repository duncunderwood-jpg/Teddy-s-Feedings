import SwiftUI
import AVFoundation
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var store: FeedingStore
    @State private var rattlePlayer: AVAudioPlayer?
    @State private var showingFeedingPlan = false
    #if DEBUG
    @State private var showingFamilyReview = ProcessInfo.processInfo.arguments.contains("--screenshot-sharing")
    #else
    @State private var showingFamilyReview = false
    #endif
    @State private var editingName: String = ""
    @State private var birthDateEnabled = false
    @State private var selectedBirthDate = Date()
    @State private var exportFile: URL?
    @State private var notificationTestMessage: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Teddy's little world")
                            .font(.system(size: 27, weight: .heavy, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        Text("Make the tracker feel like home")
                            .font(.system(size: 13, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                    }.padding(.top, 16)
                    TeddyCard {
                        HStack(spacing: 12) {
                            BearFace(size: 56)
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Theodore Emmons Underwood")
                                    .font(.system(.headline, design: .rounded, weight: .bold))
                                    .foregroundStyle(TeddyTheme.cocoa)
                                Text("Our little Teddy")
                                    .font(.system(.subheadline, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                            }
                        }
                        settingTitle("Baby profile", icon: "teddybear.fill")
                        TextField("Baby's nickname", text: $editingName)
                            .textInputAutocapitalization(.words)
                            .foregroundStyle(TeddyTheme.cocoa)
                            .onSubmit { saveName() }
                            .padding(12).background(TeddyTheme.cream, in: RoundedRectangle(cornerRadius: 12))
                        HStack {
                            Text("Birthdate (optional)")
                            Spacer()
                            Toggle("Birthdate", isOn: $birthDateEnabled).labelsHidden()
                                .tint(TeddyTheme.sage)
                                .onChange(of: birthDateEnabled) { _, enabled in
                                    if enabled != (store.settings.birthDate != nil) {
                                        store.updateSettings { $0.birthDate = enabled ? selectedBirthDate : nil }
                                    }
                                }
                        }
                        if birthDateEnabled {
                            DatePicker("Born on", selection: $selectedBirthDate, in: ...Date(), displayedComponents: .date)
                                .onChange(of: selectedBirthDate) { _, value in
                                    if birthDateEnabled && store.settings.birthDate != value { store.updateSettings { $0.birthDate = value } }
                                }
                        }
                    }
                    TeddyCard {
                        settingTitle("Caregivers", icon: "person.2.fill")
                        NavigationLink { FamilySharingView() } label: {
                            Label("Add caregiver", systemImage: "person.badge.plus")
                                .font(.system(.subheadline, design: .rounded, weight: .bold)).foregroundStyle(.white)
                                .frame(maxWidth: .infinity, minHeight: 48)
                                .background(TeddyTheme.action, in: RoundedRectangle(cornerRadius: 15))
                        }.buttonStyle(.plain)
                        Text("Invite someone or manage your shared journal.").font(.caption).foregroundStyle(TeddyTheme.muted)
                        FamilySyncStatus()
                        Text("Connect caregivers to share feedings and pumping sessions.").font(.caption).foregroundStyle(TeddyTheme.muted)
                    }
                    TeddyCard {
                        settingTitle("Feeding measurements", icon: "ruler")
                        TeddySegmentedPicker(label: "Milk volume unit", selection: Binding(
                            get: { store.settings.unit },
                            set: { unit in store.updateSettings { $0.unit = unit } }),
                            options: [("Ounces (oz)", VolumeUnit.ounces), ("Milliliters (mL)", VolumeUnit.milliliters)])
                        Text("All entries are stored in mL, so changing units won't change your feeding history.")
                            .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                    }
                    TeddyCard {
                        settingTitle("Pediatrician’s bottle target", icon: "heart.text.clipboard")
                        if let target = store.settings.clinicianTarget, target.isValid {
                            Text(target.display(unit: store.settings.unit) + " total milk per feeding")
                                .font(.system(.headline, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        } else {
                            Text("Optional: enter a target your pediatrician has given you.")
                                .font(.system(.subheadline, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        }
                        Button("Edit feeding target") { showingFeedingPlan = true }
                        Text("Your saved target replaces the general age range. Recent bottle amounts remain a history reference.")
                            .font(.caption).foregroundStyle(TeddyTheme.muted)
                    }
                    TeddyCard {
                        settingTitle("Gentle reminders", icon: "bell.badge")
                        Toggle("Enable feeding check-ins", isOn: Binding(
                            get: { store.settings.remindersEnabled },
                            set: { enabled in Task { await store.setReminders(enabled) } }))
                            .tint(TeddyTheme.sage)
                        if store.settings.remindersEnabled {
                            Picker("Check in after", selection: Binding(
                                get: { store.settings.reminderIntervalMinutes },
                                set: { interval in store.updateSettings { $0.reminderIntervalMinutes = interval } })) {
                                    Text("1.5 hours").tag(90)
                                    Text("2 hours").tag(120)
                                    Text("2.5 hours").tag(150)
                                    Text("3 hours").tag(180)
                                    Text("3.5 hours").tag(210)
                                    Text("4 hours").tag(240)
                                }
                            Toggle("Play soft lullaby sound", isOn: Binding(
                                get: { store.settings.reminderSoundEnabled },
                                set: { value in store.updateSettings { $0.reminderSoundEnabled = value } }))
                                .tint(TeddyTheme.sage)
                            Text("Feeding reminders show as standard iOS banners and Lock Screen notifications when allowed in iPhone Settings. Sounds play if both the app setting and iPhone sound settings allow them.")
                                .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        }
                        Button {
                            if let url = Bundle.main.url(forResource: "TeddyRattle", withExtension: "wav"),
                               let player = try? AVAudioPlayer(contentsOf: url) {
                                rattlePlayer = player
                                player.play()
                            }
                        } label: {
                            Label("Preview soft lullaby sound", systemImage: "speaker.wave.2.fill")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .foregroundStyle(TeddyTheme.accent)
                        }
                        Text("Tap a feeding notification to open Teddy’s feeding-time message. Choose Log feeding to enter his bottle, or Not now to dismiss it.")
                            .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        Text("The message includes his last bottle and a general total-milk amount guide based on his birth date. It does not recommend separate amounts of formula and breast milk. Follow his pediatrician’s feeding plan, especially for prematurity or growth concerns.")
                            .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        Link("Bottle amount guide — Nemours KidsHealth", destination: URL(string: "https://kidshealth.org/en/parents/feed13m.html")!)
                        Link("Newborn bottle guide — American Academy of Pediatrics", destination: URL(string: "https://www.healthychildren.org/English/ages-stages/baby/feeding-nutrition/Pages/How-Often-and-How-Much-Should-Your-Baby-Eat.aspx")!)
                        Button {
                            Task {
                                let success = await ReminderService.scheduleTestNotification(sound: store.settings.reminderSoundEnabled)
                                notificationTestMessage = success
                                    ? "A test notification is scheduled for five seconds from now. Try locking your phone to check the banner and sound."
                                    : "Notifications could not be scheduled. Check Settings > Notifications > Teddy’s Feedings."
                            }
                        } label: {
                            Label("Send test notification (5 seconds)", systemImage: "bell.badge.fill")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .foregroundStyle(TeddyTheme.accent)
                        }
                        if let notificationTestMessage {
                            Text(notificationTestMessage)
                                .font(.system(size: 12, design: .rounded))
                                .foregroundStyle(TeddyTheme.muted)
                        }
                        Button {
                            guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                            UIApplication.shared.open(url)
                        } label: {
                            Label("Open iPhone notification settings", systemImage: "gearshape")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .foregroundStyle(TeddyTheme.accent)
                        }
                        Text("Each logged feeding resets the check-in. Reminders are optional cues, not medical feeding schedules. Focus, Silent Mode, or disabled notification permissions may suppress alerts or sound.")
                            .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                    }
                    TeddyCard {
                        settingTitle("Hands-free with Siri", icon: "waveform")
                        Text("Pumping: say ‘Hey Siri, Log pumping in Teddy’s Feedings’, then ‘I pumped 3 ounces’. The Pumping tab explains the shorter personal shortcut ‘Log pumping’.")
                            .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        Text("Say: “Hey Siri, Teddy drank in Teddy's Feedings.”")
                            .font(.system(size: 14, weight: .semibold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        Text("Then say: “Teddy drank 3 ounces of formula at 8:15 PM.” Siri confirms the milk, amount, date, and time after saving.")
                            .font(.system(size: 13, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        Text("Shorter trigger: In Apple Shortcuts, create a shortcut named ‘Teddy drank’. Add Dictate Text, then this app's ‘Teddy drank’ action. Set ‘What did Teddy drink?’ to Dictated Text. Say ‘Hey Siri, Teddy drank’, pause for dictation, then give the bottle details. Finish speaking and wait for confirmation.")
                            .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        Text("Apple requires the app name in automatic trigger phrases. A single sentence with changing amount, milk type, and time is not guaranteed to trigger this app. Include ounces or milliliters and AM or PM for the clearest result. In iPhone Settings, search Siri Responses and choose Prefer Spoken Responses if you want audible confirmation.")
                            .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                    }
                    TeddyCard {
                        settingTitle("Your data", icon: "square.and.arrow.up")
                        Text("Local-only entries stay on this phone. When family sharing is connected, shared records are stored in your private Firebase family journal. Export a backup before deleting the app or changing phones.")
                            .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        if let exportFile {
                            ShareLink(item: exportFile) {
                                Label("Share feeding history as CSV", systemImage: "square.and.arrow.up")
                                    .font(.system(size: 14, weight: .bold, design: .rounded))
                                    .foregroundStyle(TeddyTheme.accent)
                            }
                        } else {
                            Button("Prepare CSV export") { exportFile = store.exportCSV() }
                                .foregroundStyle(TeddyTheme.accent)
                        }
                        Text("To update your export after logging more feedings, tap Refresh export.")
                            .font(.system(size: 11, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        Button("Refresh export") { exportFile = store.exportCSV() }
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                    }

                }.padding(.horizontal, 18).padding(.bottom, 20)
            }
            .background(TeddyTheme.cream.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .onAppear {
                editingName = store.settings.babyName
                selectedBirthDate = store.settings.birthDate ?? .now
                birthDateEnabled = store.settings.birthDate != nil
                exportFile = store.exportCSV()
                #if DEBUG
                if ProcessInfo.processInfo.arguments.contains("--screenshot-plan") { showingFeedingPlan = true }
                if ProcessInfo.processInfo.arguments.contains("--screenshot-sharing") { showingFamilyReview = true }
                #endif
            }
            .sheet(isPresented: $showingFeedingPlan) {
                FeedingPlanEditor().environmentObject(store).preferredColorScheme(.light)
            }
            .sheet(isPresented: $showingFamilyReview) { NavigationStack { FamilySharingView() }.preferredColorScheme(.light) }
            .onChange(of: editingName) { _, _ in saveName() }
        }
    }
    private func saveName() {
        let value = editingName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty, value != store.settings.babyName else { return }
        store.updateSettings { $0.babyName = String(value.prefix(30)) }
    }
    private func settingTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(size: 17, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
    }
}


private struct FeedingPlanEditor: View {
    @EnvironmentObject private var store: FeedingStore
    @Environment(\.dismiss) private var dismiss
    @State private var lower = ""
    @State private var upper = ""
    @State private var unit: VolumeUnit = .ounces
    private var target: ClinicianFeedingTarget? {
        guard let low = Double(lower.replacingOccurrences(of: ",", with: ".")),
              let high = Double(upper.replacingOccurrences(of: ",", with: ".")) else { return nil }
        let result = ClinicianFeedingTarget(minimumML: unit.toMilliliters(low), maximumML: unit.toMilliliters(high))
        return result.isValid ? result : nil
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("Your pediatrician’s recommended total milk") {
                    LabeledContent("Minimum (\(unit.symbol))") {
                        TextField("0", text: $lower).keyboardType(.decimalPad).multilineTextAlignment(.trailing)
                    }
                    LabeledContent("Maximum (\(unit.symbol))") {
                        TextField("0", text: $upper).keyboardType(.decimalPad).multilineTextAlignment(.trailing)
                    }
                    Text("Use the same amount in both fields for a single target. Enter a plan provided by his clinician; the app does not prescribe this target.")
                        .font(.caption).foregroundStyle(TeddyTheme.muted)
                    if target == nil && (!lower.isEmpty || !upper.isEmpty) {
                        Text("Enter positive amounts with the maximum at least the minimum.").font(.caption).foregroundStyle(.red)
                    }
                }
                Button("Save target") {
                    guard let target else { return }
                    store.updateSettings { $0.clinicianTarget = target }
                    dismiss()
                }.disabled(target == nil)
                if store.settings.clinicianTarget != nil {
                    Button("Remove target and use age guide", role: .destructive) {
                        store.updateSettings { $0.clinicianTarget = nil }; dismiss()
                    }
                }
            }
            .navigationTitle("Feeding target").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Cancel") { dismiss() } } }
            .onAppear {
                unit = store.settings.unit
                if let target = store.settings.clinicianTarget {
                    lower = unit.fromMilliliters(target.minimumML).formatted(.number.precision(.fractionLength(0...3)))
                    upper = unit.fromMilliliters(target.maximumML).formatted(.number.precision(.fractionLength(0...3)))
                }
            }
        }.tint(TeddyTheme.accent)
    }
}
