import SwiftUI

struct FeedingEditor: View {
    @EnvironmentObject private var store: FeedingStore
    @Environment(\.dismiss) private var dismiss
    let draft: FeedingDraft
    @State private var date: Date = .now
    @State private var formulaText = ""
    @State private var breastText = ""
    @State private var notes = ""
    @State private var trackOffered = false
    @State private var offeredFormulaText = ""
    @State private var offeredBreastText = ""
    @State private var saveFailed = false
    @State private var isSaving = false
    @FocusState private var focusedField: Field?
    private enum Field { case formula, breast, offeredFormula, offeredBreast }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(spacing: 12) {
                        BearFace(size: 64)
                        VStack(alignment: .leading, spacing: 5) {
                            Text(draft.topUpForID != nil ? "A little top-up for Teddy" : (draft.editingID == nil ? "A little milk for Teddy" : "Update Teddy's feeding"))
                                .font(.system(size: 21, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                            Text("Enter how much Teddy actually drank")
                                .font(.system(size: 12, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        }
                    }
                    TeddyCard {
                        Label("Formula", systemImage: "drop.fill")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(TeddyTheme.cocoa)
                        numberInput(text: $formulaText, field: .formula)
                        amountPresets(for: .formula)
                    }
                    TeddyCard {
                        Label("Expressed breast milk", systemImage: "heart.fill")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(TeddyTheme.cocoa)
                        numberInput(text: $breastText, field: .breast)
                        amountPresets(for: .breast)
                    }
                    TeddyCard {
                        Toggle("Track how much was offered", isOn: $trackOffered).tint(TeddyTheme.accent)
                        Text("Milk totals count what Teddy actually drank. Offered amounts are optional and saved separately.")
                            .font(.caption).foregroundStyle(TeddyTheme.muted)
                        if trackOffered {
                            Text("Formula offered (\(store.settings.unit.symbol))").font(.subheadline).foregroundStyle(TeddyTheme.cocoa)
                            TextField("Formula offered (\(store.settings.unit.symbol))", text: $offeredFormulaText).keyboardType(.decimalPad).focused($focusedField, equals: .offeredFormula)
                            Text("Breast milk offered (\(store.settings.unit.symbol))").font(.subheadline).foregroundStyle(TeddyTheme.cocoa)
                            TextField("Breast milk offered (\(store.settings.unit.symbol))", text: $offeredBreastText).keyboardType(.decimalPad).focused($focusedField, equals: .offeredBreast)
                            if !offeredIsValid { Text("Offered amounts must be at least the amounts actually drank for each milk type.").font(.caption).foregroundStyle(.red) }
                        }
                    }
                    TeddyCard {
                        Label("When did Teddy eat?", systemImage: "clock")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(TeddyTheme.cocoa)
                        DatePicker("Feeding time", selection: $date, in: ...Date(), displayedComponents: [.date, .hourAndMinute])
                            .datePickerStyle(.compact).tint(TeddyTheme.accent)
                    }
                    TeddyCard {
                        Label("Notes (optional)", systemImage: "note.text")
                            .font(.system(size: 16, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                        TextField("e.g. finished bottle, sleepy afterward", text: $notes, axis: .vertical)
                            .lineLimit(2...4).font(.system(size: 14, design: .rounded))
                    }
                    HStack {
                        Text("Total")
                        Spacer()
                        Text(store.settings.unit.display(totalML))
                            .font(.system(size: 20, weight: .heavy, design: .rounded))
                    }
                    .foregroundStyle(TeddyTheme.cocoa).padding(.horizontal, 7)
                    Button(action: save) {
                        Text(draft.topUpForID != nil ? "Save top-up" : (draft.editingID == nil ? "Save feeding" : "Save changes"))
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .frame(maxWidth: .infinity).padding(17)
                            .background(canSave ? TeddyTheme.accent : TeddyTheme.muted.opacity(0.4),
                                        in: RoundedRectangle(cornerRadius: 18)).foregroundStyle(.white)
                    }
                    .disabled(!canSave).buttonStyle(.plain).padding(.bottom, 14)
                }.padding(18)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(TeddyTheme.cream.ignoresSafeArea())
            .navigationTitle(draft.topUpForID != nil ? "Log top-up" : (draft.editingID == nil ? "Log feeding" : "Edit feeding"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { Button("Cancel") { dismiss() } }
                ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { focusedField = nil } }
            }
            .onAppear(perform: populate)
            .alert("Feeding wasn’t saved", isPresented: $saveFailed) { Button("OK", role: .cancel) {} } message: {
                Text("Check the amounts and time. The original feeding may have changed or been deleted. Your entered amounts are still here.")
            }
        }
    }
    private var formulaML: Double {
        store.settings.unit.toMilliliters(Double(formulaText.replacingOccurrences(of: ",", with: ".")) ?? 0)
    }
    private var breastML: Double {
        store.settings.unit.toMilliliters(Double(breastText.replacingOccurrences(of: ",", with: ".")) ?? 0)
    }
    private var totalML: Double { formulaML + breastML }
    private func enteredML(_ text: String) -> Double? {
        guard let value = Double(text.replacingOccurrences(of: ",", with: ".")), value.isFinite, value >= 0 else { return nil }
        return store.settings.unit.toMilliliters(value)
    }
    private var offeredIsValid: Bool {
        guard trackOffered else { return true }
        guard let formula = enteredML(offeredFormulaText.isEmpty ? "0" : offeredFormulaText),
              let breast = enteredML(offeredBreastText.isEmpty ? "0" : offeredBreastText) else { return false }
        return formula >= formulaML && breast >= breastML && formula + breast <= 1000
    }
    private var canSave: Bool {
        !isSaving && enteredML(formulaText.isEmpty ? "0" : formulaText) != nil && enteredML(breastText.isEmpty ? "0" : breastText) != nil && offeredIsValid && totalML > 0 && totalML <= 1000 && date <= Date().addingTimeInterval(60)
    }
    private func populate() {
        date = draft.time
        formulaText = draft.formulaML > 0 ? formatNumber(store.settings.unit.fromMilliliters(draft.formulaML)) : ""
        breastText = draft.breastMilkML > 0 ? formatNumber(store.settings.unit.fromMilliliters(draft.breastMilkML)) : ""
        notes = draft.notes
        trackOffered = draft.offeredFormulaML != nil && draft.offeredBreastMilkML != nil
        offeredFormulaText = draft.offeredFormulaML.map { formatNumber(store.settings.unit.fromMilliliters($0)) } ?? ""
        offeredBreastText = draft.offeredBreastMilkML.map { formatNumber(store.settings.unit.fromMilliliters($0)) } ?? ""
    }
    private func formatNumber(_ value: Double) -> String {
        value.formatted(.number.precision(.fractionLength(0...2)))
    }
    private func numberInput(text: Binding<String>, field: Field) -> some View {
        HStack(spacing: 8) {
            TextField("0", text: text)
                .keyboardType(.decimalPad)
                .focused($focusedField, equals: field)
                .font(.system(size: 31, weight: .semibold, design: .rounded))
                .foregroundStyle(TeddyTheme.cocoa)
                .accessibilityLabel(field == .formula ? "Formula volume" : "Breast milk volume")
            Text(store.settings.unit.symbol)
                .font(.system(size: 18, weight: .medium, design: .rounded))
                .foregroundStyle(TeddyTheme.muted)
        }.padding(.vertical, 5)
    }
    private func amountPresets(for field: Field) -> some View {
        HStack(spacing: 8) {
            Text("ADD").font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(TeddyTheme.muted)
            ForEach(store.settings.unit == .ounces ? [0.5, 1, 2] : [15, 30, 60], id: \.self) { amount in
                Button("+\(amount.formatted(.number.precision(.fractionLength(0...1))))") {
                    let current = field == .formula ? formulaML : breastML
                    let mlDelta = store.settings.unit.toMilliliters(amount)
                    let updated = formatNumber(store.settings.unit.fromMilliliters(current + mlDelta))
                    if field == .formula { formulaText = updated } else { breastText = updated }
                }
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .padding(.horizontal, 13).padding(.vertical, 8)
                .background(TeddyTheme.paleHoney, in: Capsule())
                .foregroundStyle(TeddyTheme.cocoa)
                .buttonStyle(.plain)
                .accessibilityLabel("Add \(amount) \(store.settings.unit.symbol)")
            }
        }
    }
    private func save() {
        guard canSave else { return }
        var result = draft
        result.time = date; result.formulaML = formulaML; result.breastMilkML = breastML; result.notes = notes
        result.offeredFormulaML = trackOffered ? enteredML(offeredFormulaText.isEmpty ? "0" : offeredFormulaText) : nil
        result.offeredBreastMilkML = trackOffered ? enteredML(offeredBreastText.isEmpty ? "0" : offeredBreastText) : nil
        isSaving = true
        if store.save(result) { dismiss() }
        else { isSaving = false; saveFailed = true }
    }
}
