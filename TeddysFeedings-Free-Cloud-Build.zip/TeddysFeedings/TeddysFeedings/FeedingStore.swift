import Combine
import Foundation
import UserNotifications

extension Notification.Name {
    static let teddyFeedingsChanged = Notification.Name("teddyFeedingsChanged")
}

@MainActor
enum FeedingRepository {
    private static let feedingsKey = "teddy.feedings.v1"
    private static let settingsKey = "teddy.settings.v1"

    static func readFeedings() -> [Feeding] {
        guard let data = UserDefaults.standard.data(forKey: feedingsKey),
              let decoded = try? JSONDecoder().decode([Feeding].self, from: data) else { return [] }
        return decoded.sorted { $0.time > $1.time }
    }
    static func readSettings() -> TeddySettings {
        guard let data = UserDefaults.standard.data(forKey: settingsKey),
              let decoded = try? JSONDecoder().decode(TeddySettings.self, from: data) else { return TeddySettings() }
        return decoded
    }
    static func saveFeedings(_ feedings: [Feeding]) {
        guard let data = try? JSONEncoder().encode(feedings) else { return }
        UserDefaults.standard.set(data, forKey: feedingsKey)
        NotificationCenter.default.post(name: .teddyFeedingsChanged, object: nil)
        reschedule()
    }
    static func saveSettings(_ settings: TeddySettings) {
        guard let data = try? JSONEncoder().encode(settings) else { return }
        UserDefaults.standard.set(data, forKey: settingsKey)
        NotificationCenter.default.post(name: .teddyFeedingsChanged, object: nil)
        reschedule()
    }
    static func insert(_ feeding: Feeding) {
        guard feeding.totalML > 0, feeding.totalML <= 1000, feeding.time <= Date().addingTimeInterval(60) else { return }
        var all = readFeedings()
        if let index = all.firstIndex(where: { $0.id == feeding.id }) { all[index] = feeding }
        else { all.append(feeding) }
        saveFeedings(all)
    }
    private static func reschedule() {
        let settings = readSettings()
        let latest = readFeedings().first?.time
        Task { await ReminderService.schedule(settings: settings, lastFeeding: latest) }
    }
}

@MainActor
final class FeedingStore: ObservableObject {
    @Published private(set) var feedings = FeedingRepository.readFeedings()
    @Published private(set) var settings = FeedingRepository.readSettings()
    @Published var notificationMessage: String? = nil
    private var observer: NSObjectProtocol?

    init() {
        observer = NotificationCenter.default.addObserver(forName: .teddyFeedingsChanged,
                                                           object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.reload() }
        }
    }
    func reload() {
        feedings = FeedingRepository.readFeedings()
        settings = FeedingRepository.readSettings()
    }
    func save(_ draft: FeedingDraft) { FeedingRepository.insert(draft.feeding()); reload() }
    func delete(_ feeding: Feeding) {
        FeedingRepository.saveFeedings(feedings.filter { $0.id != feeding.id })
        reload()
    }
    func updateSettings(_ change: (inout TeddySettings) -> Void) {
        var copy = settings
        change(&copy)
        FeedingRepository.saveSettings(copy)
        reload()
    }
    func setReminders(_ enabled: Bool) async {
        if enabled {
            let accepted = await ReminderService.askPermission()
            if !accepted {
                notificationMessage = "Notifications aren't allowed. Enable them for Teddy's Feedings in iPhone Settings."
                return
            }
        }
        updateSettings { $0.remindersEnabled = enabled }
    }
    var mostRecent: Feeding? { feedings.first(where: { $0.time <= Date() }) }
    var today: [Feeding] { feedings.filter { Calendar.current.isDateInToday($0.time) } }
    var todayTotalML: Double { today.reduce(0) { $0 + $1.totalML } }
    var todayFormulaML: Double { today.reduce(0) { $0 + $1.formulaML } }
    var todayBreastML: Double { today.reduce(0) { $0 + $1.breastMilkML } }
    var expectedNext: Date? {
        guard settings.remindersEnabled, let last = mostRecent else { return nil }
        return last.time.addingTimeInterval(Double(settings.reminderIntervalMinutes * 60))
    }
    func exportCSV() -> URL? {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent("Teddys-Feedings.csv")
        var lines = ["Date,Time,Formula (mL),Breast milk (mL),Total (mL),Notes"]
        let dayFormatter = DateFormatter(); dayFormatter.dateFormat = "yyyy-MM-dd"
        let timeFormatter = DateFormatter(); timeFormatter.dateFormat = "HH:mm:ss"
        for feeding in feedings.sorted(by: { $0.time < $1.time }) {
            let note = "\"\(feeding.notes.replacingOccurrences(of: "\"", with: "\"\""))\""
            lines.append("\(dayFormatter.string(from: feeding.time)),\(timeFormatter.string(from: feeding.time)),\(feeding.formulaML),\(feeding.breastMilkML),\(feeding.totalML),\(note)")
        }
        do { try lines.joined(separator: "\n").write(to: file, atomically: true, encoding: .utf8); return file }
        catch { return nil }
    }
}

enum ReminderService {
    private static let id = "teddy.nextFeeding"
    static func askPermission() async -> Bool {
        do { return try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) }
        catch { return false }
    }
    static func scheduleTestNotification(sound: Bool) async -> Bool {
        let granted = await askPermission()
        guard granted else { return false }
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Teddy's Feedings 🧸"
        content.body = "This is a test feeding check-in. Banners and sounds follow your iPhone notification settings."
        if sound { content.sound = .default }
        let request = UNNotificationRequest(identifier: "teddy.test.\(UUID().uuidString)", content: content,
                                            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false))
        do { try await center.add(request); return true }
        catch { return false }
    }

    static func schedule(settings: TeddySettings, lastFeeding: Date?) async {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [id])
        guard settings.remindersEnabled, let lastFeeding else { return }
        let authorization = await center.notificationSettings()
        guard authorization.authorizationStatus == .authorized || authorization.authorizationStatus == .provisional else { return }
        let intended = lastFeeding.addingTimeInterval(Double(settings.reminderIntervalMinutes * 60))
        let delay = max(60, intended.timeIntervalSinceNow)
        let content = UNMutableNotificationContent()
        content.title = "Teddy's feeding check-in 🧸"
        content.body = "It’s been about \(FeedingMath.intervalText(Double(settings.reminderIntervalMinutes * 60))) since the last logged feeding. Check Teddy’s cues."
        if settings.reminderSoundEnabled { content.sound = .default }
        let request = UNNotificationRequest(identifier: id, content: content,
                                            trigger: UNTimeIntervalNotificationTrigger(timeInterval: delay, repeats: false))
        try? await center.add(request)
    }
}
