import Combine
import Foundation
import UserNotifications

extension Notification.Name {
    static let teddyFeedingsChanged = Notification.Name("teddyFeedingsChanged")
}

@MainActor
enum FeedingRepository {
    private static let feedingsKey = "teddy.feedings.v1"
    private static let settingsKey = "teddy.settings.v1"

    static func readFeedings() -> [Feeding] {
        guard let data = UserDefaults.standard.data(forKey: feedingsKey),
              let decoded = try? JSONDecoder().decode([Feeding].self, from: data) else { return [] }
        return decoded.sorted { $0.time > $1.time }
    }
    static func readSettings() -> TeddySettings {
        guard let data = UserDefaults.standard.data(forKey: settingsKey),
              let decoded = try? JSONDecoder().decode(TeddySettings.self, from: data) else { return TeddySettings() }
        return decoded
    }
    static func saveFeedings(_ feedings: [Feeding]) {
        guard let data = try? JSONEncoder().encode(feedings) else { return }
        UserDefaults.standard.set(data, forKey: feedingsKey)
        NotificationCenter.default.post(name: .teddyFeedingsChanged, object: nil)
        reschedule()
    }
    static func saveSettings(_ settings: TeddySettings) {
        guard let data = try? JSONEncoder().encode(settings) else { return }
        UserDefaults.standard.set(data, forKey: settingsKey)
        NotificationCenter.default.post(name: .teddyFeedingsChanged, object: nil)
        reschedule()
    }
    static func insert(_ feeding: Feeding) {
        guard feeding.totalML > 0, feeding.totalML <= 1000, feeding.time <= Date().addingTimeInterval(60) else { return }
        var all = readFeedings()
        if let index = all.firstIndex(where: { $0.id == feeding.id }) { all[index] = feeding }
        else { all.append(feeding) }
        saveFeedings(all)
    }
    private static func reschedule() {
        let settings = readSettings()
        let latest = readFeedings().map(\.lastMilkAt).filter { $0 <= Date() }.max()
        Task { await ReminderService.schedule(settings: settings, lastFeeding: latest) }
    }
}

@MainActor
final class FeedingStore: ObservableObject {
    @Published private(set) var feedings = FeedingRepository.readFeedings()
    @Published private(set) var settings = FeedingRepository.readSettings()
    @Published var notificationMessage: String? = nil
    private var observer: NSObjectProtocol?

    init() {
        observer = NotificationCenter.default.addObserver(forName: .teddyFeedingsChanged,
                                                           object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.reload() }
        }
    }
    func reload() {
        feedings = FeedingRepository.readFeedings()
        settings = FeedingRepository.readSettings()
    }
    @discardableResult
    func save(_ draft: FeedingDraft) -> Bool {
        let incoming = draft.feeding()
        guard incoming.formulaML.isFinite, incoming.breastMilkML.isFinite,
              incoming.formulaML >= 0, incoming.breastMilkML >= 0, incoming.totalML > 0, incoming.totalML <= 1000 else { return false }
        if let offered = incoming.offeredFormulaML {
            guard offered.isFinite, offered >= incoming.formulaML else { return false }
        }
        if let offered = incoming.offeredBreastMilkML {
            guard offered.isFinite, offered >= incoming.breastMilkML else { return false }
        }
        guard incoming.time <= Date().addingTimeInterval(60) else { return false }
        let extras = incoming.topUps ?? []
        guard incoming.formulaML >= extras.reduce(0, { $0 + $1.formulaML }),
              incoming.breastMilkML >= extras.reduce(0, { $0 + $1.breastMilkML }),
              extras.allSatisfy({ $0.time >= incoming.time }) else { return false }
        if let id = draft.topUpForID {
            guard let original = FeedingRepository.readFeedings().first(where: { $0.id == id }),
                  let combined = FeedingPlan.addingTopUp(incoming, to: original) else { return false }
            FeedingRepository.insert(combined)
        } else {
            if let id = draft.editingID, !FeedingRepository.readFeedings().contains(where: { $0.id == id }) { return false }
            FeedingRepository.insert(incoming)
        }
        reload()
        return true
    }
    func delete(_ feeding: Feeding) {
        FeedingRepository.saveFeedings(feedings.filter { $0.id != feeding.id })
        reload()
    }
    func updateSettings(_ change: (inout TeddySettings) -> Void) {
        var copy = settings
        change(&copy)
        FeedingRepository.saveSettings(copy)
        reload()
    }
    func setReminders(_ enabled: Bool) async {
        if enabled {
            let accepted = await ReminderService.askPermission()
            if !accepted {
                notificationMessage = "Notifications aren't allowed. Enable them for Teddy's Feedings in iPhone Settings."
                return
            }
        }
        updateSettings { $0.remindersEnabled = enabled }
    }
    var mostRecent: Feeding? { feedings.filter { $0.lastMilkAt <= Date() }.max(by: { $0.lastMilkAt < $1.lastMilkAt }) }
    var today: [Feeding] { feedings.filter { let milk = $0.milk(on: Date()); return milk.formula + milk.breast > 0 } }
    var todayTotalML: Double { todayFormulaML + todayBreastML }
    var todayFormulaML: Double { feedings.reduce(0) { $0 + $1.milk(on: Date()).formula } }
    var todayBreastML: Double { feedings.reduce(0) { $0 + $1.milk(on: Date()).breast } }
    var expectedNext: Date? {
        guard settings.remindersEnabled, let last = mostRecent else { return nil }
        return last.lastMilkAt.addingTimeInterval(Double(settings.reminderIntervalMinutes * 60))
    }
    func exportCSV() -> URL? {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent("Teddys-Feedings.csv")
        var lines = ["Date,Time,Formula (mL),Breast milk (mL),Total (mL),Offered formula (mL),Offered breast milk (mL),Last top-up,Notes"]
        let dayFormatter = DateFormatter(); dayFormatter.dateFormat = "yyyy-MM-dd"
        let timeFormatter = DateFormatter(); timeFormatter.dateFormat = "HH:mm:ss"
        for feeding in feedings.sorted(by: { $0.time < $1.time }) {
            let note = "\"\(feeding.notes.replacingOccurrences(of: "\"", with: "\"\""))\""
            lines.append("\(dayFormatter.string(from: feeding.time)),\(timeFormatter.string(from: feeding.time)),\(feeding.formulaML),\(feeding.breastMilkML),\(feeding.totalML),\(feeding.offeredFormulaML.map { String($0) } ?? ""),\(feeding.offeredBreastMilkML.map { String($0) } ?? ""),\(feeding.lastTopUpAt.map { ISO8601DateFormatter().string(from: $0) } ?? ""),\(note)")
        }
        do { try lines.joined(separator: "\n").write(to: file, atomically: true, encoding: .utf8); return file }
        catch { return nil }
    }
}

enum ReminderService {
    private static let id = "teddy.nextFeeding"
    // Update already-scheduled reminders without moving their due date or asking permission again.
    static func upgradePendingReminderSound() async {
        let center = UNUserNotificationCenter.current()
        let pending = await center.pendingNotificationRequests()
        for request in pending where request.identifier == id {
            let nextDate: Date?
            if let trigger = request.trigger as? UNTimeIntervalNotificationTrigger {
                nextDate = trigger.nextTriggerDate()
            } else if let trigger = request.trigger as? UNCalendarNotificationTrigger {
                nextDate = trigger.nextTriggerDate()
            } else { nextDate = nil }
            guard let due = nextDate, due > Date(),
                  let content = request.content.mutableCopy() as? UNMutableNotificationContent else { continue }
            let enabled = await MainActor.run { FeedingRepository.readSettings().reminderSoundEnabled }
            content.sound = enabled ? UNNotificationSound(named: UNNotificationSoundName(rawValue: "TeddyRattle.wav")) : nil
            content.title = "It’s feeding time for Teddy 🧸"
            content.body = "Time for a little bottle break. Tap to open Teddy’s feeding reminder and check his hunger cues."
            let parts = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: due)
            let trigger = UNCalendarNotificationTrigger(dateMatching: parts, repeats: false)
            try? await center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
        }
    }

    static func askPermission() async -> Bool {
        do { return try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) }
        catch { return false }
    }
    static func scheduleTestNotification(sound: Bool) async -> Bool {
        let granted = await askPermission()
        guard granted else { return false }
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Teddy's Feedings 🧸"
        content.body = "A little lullaby for Teddy. Tap this test reminder to open his feeding-time message."
        if sound { content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "TeddyRattle.wav")) }
        let request = UNNotificationRequest(identifier: "teddy.test.\(UUID().uuidString)", content: content,
                                            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false))
        do { try await center.add(request); return true }
        catch { return false }
    }

    static func schedule(settings: TeddySettings, lastFeeding: Date?) async {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [id])
        guard settings.remindersEnabled, let lastFeeding else { return }
        let authorization = await center.notificationSettings()
        guard authorization.authorizationStatus == .authorized || authorization.authorizationStatus == .provisional else { return }
        let intended = lastFeeding.addingTimeInterval(Double(settings.reminderIntervalMinutes * 60))
        let delay = max(60, intended.timeIntervalSinceNow)
        let content = UNMutableNotificationContent()
        content.title = "It’s feeding time for Teddy 🧸"
        content.body = "Time for a little bottle break. Tap to open Teddy’s feeding reminder and check his hunger cues."
        if settings.reminderSoundEnabled { content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "TeddyRattle.wav")) }
        let request = UNNotificationRequest(identifier: id, content: content,
                                            trigger: UNTimeIntervalNotificationTrigger(timeInterval: delay, repeats: false))
        try? await center.add(request)
    }
}
