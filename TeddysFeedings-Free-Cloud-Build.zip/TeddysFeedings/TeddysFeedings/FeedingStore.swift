import Combine
import Foundation
import UserNotifications

extension Notification.Name {
    static let teddyFeedingsChanged = Notification.Name("teddyFeedingsChanged")
}

@MainActor
enum FeedingRepository {
    private static var feedingsKey: String { FamilySyncService.storagePrefix + ".feedings.v1" }
    private static var settingsKey: String { FamilySyncService.storagePrefix + ".settings.v1" }

    static func readFeedings() -> [Feeding] {
        guard let data = UserDefaults.standard.data(forKey: feedingsKey),
              let decoded = try? JSONDecoder().decode([Feeding].self, from: data) else { return [] }
        return decoded.sorted { $0.time > $1.time }
    }
    static func readSettings() -> TeddySettings {
        guard let data = UserDefaults.standard.data(forKey: settingsKey),
              let decoded = try? JSONDecoder().decode(TeddySettings.self, from: data) else { return TeddySettings() }
        return decoded
    }
    static func saveFeedings(_ feedings: [Feeding]) {
        guard let data = try? JSONEncoder().encode(feedings) else { return }
        UserDefaults.standard.set(data, forKey: feedingsKey)
        FamilySyncService.shared.captureLocal()
        NotificationCenter.default.post(name: .teddyFeedingsChanged, object: nil)
        reschedule()
    }
    static func saveSettings(_ settings: TeddySettings) {
        guard let data = try? JSONEncoder().encode(settings) else { return }
        UserDefaults.standard.set(data, forKey: settingsKey)
        FamilySyncService.shared.captureLocal()
        NotificationCenter.default.post(name: .teddyFeedingsChanged, object: nil)
        reschedule()
    }
    static func insert(_ feeding: Feeding) {
        guard feeding.totalML > 0, feeding.totalML <= 1000, feeding.time <= Date().addingTimeInterval(60) else { return }
        var all = readFeedings()
        if let index = all.firstIndex(where: { $0.id == feeding.id }) { all[index] = feeding }
        else { all.append(feeding) }
        saveFeedings(all)
    }
    private static func reschedule() {
        let settings = readSettings()
        let latest = readFeedings().map(\.lastMilkAt).filter { $0 <= Date() }.max()
        Task { await ReminderService.schedule(settings: settings, lastFeeding: latest) }
        PumpingReminderService.reschedule()
    }
}

@MainActor
final class FeedingStore: ObservableObject {
    @Published private(set) var pumpingSessions = PumpingRepository.read()
    @Published private(set) var feedings = FeedingRepository.readFeedings()
    @Published private(set) var settings = FeedingRepository.readSettings()
    @Published var notificationMessage: String? = nil
    private var observer: NSObjectProtocol?

    init() {
        observer = NotificationCenter.default.addObserver(forName: .teddyFeedingsChanged,
                                                           object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.reload() }
        }
    }
    func refreshShared() async {
        reload()
        await FamilySyncService.shared.refresh()
        reload()
    }
    func reload() {
        pumpingSessions = PumpingRepository.read()
        feedings = FeedingRepository.readFeedings()
        settings = FeedingRepository.readSettings()
        PumpingReminderService.reschedule()
    }
    @discardableResult
    func save(_ draft: FeedingDraft) -> Bool {
        if let original = draft.originalFeeding,
           FeedingRepository.readFeedings().first(where: { $0.id == original.id }) != original { return false }
        let incoming = draft.feeding()
        guard incoming.formulaML.isFinite, incoming.breastMilkML.isFinite,
              incoming.formulaML >= 0, incoming.breastMilkML >= 0, incoming.totalML > 0, incoming.totalML <= 1000 else { return false }
        if let offered = incoming.offeredFormulaML {
            guard offered.isFinite, offered >= incoming.formulaML else { return false }
        }
        if let offered = incoming.offeredBreastMilkML {
            guard offered.isFinite, offered >= incoming.breastMilkML else { return false }
        }
        guard incoming.time <= Date().addingTimeInterval(60) else { return false }
        let extras = incoming.topUps ?? []
        guard incoming.formulaML >= extras.reduce(0, { $0 + $1.formulaML }),
              incoming.breastMilkML >= extras.reduce(0, { $0 + $1.breastMilkML }),
              extras.allSatisfy({ $0.time >= incoming.time }) else { return false }
        if let id = draft.topUpForID {
            guard let original = FeedingRepository.readFeedings().first(where: { $0.id == id }),
                  let combined = FeedingPlan.addingTopUp(incoming, to: original) else { return false }
            FeedingRepository.insert(combined)
        } else {
            if let id = draft.editingID, !FeedingRepository.readFeedings().contains(where: { $0.id == id }) { return false }
            FeedingRepository.insert(incoming)
        }
        reload()
        return true
    }
    func delete(_ feeding: Feeding) {
        guard FeedingRepository.readFeedings().first(where: { $0.id == feeding.id }) == feeding else {
            notificationMessage = "This feeding changed since you selected it. Refresh and review it before deleting."; return
        }
        FeedingRepository.saveFeedings(FeedingRepository.readFeedings().filter { $0.id != feeding.id })
        reload()
    }
    func updateSettings(_ change: (inout TeddySettings) -> Void) {
        var copy = settings
        change(&copy)
        FeedingRepository.saveSettings(copy)
        reload()
    }
    func setReminders(_ enabled: Bool) async {
        if enabled {
            let accepted = await ReminderService.askPermission()
            if !accepted {
                notificationMessage = "Notifications aren't allowed. Enable them for Teddy's Feedings in iPhone Settings."
                return
            }
        }
        updateSettings { $0.remindersEnabled = enabled }
    }
    var mostRecent: Feeding? { feedings.filter { $0.lastMilkAt <= Date() }.max(by: { $0.lastMilkAt < $1.lastMilkAt }) }
    var today: [Feeding] { feedings.filter { let milk = $0.milk(on: Date()); return milk.formula + milk.breast > 0 } }
    var todayTotalML: Double { todayFormulaML + todayBreastML }
    var todayFormulaML: Double { feedings.reduce(0) { $0 + $1.milk(on: Date()).formula } }
    var todayBreastML: Double { feedings.reduce(0) { $0 + $1.milk(on: Date()).breast } }
    var expectedNext: Date? {
        guard settings.remindersEnabled, let last = mostRecent else { return nil }
        return last.lastMilkAt.addingTimeInterval(Double(settings.reminderIntervalMinutes * 60))
    }
    func exportCSV() -> URL? {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent("Teddys-Feedings.csv")
        var lines = ["Date,Time,Formula (mL),Breast milk (mL),Total (mL),Offered formula (mL),Offered breast milk (mL),Last top-up,Notes"]
        let dayFormatter = DateFormatter(); dayFormatter.dateFormat = "yyyy-MM-dd"
        let timeFormatter = DateFormatter(); timeFormatter.dateFormat = "HH:mm:ss"
        for feeding in feedings.sorted(by: { $0.time < $1.time }) {
            let note = "\"\(feeding.notes.replacingOccurrences(of: "\"", with: "\"\""))\""
            lines.append("\(dayFormatter.string(from: feeding.time)),\(timeFormatter.string(from: feeding.time)),\(feeding.formulaML),\(feeding.breastMilkML),\(feeding.totalML),\(feeding.offeredFormulaML.map { String($0) } ?? ""),\(feeding.offeredBreastMilkML.map { String($0) } ?? ""),\(feeding.lastTopUpAt.map { ISO8601DateFormatter().string(from: $0) } ?? ""),\(note)")
        }
        do { try lines.joined(separator: "\n").write(to: file, atomically: true, encoding: .utf8); return file }
        catch { return nil }
    }
}

enum ReminderService {
    private static let id = "teddy.nextFeeding"
    // Update already-scheduled reminders without moving their due date or asking permission again.
    static func upgradePendingReminderSound() async {
        let center = UNUserNotificationCenter.current()
        let pending = await center.pendingNotificationRequests()
        for request in pending where request.identifier == id {
            let nextDate: Date?
            if let trigger = request.trigger as? UNTimeIntervalNotificationTrigger {
                nextDate = trigger.nextTriggerDate()
            } else if let trigger = request.trigger as? UNCalendarNotificationTrigger {
                nextDate = trigger.nextTriggerDate()
            } else { nextDate = nil }
            guard let due = nextDate, due > Date(),
                  let content = request.content.mutableCopy() as? UNMutableNotificationContent else { continue }
            let enabled = await MainActor.run { FeedingRepository.readSettings().reminderSoundEnabled }
            content.sound = enabled ? UNNotificationSound(named: UNNotificationSoundName(rawValue: "TeddyRattle.wav")) : nil
            content.title = "It’s feeding time for Teddy 🧸"
            content.body = "Time for a little bottle break. Tap to open Teddy’s feeding reminder and check his hunger cues."
            let parts = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: due)
            let trigger = UNCalendarNotificationTrigger(dateMatching: parts, repeats: false)
            try? await center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
        }
    }

    static func askPermission() async -> Bool {
        do { return try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) }
        catch { return false }
    }
    static func scheduleTestNotification(sound: Bool) async -> Bool {
        let granted = await askPermission()
        guard granted else { return false }
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Teddy's Feedings 🧸"
        content.body = "A little lullaby for Teddy. Tap this test reminder to open his feeding-time message."
        if sound { content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "TeddyRattle.wav")) }
        let request = UNNotificationRequest(identifier: "teddy.test.\(UUID().uuidString)", content: content,
                                            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false))
        do { try await center.add(request); return true }
        catch { return false }
    }

    static func schedule(settings: TeddySettings, lastFeeding: Date?) async {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [id])
        guard settings.remindersEnabled, let lastFeeding else { return }
        let authorization = await center.notificationSettings()
        guard authorization.authorizationStatus == .authorized || authorization.authorizationStatus == .provisional else { return }
        let intended = lastFeeding.addingTimeInterval(Double(settings.reminderIntervalMinutes * 60))
        let delay = max(60, intended.timeIntervalSinceNow)
        let content = UNMutableNotificationContent()
        content.title = "It’s feeding time for Teddy 🧸"
        content.body = "Time for a little bottle break. Tap to open Teddy’s feeding reminder and check his hunger cues."
        if settings.reminderSoundEnabled { content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "TeddyRattle.wav")) }
        let request = UNNotificationRequest(identifier: id, content: content,
                                            trigger: UNTimeIntervalNotificationTrigger(timeInterval: delay, repeats: false))
        try? await center.add(request)
    }
}

@MainActor
enum PumpingRepository {
    private static var key: String { FamilySyncService.storagePrefix + ".pumping.v1" }
    static func read() -> [PumpingSession] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let sessions = try? JSONDecoder().decode([PumpingSession].self, from: data) else { return [] }
        return sessions.sorted { $0.endedAt > $1.endedAt }
    }
    @discardableResult
    static func save(_ session: PumpingSession, editing: Bool = false) -> Bool {
        guard session.isValid() else { return false }
        var all = read()
        if let index = all.firstIndex(where: { $0.id == session.id }) { all[index] = session }
        else if editing { return false }
        else { all.append(session) }
        return write(all) && read().contains(session)
    }
    @discardableResult
    static func delete(_ session: PumpingSession) -> Bool {
        guard read().first(where: { $0.id == session.id }) == session else { return false }
        return write(read().filter { $0.id != session.id })
    }
    private static func write(_ sessions: [PumpingSession]) -> Bool {
        guard let data = try? JSONEncoder().encode(sessions) else { return false }
        UserDefaults.standard.set(data, forKey: key)
        FamilySyncService.shared.captureLocal()
        PumpingReminderService.reschedule()
        NotificationCenter.default.post(name: .teddyFeedingsChanged, object: nil)
        return true
    }
    static func replaceFromSync(_ sessions: [PumpingSession]) { _ = write(sessions) }
    #if DEBUG
    static func seedForReview(_ sessions: [PumpingSession]) { _ = write(sessions) }
    #endif
    static func exportCSV() -> URL? {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Teddys-Pumping.csv")
        var lines = ["Started,Ended,Duration (minutes),Pumped (mL),Pumped (oz),Notes"]
        let formatter = ISO8601DateFormatter()
        for session in read().reversed() {
            let note = "\"\(session.notes.replacingOccurrences(of: "\"", with: "\"\""))\""
            lines.append("\(formatter.string(from: session.startedAt)),\(formatter.string(from: session.endedAt)),\(session.durationMinutes),\(session.amountML),\(VolumeUnit.ounces.fromMilliliters(session.amountML)),\(note)")
        }
        do { try lines.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8); return url } catch { return nil }
    }
}

@MainActor
enum PumpingReminderService {
    static let id = "teddy.nextPumping"
    private static var generation = 0
    static func reschedule() {
        generation += 1
        let version = generation
        let scope = FamilySyncService.storagePrefix
        let settings = FeedingRepository.readSettings()
        let due = PumpingReminderPlan.due(sessions: PumpingRepository.read(), settings: settings)
        Task {
            let center = UNUserNotificationCenter.current()
            let pending = await center.pendingNotificationRequests()
            let delivered = await center.deliveredNotifications()
            let authorization = await center.notificationSettings()
            guard version == generation, scope == FamilySyncService.storagePrefix else { return }
            guard let due, authorization.authorizationStatus == .authorized || authorization.authorizationStatus == .provisional else {
                center.removePendingNotificationRequests(withIdentifiers: [id]); return
            }
            let anchor = "\(scope):\(due.timeIntervalSince1970)"
            // Refreshing the shared journal must not postpone or repeat the same check-in.
            let old = pending.first { $0.identifier == id && $0.content.userInfo["anchor"] as? String == anchor }
            if let old, (old.content.sound != nil) == settings.pumpingReminderSoundEnabled { return }
            if old == nil && due <= Date() && UserDefaults.standard.string(forKey: "teddy.pumpingReminder.lastAnchor") == anchor {
                center.removePendingNotificationRequests(withIdentifiers: [id]); return
            }
            if delivered.contains(where: { $0.request.identifier == id && $0.request.content.userInfo["anchor"] as? String == anchor }) {
                center.removePendingNotificationRequests(withIdentifiers: [id]); return
            }
            let content = UNMutableNotificationContent()
            content.title = "A little pumping break 💗"
            content.body = "Time for your pumping check-in. Tap to see your last session and log when you’re finished."
            content.userInfo = ["anchor": anchor, "journal": scope]
            if settings.pumpingReminderSoundEnabled { content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "TeddyRattle.wav")) }
            let oldDate = (old?.trigger as? UNCalendarNotificationTrigger)?.nextTriggerDate()
                ?? (old?.trigger as? UNTimeIntervalNotificationTrigger)?.nextTriggerDate()
            let fire = oldDate ?? max(due, Date().addingTimeInterval(60))
            let parts = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: fire)
            do {
                try await center.add(UNNotificationRequest(identifier: id, content: content, trigger: UNCalendarNotificationTrigger(dateMatching: parts, repeats: false)))
                UserDefaults.standard.set(anchor, forKey: "teddy.pumpingReminder.lastAnchor")
                if version != generation { reschedule() }
            } catch { }

        }
    }
    static func test(sound: Bool) async -> Bool {
        guard await ReminderService.askPermission() else { return false }
        let content = UNMutableNotificationContent()
        content.title = "A little pumping break 💗"
        content.body = "Your pumping reminder test. Tap to open your last-session message."
        content.userInfo = ["journal": FamilySyncService.storagePrefix]
        if sound { content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "TeddyRattle.wav")) }
        do {
            try await UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "teddy.pumpingTest.\(UUID().uuidString)", content: content, trigger: UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)))
            return true
        } catch { return false }
    }
}
