import SwiftUI

struct HistoryView: View {
    @EnvironmentObject private var store: FeedingStore
    let openEditor: (FeedingDraft) -> Void
    @State private var selectedPeriod = 1
    @State private var selectedForDeletion: Feeding?

    private var visible: [Feeding] {
        switch selectedPeriod {
        case 0: return store.today
        case 1: return store.feedings.filter { $0.time >= Calendar.current.date(byAdding: .day, value: -7, to: .now)! }
        default: return store.feedings
        }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Feeding history")
                                .font(.system(size: 27, weight: .heavy, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                            Text("Every bottle, easy to find")
                                .font(.system(size: 13, design: .rounded)).foregroundStyle(TeddyTheme.muted)
                        }
                        Spacer()
                        Image(systemName: "list.bullet.clipboard")
                            .font(.system(size: 25)).foregroundStyle(TeddyTheme.accent)
                    }.padding(.top, 16)
                    TeddySegmentedPicker(label: "Time range", selection: $selectedPeriod,
                                         options: [("Today", 0), ("7 days", 1), ("All time", 2)])
                    TeddyCard {
                        HStack {
                            stat(value: "\(visible.count)", title: "feedings")
                            Spacer()
                            stat(value: store.settings.unit.display(visible.reduce(0) { $0 + $1.totalML }), title: "total volume")
                            Spacer()
                            stat(value: FeedingMath.averageGap(visible).map(FeedingMath.intervalText) ?? "—", title: "avg interval")
                        }
                    }
                    if visible.isEmpty {
                        TeddyEmptyState(title: "No bottles in this time range", message: "Teddy’s saved feedings will appear here.")
                    } else {
                        ForEach(visible) { feeding in
                            Button { openEditor(FeedingDraft(feeding: feeding)) } label: {
                                TeddyCard {
                                    FeedingRow(feeding: feeding, unit: store.settings.unit,
                                               previous: store.feedings.first(where: { $0.time < feeding.time }))
                                    if !feeding.notes.isEmpty {
                                        Text(feeding.notes)
                                            .font(.system(size: 12, design: .rounded))
                                            .foregroundStyle(TeddyTheme.muted)
                                    }
                                    HStack {
                                        Text("Tap to edit").font(.system(size: 11, design: .rounded))
                                        Spacer()
                                        Image(systemName: "pencil")
                                    }.foregroundStyle(TeddyTheme.accent)
                                }
                            }.buttonStyle(.plain)
                                .contextMenu {
                                    Button("Edit", systemImage: "pencil") { openEditor(FeedingDraft(feeding: feeding)) }
                                    Button("Delete", systemImage: "trash", role: .destructive) {
                                        selectedForDeletion = feeding
                                    }
                                }
                        }
                    }
                }.padding(.horizontal, 18).padding(.bottom, 18)
            }
            .scrollBounceBehavior(.always)
            .refreshable { store.reload() }
            .background(TeddyTheme.cream.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .confirmationDialog("Delete this feeding?", isPresented: Binding(
                get: { selectedForDeletion != nil },
                set: { if !$0 { selectedForDeletion = nil } }), titleVisibility: .visible) {
                    Button("Delete feeding", role: .destructive) {
                        if let feeding = selectedForDeletion { store.delete(feeding) }
                        selectedForDeletion = nil
                    }
                } message: { Text("This cannot be undone.") }
        }
    }
    private func stat(value: String, title: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(value).font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundStyle(TeddyTheme.cocoa).minimumScaleFactor(0.65).lineLimit(1)
            Text(title).font(.system(size: 11, design: .rounded)).foregroundStyle(TeddyTheme.muted)
        }
    }
}
