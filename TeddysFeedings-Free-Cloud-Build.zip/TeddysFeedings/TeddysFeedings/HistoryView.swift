import SwiftUI
import UIKit

struct HistoryView: View {
    @EnvironmentObject private var store: FeedingStore
    @State private var openSwipeID: UUID?
    let openEditor: (FeedingDraft) -> Void
    @SceneStorage("teddy.history.period") private var selectedPeriod = 1
    @State private var selectedForDeletion: Feeding?
    @State private var showingSummary = false
    private var analytics: FeedingAnalytics { FeedingAnalytics(store.feedings, dayCount: selectedPeriod == 0 ? 1 : selectedPeriod == 1 ? 7 : nil) }
    private var visible: [Feeding] { analytics.sessions }
    private var periodTitle: String { ["Today", "Last 7 days", "All time"][selectedPeriod] }
    private var summary: String {
        let a = analytics; let unit = store.settings.unit
        return "Teddy’s feeding summary — \(periodTitle)\n\(Date().formatted(date: .abbreviated, time: .shortened))\n\nFeedings: \(a.count)\nTotal milk: \(unit.display(a.totalML))\nFormula: \(unit.display(a.formulaML)) (\(PumpingMath.percentage(a.formulaML, total: a.totalML)))\nBreast milk: \(unit.display(a.breastML)) (\(PumpingMath.percentage(a.breastML, total: a.totalML)))\nAverage interval: \(a.averageGap.map(FeedingMath.intervalText) ?? "—")\n\nTotals use the time milk was logged as drunk, including top-offs."
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Feeding history").font(.system(size: 27, weight: .heavy, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                            Text("Every bottle, easy to find").font(.subheadline).foregroundStyle(TeddyTheme.muted)
                        }
                        Spacer()
                        Button { showingSummary = true } label: {
                            Image(systemName: "list.bullet.clipboard.fill").font(.title2).foregroundStyle(TeddyTheme.action)
                                .frame(width: 48, height: 48).background(TeddyTheme.paleSage, in: RoundedRectangle(cornerRadius: 14))
                        }.buttonStyle(.plain).accessibilityLabel("Copy or share feeding summary")
                    }
                    TeddySegmentedPicker(label: "Time range", selection: $selectedPeriod, options: [("Today", 0), ("7 days", 1), ("All time", 2)])
                    summaryCard
                    if visible.isEmpty {
                        TeddyEmptyState(title: "No bottles in this time range", message: "Teddy’s saved feedings will appear here.")
                    } else {
                        ForEach(visible) { feeding in
                            SwipeEntryRow(id: feeding.id, openID: $openSwipeID,
                                requestEdit: { openEditor(FeedingDraft(feeding: feeding)) }, requestDelete: { selectedForDeletion = feeding }) {
                            Button { openEditor(FeedingDraft(feeding: feeding)) } label: {
                                TeddyCard {
                                    FeedingRow(feeding: feeding, unit: store.settings.unit, previous: store.feedings.first { $0.time < feeding.time })
                                    if let offered = feeding.offeredTotalML {
                                        Text("Offered \(store.settings.unit.display(offered)) · Drank \(store.settings.unit.display(feeding.totalML))").font(.caption).foregroundStyle(TeddyTheme.muted)
                                    }
                                    if !feeding.notes.isEmpty { Text(feeding.notes).font(.caption).foregroundStyle(TeddyTheme.muted) }
                                    Label("Edit feeding", systemImage: "pencil").font(.caption.weight(.semibold)).foregroundStyle(TeddyTheme.action)
                                }
                            }.buttonStyle(.plain).contextMenu {
                                Button("Add top-off", systemImage: "plus.circle") { openEditor(FeedingDraft.topUp(for: feeding)) }
                                Button("Edit", systemImage: "pencil") { openEditor(FeedingDraft(feeding: feeding)) }
                                Button("Delete", systemImage: "trash", role: .destructive) { selectedForDeletion = feeding }
                            }
                            }
                        }
                    }
                }.padding(18)
            }.scrollBounceBehavior(.always).refreshable { await store.refreshShared() }
                .background(TeddyTheme.cream.ignoresSafeArea()).toolbar(.hidden, for: .navigationBar)
                .sheet(isPresented: $showingSummary) { HistorySummarySheet(summary: summary) }
                .confirmationDialog("Delete this feeding?", isPresented: Binding(get: { selectedForDeletion != nil }, set: { if !$0 { selectedForDeletion = nil } }), titleVisibility: .visible) {
                    Button("Delete feeding", role: .destructive) {
                        if let feeding = selectedForDeletion { store.delete(feeding) }; selectedForDeletion = nil
                    }
                } message: { Text(FamilySyncService.shared.familyID != nil ? "This removes the feeding from the shared journal on both phones. This cannot be undone." : "This removes the entry from this phone only. This cannot be undone.") }
        }
    }
    private var summaryCard: some View {
        let a = analytics
        return TeddyCard {
            HStack(alignment: .top) {
                stat("\(a.count)", "feedings")
                Spacer(); stat(store.settings.unit.display(a.totalML), "total milk")
                Spacer(); stat(a.averageGap.map(FeedingMath.intervalText) ?? "—", "avg interval")
            }
            Divider()
            milkRow("Formula", ml: a.formulaML, kind: .formula)
            milkRow("Breast milk", ml: a.breastML, kind: .breast)
            Text("\(a.formulaOnlyCount) formula-only · \(a.breastOnlyCount) breast-milk-only · \(a.mixedCount) mixed bottles")
                .font(.caption).foregroundStyle(TeddyTheme.muted)
            Text("Milk totals count top-offs on the day they were drunk. Bottle categories describe the complete logged bottle.").font(.caption2).foregroundStyle(TeddyTheme.muted)
        }
    }
    private func milkRow(_ title: String, ml: Double, kind: MilkIconKind) -> some View {
        HStack {
            MilkTypeIcon(kind: kind).frame(width: 23, height: 25)
            Text(title).font(.subheadline)
            Spacer()
            Text("\(store.settings.unit.display(ml)) · \(PumpingMath.percentage(ml, total: analytics.totalML))").font(.subheadline.weight(.semibold))
        }
    }
    private func stat(_ value: String, _ title: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(value).font(.system(size: 18, weight: .heavy, design: .rounded)).minimumScaleFactor(0.6).lineLimit(1).foregroundStyle(TeddyTheme.cocoa)
            Text(title).font(.caption).foregroundStyle(TeddyTheme.muted)
        }
    }
}
private struct HistorySummarySheet: View {
    let summary: String
    @Environment(\.dismiss) private var dismiss
    @State private var copied = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text(summary).textSelection(.enabled)
                    Button(copied ? "Summary copied!" : "Copy summary", systemImage: "doc.on.doc") { UIPasteboard.general.string = summary; copied = true }
                    ShareLink("Share summary", item: summary)
                }.padding(22)
            }.navigationTitle("Feeding summary").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } } }
        }.tint(TeddyTheme.action).buttonStyle(TeddyTextButtonStyle()).preferredColorScheme(.light)
    }
}
