import SwiftUI

enum TeddyTheme {
    static let cream = Color(red: 0.985, green: 0.967, blue: 0.941)
    static let paper = Color(red: 1.000, green: 0.997, blue: 0.989)
    static let cocoa = Color(red: 0.278, green: 0.204, blue: 0.160)
    static let brown = Color(red: 0.57, green: 0.38, blue: 0.27)
    static let honey = Color(red: 0.87, green: 0.65, blue: 0.39)
    static let paleHoney = Color(red: 0.963, green: 0.899, blue: 0.790)
    static let sage = Color(red: 0.34, green: 0.54, blue: 0.47)
    static let paleSage = Color(red: 0.883, green: 0.940, blue: 0.887)
    static let muted = Color(red: 0.51, green: 0.45, blue: 0.41)
}

struct BearFace: View {
    var size: CGFloat = 76
    var body: some View {
        ZStack {
            Circle().fill(TeddyTheme.brown).frame(width: size * 0.35, height: size * 0.35)
                .offset(x: -size * 0.32, y: -size * 0.31)
            Circle().fill(TeddyTheme.paleHoney).frame(width: size * 0.19, height: size * 0.19)
                .offset(x: -size * 0.32, y: -size * 0.31)
            Circle().fill(TeddyTheme.brown).frame(width: size * 0.35, height: size * 0.35)
                .offset(x: size * 0.32, y: -size * 0.31)
            Circle().fill(TeddyTheme.paleHoney).frame(width: size * 0.19, height: size * 0.19)
                .offset(x: size * 0.32, y: -size * 0.31)
            Ellipse().fill(TeddyTheme.brown).frame(width: size * 0.87, height: size * 0.81)
            Circle().fill(TeddyTheme.cocoa).frame(width: size * 0.073, height: size * 0.073)
                .offset(x: -size * 0.18, y: -size * 0.065)
            Circle().fill(TeddyTheme.cocoa).frame(width: size * 0.073, height: size * 0.073)
                .offset(x: size * 0.18, y: -size * 0.065)
            Ellipse().fill(TeddyTheme.paleHoney).frame(width: size * 0.38, height: size * 0.3)
                .offset(y: size * 0.18)
            Ellipse().fill(TeddyTheme.cocoa).frame(width: size * 0.14, height: size * 0.10)
                .offset(y: size * 0.115)
            Image(systemName: "mouth")
                .resizable().scaledToFit().frame(width: size * 0.16, height: size * 0.1)
                .foregroundStyle(TeddyTheme.cocoa).offset(y: size * 0.225)
        }
        .frame(width: size, height: size)
        .accessibilityLabel("Smiling teddy bear")
    }
}

struct TeddyCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .padding(19).frame(maxWidth: .infinity, alignment: .leading)
            .background(TeddyTheme.paper, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24)
                .strokeBorder(TeddyTheme.cocoa.opacity(0.06), lineWidth: 1))
    }
}

struct PillLabel: View {
    let symbol: String
    let label: String
    let tint: Color
    var body: some View {
        Label(label, systemImage: symbol)
            .font(.system(size: 12, weight: .semibold, design: .rounded))
            .foregroundStyle(tint)
            .padding(.horizontal, 10).padding(.vertical, 7)
            .background(tint.opacity(0.11), in: Capsule())
    }
}

struct FeedingRow: View {
    let feeding: Feeding
    let unit: VolumeUnit
    let previous: Feeding?
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 14).fill(feeding.formulaML > 0 ? TeddyTheme.paleHoney : TeddyTheme.paleSage)
                Image(systemName: "water.waves").font(.system(size: 18, weight: .medium))
                    .foregroundStyle(feeding.formulaML > 0 ? TeddyTheme.brown : TeddyTheme.sage)
            }.frame(width: 46, height: 46)
            VStack(alignment: .leading, spacing: 5) {
                Text(feeding.category).font(.system(.subheadline, design: .rounded, weight: .bold))
                    .foregroundStyle(TeddyTheme.cocoa)
                Text(feeding.time.formatted(date: .abbreviated, time: .shortened))
                    .font(.system(size: 12)).foregroundStyle(TeddyTheme.muted)
                if let previous, feeding.time > previous.time {
                    Text("\(FeedingMath.intervalText(feeding.time.timeIntervalSince(previous.time))) after previous")
                        .font(.system(size: 11)).foregroundStyle(TeddyTheme.sage)
                }
            }
            Spacer(minLength: 4)
            VStack(alignment: .trailing, spacing: 4) {
                Text(unit.display(feeding.totalML))
                    .font(.system(.headline, design: .rounded, weight: .bold)).foregroundStyle(TeddyTheme.cocoa)
                if feeding.formulaML > 0 && feeding.breastMilkML > 0 {
                    Text("F \(unit.display(feeding.formulaML)) · B \(unit.display(feeding.breastMilkML))")
                        .font(.system(size: 10)).foregroundStyle(TeddyTheme.muted)
                }
            }
        }.padding(.vertical, 4)
    }
}
