import SwiftUI

enum TeddyTheme {
    // This nursery palette always uses a light interface, including native controls.
    static let action = Color(red: 0.18, green: 0.25, blue: 0.65)
    static let rose = Color(red: 0.58, green: 0.18, blue: 0.36)
    static let blush = Color(red: 1.0, green: 0.94, blue: 0.96)
    static let paleRose = Color(red: 0.98, green: 0.86, blue: 0.91)
    static let plum = Color(red: 0.30, green: 0.15, blue: 0.26)
    static let cream = Color(red: 0.941, green: 0.965, blue: 0.984)
    static let paper = Color.white
    static let cocoa = Color(red: 0.102, green: 0.176, blue: 0.251)
    static let brown = Color(red: 0.486, green: 0.310, blue: 0.204)
    static let fur = Color(red: 0.690, green: 0.471, blue: 0.310)
    static let accent = Color(red: 0.149, green: 0.337, blue: 0.510)
    static let honey = Color(red: 0.659, green: 0.424, blue: 0.235)
    static let paleHoney = Color(red: 0.957, green: 0.898, blue: 0.804)
    static let sage = Color(red: 0.176, green: 0.384, blue: 0.459)
    static let paleSage = Color(red: 0.855, green: 0.925, blue: 0.961)
    static let muted = Color(red: 0.329, green: 0.392, blue: 0.451)
}

// A scalable baby bottle, drawn locally rather than relying on an unavailable SF Symbol.
struct BottleIcon: View {
    var body: some View {
        GeometryReader { proxy in
            let w = proxy.size.width
            let h = proxy.size.height
            ZStack {
                BottleOutline().stroke(style: StrokeStyle(lineWidth: max(1.6, w * 0.075), lineCap: .round, lineJoin: .round))
                Path { path in
                    for y in [0.50, 0.63, 0.76] {
                        path.move(to: CGPoint(x: w * 0.55, y: h * y))
                        path.addLine(to: CGPoint(x: w * 0.72, y: h * y))
                    }
                }.stroke(style: StrokeStyle(lineWidth: max(1.4, w * 0.06), lineCap: .round))
            }
        }
        .aspectRatio(0.68, contentMode: .fit)
        .accessibilityHidden(true)
    }
}

private struct BottleOutline: Shape {
    func path(in rect: CGRect) -> Path {
        func point(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: rect.width * x, y: rect.height * y) }
        var p = Path()
        p.move(to: point(0.37, 0.23))
        p.addLine(to: point(0.37, 0.14))
        p.addCurve(to: point(0.63, 0.14), control1: point(0.37, 0.01), control2: point(0.63, 0.01))
        p.addLine(to: point(0.63, 0.23))
        p.move(to: point(0.28, 0.24)); p.addLine(to: point(0.72, 0.24))
        p.addLine(to: point(0.72, 0.34)); p.addLine(to: point(0.28, 0.34)); p.closeSubpath()
        p.move(to: point(0.33, 0.35))
        p.addCurve(to: point(0.20, 0.49), control1: point(0.33, 0.42), control2: point(0.20, 0.42))
        p.addLine(to: point(0.20, 0.86))
        p.addQuadCurve(to: point(0.31, 0.95), control: point(0.20, 0.95))
        p.addLine(to: point(0.69, 0.95))
        p.addQuadCurve(to: point(0.80, 0.86), control: point(0.80, 0.95))
        p.addLine(to: point(0.80, 0.49))
        p.addCurve(to: point(0.67, 0.35), control1: point(0.80, 0.42), control2: point(0.67, 0.42))
        return p
    }
}

struct TeddyEmptyState: View {
    let title: String
    let message: String
    var body: some View {
        VStack(spacing: 14) {
            BearFace(size: 68).padding(18).background(TeddyTheme.paleSage, in: Circle())
            Text(title).font(.system(.title3, design: .rounded, weight: .bold))
                .foregroundStyle(TeddyTheme.cocoa)
            Text(message).font(.system(.subheadline, design: .rounded))
                .foregroundStyle(TeddyTheme.muted).multilineTextAlignment(.center)
        }.frame(maxWidth: .infinity).padding(.vertical, 24).padding(.horizontal, 12)
    }
}

struct TeddySegmentedPicker<Value: Hashable>: View {
    let label: String
    @Binding var selection: Value
    let options: [(String, Value)]
    var body: some View {
        HStack(spacing: 4) {
            ForEach(options.indices, id: \.self) { index in
                let option = options[index]
                Button { selection = option.1 } label: {
                    Text(option.0)
                        .font(.system(.subheadline, design: .rounded, weight: .semibold))
                        .foregroundStyle(selection == option.1 ? Color.white : TeddyTheme.action)
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .background(selection == option.1 ? TeddyTheme.accent : Color.clear,
                                    in: RoundedRectangle(cornerRadius: 13))
                }.buttonStyle(.plain)
                    .accessibilityAddTraits(selection == option.1 ? [.isSelected] : [])
            }
        }.padding(4).background(TeddyTheme.paleSage, in: RoundedRectangle(cornerRadius: 17))
            .accessibilityElement(children: .contain).accessibilityLabel(label)
    }
}

struct BearFace: View {
    var size: CGFloat = 76
    var body: some View {
        ZStack {
            Circle().fill(TeddyTheme.fur).frame(width: size * 0.35, height: size * 0.35)
                .offset(x: -size * 0.32, y: -size * 0.31)
            Circle().fill(TeddyTheme.paleHoney).frame(width: size * 0.19, height: size * 0.19)
                .offset(x: -size * 0.32, y: -size * 0.31)
            Circle().fill(TeddyTheme.fur).frame(width: size * 0.35, height: size * 0.35)
                .offset(x: size * 0.32, y: -size * 0.31)
            Circle().fill(TeddyTheme.paleHoney).frame(width: size * 0.19, height: size * 0.19)
                .offset(x: size * 0.32, y: -size * 0.31)
            Ellipse().fill(TeddyTheme.fur).frame(width: size * 0.87, height: size * 0.81)
            Circle().fill(TeddyTheme.cocoa).frame(width: size * 0.073, height: size * 0.073)
                .offset(x: -size * 0.18, y: -size * 0.065)
            Circle().fill(TeddyTheme.cocoa).frame(width: size * 0.073, height: size * 0.073)
                .offset(x: size * 0.18, y: -size * 0.065)
            Ellipse().fill(TeddyTheme.paleHoney).frame(width: size * 0.38, height: size * 0.3)
                .offset(y: size * 0.18)
            Ellipse().fill(TeddyTheme.cocoa).frame(width: size * 0.14, height: size * 0.10)
                .offset(y: size * 0.115)
            Image(systemName: "mouth")
                .resizable().scaledToFit().frame(width: size * 0.16, height: size * 0.1)
                .foregroundStyle(TeddyTheme.cocoa).offset(y: size * 0.225)
        }
        .overlay(alignment: .bottom) {
            HStack(spacing: 0) {
                RoundedRectangle(cornerRadius: 3).frame(width: size * 0.13, height: size * 0.13).rotationEffect(.degrees(25))
                Circle().frame(width: size * 0.07, height: size * 0.07)
                RoundedRectangle(cornerRadius: 3).frame(width: size * 0.13, height: size * 0.13).rotationEffect(.degrees(-25))
            }
                .foregroundStyle(TeddyTheme.accent).offset(y: size * 0.03)
        }
        .frame(width: size, height: size)
        .accessibilityLabel("Smiling teddy bear")
    }
}

struct TeddyCard<Content: View>: View {
    let content: Content
    let color: Color
    init(color: Color = TeddyTheme.paper, @ViewBuilder content: () -> Content) { self.color = color; self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .foregroundStyle(TeddyTheme.cocoa)
            .padding(19).frame(maxWidth: .infinity, alignment: .leading)
            .background(color, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24)
                .strokeBorder(TeddyTheme.accent.opacity(0.14), lineWidth: 1))
    }
}

struct PillLabel: View {
    let symbol: String
    let label: String
    let tint: Color
    var body: some View {
        Label(label, systemImage: symbol)
            .font(.system(size: 12, weight: .semibold, design: .rounded))
            .foregroundStyle(tint)
            .padding(.horizontal, 10).padding(.vertical, 7)
            .background(tint.opacity(0.11), in: Capsule())
    }
}

struct FeedingRow: View {
    let feeding: Feeding
    let unit: VolumeUnit
    let previous: Feeding?
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 14).fill(feeding.formulaML > 0 ? TeddyTheme.paleHoney : TeddyTheme.paleSage)
                MilkTypeIcon(kind: feeding.formulaML > 0 ? (feeding.breastMilkML > 0 ? .mixed : .formula) : .breast).frame(width: 25, height: 28)
            }.frame(width: 46, height: 46)
            VStack(alignment: .leading, spacing: 5) {
                Text(feeding.category).font(.system(.subheadline, design: .rounded, weight: .bold))
                    .foregroundStyle(TeddyTheme.cocoa)
                Text(feeding.time.formatted(date: .abbreviated, time: .shortened))
                    .font(.system(size: 12)).foregroundStyle(TeddyTheme.muted)
                if let author = FamilySyncService.shared.author(kind: "feeding", id: feeding.id) {
                    Text("Last saved by \(author)").font(.system(size: 11)).foregroundStyle(TeddyTheme.muted)
                }
                if let previous, feeding.time > previous.time {
                    Text("\(FeedingMath.intervalText(feeding.time.timeIntervalSince(previous.time))) after previous")
                        .font(.system(size: 11)).foregroundStyle(TeddyTheme.sage)
                }
            }
            Spacer(minLength: 4)
            VStack(alignment: .trailing, spacing: 4) {
                Text(unit.display(feeding.totalML))
                    .font(.system(.headline, design: .rounded, weight: .bold)).foregroundStyle(TeddyTheme.cocoa)
                if feeding.formulaML > 0 && feeding.breastMilkML > 0 {
                    Text("F \(unit.display(feeding.formulaML)) · B \(unit.display(feeding.breastMilkML))")
                        .font(.system(size: 10)).foregroundStyle(TeddyTheme.muted)
                }
            }
        }.padding(.vertical, 4)
    }
}


enum MilkIconKind { case formula, breast, mixed }
struct BreastMilkIcon: View {
    var body: some View {
        ZStack {
            Image(systemName: "heart.fill").resizable().scaledToFit()
            Image(systemName: "drop.fill").resizable().scaledToFit().foregroundStyle(.white).padding(8)
        }.accessibilityHidden(true)
    }
}
struct MilkTypeIcon: View {
    let kind: MilkIconKind
    var body: some View {
        Group {
            switch kind {
            case .formula: Image(systemName: "drop.fill").resizable().scaledToFit().foregroundStyle(TeddyTheme.brown)
            case .breast: BreastMilkIcon().foregroundStyle(TeddyTheme.rose)
            case .mixed: HStack(spacing: 1) { BottleIcon(); BreastMilkIcon().foregroundStyle(TeddyTheme.rose) }
            }
        }.accessibilityHidden(true)
    }
}
struct PumpIcon: View {
    var body: some View {
        GeometryReader { g in
            let w = g.size.width; let h = g.size.height
            Path { p in
                p.move(to: CGPoint(x: w * 0.08, y: h * 0.17))
                p.addQuadCurve(to: CGPoint(x: w * 0.08, y: h * 0.61), control: CGPoint(x: -w * 0.03, y: h * 0.39))
                p.addLine(to: CGPoint(x: w * 0.43, y: h * 0.46)); p.addLine(to: CGPoint(x: w * 0.64, y: h * 0.46))
                p.addLine(to: CGPoint(x: w * 0.64, y: h * 0.30)); p.addLine(to: CGPoint(x: w * 0.43, y: h * 0.30)); p.closeSubpath()
                p.move(to: CGPoint(x: w * 0.56, y: h * 0.30)); p.addLine(to: CGPoint(x: w * 0.56, y: h * 0.14))
                p.addQuadCurve(to: CGPoint(x: w * 0.92, y: h * 0.20), control: CGPoint(x: w * 0.82, y: h * 0.06))
                p.move(to: CGPoint(x: w * 0.57, y: h * 0.46)); p.addLine(to: CGPoint(x: w * 0.48, y: h * 0.58))
                p.addLine(to: CGPoint(x: w * 0.48, y: h * 0.88)); p.addQuadCurve(to: CGPoint(x: w * 0.58, y: h * 0.95), control: CGPoint(x: w * 0.48, y: h * 0.95))
                p.addLine(to: CGPoint(x: w * 0.85, y: h * 0.95)); p.addQuadCurve(to: CGPoint(x: w * 0.94, y: h * 0.88), control: CGPoint(x: w * 0.94, y: h * 0.95))
                p.addLine(to: CGPoint(x: w * 0.94, y: h * 0.58)); p.addLine(to: CGPoint(x: w * 0.84, y: h * 0.46)); p.closeSubpath()
                for y in [0.64, 0.75, 0.85] {
                    p.move(to: CGPoint(x: w * 0.70, y: h * y)); p.addLine(to: CGPoint(x: w * 0.83, y: h * y))
                }
            }.stroke(style: StrokeStyle(lineWidth: max(1.6, w * 0.065), lineCap: .round, lineJoin: .round))
        }.aspectRatio(1, contentMode: .fit).accessibilityHidden(true)
    }
}
struct TeddyTextButtonStyle: ButtonStyle {
    var color: Color = TeddyTheme.action
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.foregroundStyle(configuration.role == .destructive ? Color.red : color)
            .opacity(configuration.isPressed ? 0.6 : 1)
    }
}
struct TeddyLogLabel: View {
    let title: String
    let subtitle: String
    var pumping = false
    var body: some View {
        HStack(spacing: 14) {
            Group { if pumping { PumpIcon() } else { BottleIcon() } }
                .frame(width: 34, height: 42).padding(12).background(.white.opacity(0.18), in: RoundedRectangle(cornerRadius: 18))
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 20, weight: .heavy, design: .rounded))
                Text(subtitle).font(.system(size: 12, design: .rounded)).opacity(0.95)
            }
            Spacer(minLength: 0)
            Image(systemName: "plus.circle.fill").font(.title2)
        }.foregroundStyle(.white).padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: pumping ? [TeddyTheme.rose, TeddyTheme.plum] : [TeddyTheme.accent, TeddyTheme.action], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 25))
    }
}
