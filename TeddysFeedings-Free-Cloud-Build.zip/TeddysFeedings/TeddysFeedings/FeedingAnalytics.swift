import Foundation

struct MilkDay: Identifiable {
    var id: Date { date }
    var date: Date
    var formulaML = 0.0
    var breastML = 0.0
    var count = 0
    var totalML: Double { formulaML + breastML }
}
struct MilkTrendPoint: Identifiable {
    var id: Date { date }
    var date: Date
    var averageML: Double
}
struct HourlyFeedCount: Identifiable {
    var id: Int { hour }
    var hour: Int
    var count: Int
}
struct FeedingAnalytics {
    let days: [MilkDay]
    let sessions: [Feeding]
    let hourly: [HourlyFeedCount]
    let rolling: [MilkTrendPoint]
    let start: Date
    let end: Date
    let previousTotalML: Double
    var formulaML: Double { days.reduce(0) { $0 + $1.formulaML } }
    var breastML: Double { days.reduce(0) { $0 + $1.breastML } }
    var totalML: Double { formulaML + breastML }
    var count: Int { sessions.count }
    var activeDays: Int { days.filter { $0.totalML > 0 }.count }
    var averagePerDay: Double { totalML / Double(max(1, days.count)) }
    var averageBottle: Double? { count > 0 ? totalML / Double(count) : nil }
    var averageGap: TimeInterval? { FeedingMath.averageGap(sessions.filter { $0.time >= start }) }
    var longestGap: TimeInterval? {
        let times = sessions.map(\.time).filter { $0 >= start }.sorted()
        return zip(times.dropFirst(), times).map { $0.timeIntervalSince($1) }.max()
    }
    var changePercent: Double? { previousTotalML > 0 ? (totalML - previousTotalML) / previousTotalML * 100 : nil }
    var peak: MilkDay? { days.filter { $0.totalML > 0 }.max { $0.totalML < $1.totalML } }
    var firstLogged: Date? { sessions.map(\.time).min() }
    var largestBottle: Double? { sessions.filter { $0.time >= start }.map(\.totalML).max() }
    var formulaOnlyCount: Int { sessions.filter { $0.formulaML > 0 && $0.breastMilkML == 0 }.count }
    var breastOnlyCount: Int { sessions.filter { $0.breastMilkML > 0 && $0.formulaML == 0 }.count }
    var mixedCount: Int { sessions.filter { $0.formulaML > 0 && $0.breastMilkML > 0 }.count }

    init(_ feedings: [Feeding], dayCount: Int?, now: Date = Date(), calendar: Calendar = .current) {
        struct Event { let id: UUID; let time: Date; let formula: Double; let breast: Double }
        let events: [Event] = feedings.flatMap { feeding -> [Event] in
            let extras = feeding.topUps ?? []
            var result = [Event(id: feeding.id, time: feeding.time,
                formula: max(0, feeding.formulaML - extras.reduce(0) { $0 + $1.formulaML }),
                breast: max(0, feeding.breastMilkML - extras.reduce(0) { $0 + $1.breastMilkML }))]
            result += extras.map { Event(id: feeding.id, time: $0.time, formula: $0.formulaML, breast: $0.breastMilkML) }
            return result.filter { $0.time <= now && $0.formula + $0.breast > 0 }
        }
        let today = calendar.startOfDay(for: now)
        let count = dayCount.map { max(1, $0) } ?? max(1, (calendar.dateComponents([.day], from: calendar.startOfDay(for: events.map(\.time).min() ?? today), to: today).day ?? 0) + 1)
        let lowerBound = calendar.date(byAdding: .day, value: -(count - 1), to: today)!
        start = lowerBound
        end = now
        let priorStart = calendar.date(byAdding: .day, value: -count, to: lowerBound)!
        previousTotalML = events.filter { $0.time >= priorStart && $0.time < lowerBound }.reduce(0) { $0 + $1.formula + $1.breast }
        let selected = events.filter { $0.time >= lowerBound }
        let ids = Set(selected.map(\.id))
        sessions = feedings.filter { ids.contains($0.id) && $0.time <= now }.sorted { $0.time > $1.time }
        let grouped = Dictionary(grouping: events, by: { calendar.startOfDay(for: $0.time) })
        days = (0..<count).map { index in
            let date = calendar.date(byAdding: .day, value: index, to: lowerBound)!
            let rows = grouped[date] ?? []
            return MilkDay(date: date, formulaML: rows.reduce(0) { $0 + $1.formula }, breastML: rows.reduce(0) { $0 + $1.breast }, count: Set(rows.map(\.id)).count)
        }
        rolling = days.map { day in
            let total = (0..<7).reduce(0.0) { sum, offset in
                let date = calendar.date(byAdding: .day, value: -offset, to: day.date)!
                return sum + (grouped[date] ?? []).reduce(0) { $0 + $1.formula + $1.breast }
            }
            return MilkTrendPoint(date: day.date, averageML: total / 7)
        }
        let hourCounts = Dictionary(grouping: sessions.filter { $0.time >= lowerBound }, by: { calendar.component(.hour, from: $0.time) })
        hourly = (0..<24).map { HourlyFeedCount(hour: $0, count: hourCounts[$0]?.count ?? 0) }
    }
    // Long histories use weekly/monthly buckets; totals still cover the complete selected range.
    func chartBuckets(calendar: Calendar = .current) -> [MilkDay] {
        guard days.count > 30 else { return days }
        let component: Calendar.Component = days.count > 180 ? .month : .weekOfYear
        let grouped = Dictionary(grouping: days, by: { calendar.dateInterval(of: component, for: $0.date)!.start })
        return grouped.map { date, rows in
            let uniqueCount = sessions.filter { feeding in
                rows.contains { day in
                    let milk = feeding.milk(on: day.date, calendar: calendar)
                    return milk.formula + milk.breast > 0
                }
            }.count
            return MilkDay(date: date, formulaML: rows.reduce(0) { $0 + $1.formulaML }, breastML: rows.reduce(0) { $0 + $1.breastML }, count: uniqueCount)
        }.sorted { $0.date < $1.date }
    }
}
