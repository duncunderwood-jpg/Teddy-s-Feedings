import SwiftUI

struct SwipeEntryRow<Content: View>: View {
    let id: UUID
    @Binding var openID: UUID?
    var cornerRadius: CGFloat = 22
    let requestEdit: () -> Void
    let requestDelete: () -> Void
    let content: Content
    @State private var translation: CGFloat = 0
    private let reveal: CGFloat = 88
    init(id: UUID, openID: Binding<UUID?>, cornerRadius: CGFloat = 22,
         requestEdit: @escaping () -> Void, requestDelete: @escaping () -> Void,
         @ViewBuilder content: () -> Content) {
        self.id = id; self._openID = openID; self.cornerRadius = cornerRadius
        self.requestEdit = requestEdit; self.requestDelete = requestDelete; self.content = content()
    }
    private var resting: CGFloat { openID == id ? -reveal : 0 }
    var body: some View {
        ZStack {
            HStack(spacing: 0) {
                VStack(spacing: 6) {
                    Image(systemName: "pencil").font(.title3)
                    Text("Edit").font(.caption.bold())
                }.foregroundStyle(.white).frame(width: reveal).frame(maxHeight: .infinity)
                    .background(TeddyTheme.action).accessibilityHidden(true)
                Spacer(minLength: 0)
                Button(role: .destructive) { openID = nil; requestDelete() } label: {
                    VStack(spacing: 6) {
                        Image(systemName: "trash.fill").font(.title3)
                        Text("Delete").font(.caption.bold())
                    }.foregroundStyle(.white).frame(width: reveal).frame(maxHeight: .infinity).background(Color.red)
                }.buttonStyle(.plain).accessibilityHidden(openID != id)
            }
            content.background(TeddyTheme.paper).offset(x: resting + translation)
                .simultaneousGesture(DragGesture(minimumDistance: 20)
                    .onChanged { value in
                        guard abs(value.translation.width) > abs(value.translation.height) * 1.3 else { return }
                        translation = min(reveal, max(-reveal, resting + value.translation.width)) - resting
                    }
                    .onEnded { value in
                        let horizontal = abs(value.translation.width) > abs(value.translation.height) * 1.3
                        if horizontal && resting == 0 && value.translation.width > reveal * 0.55 {
                            openID = nil; translation = 0; requestEdit(); return
                        }
                        if horizontal {
                            if resting + value.translation.width < -reveal / 2 { openID = id }
                            else if openID == id { openID = nil }
                        }
                        translation = 0
                    })
                .accessibilityAction(named: Text("Edit entry")) { requestEdit() }
                .accessibilityAction(named: Text("Delete entry")) { requestDelete() }
        }.clipShape(RoundedRectangle(cornerRadius: cornerRadius))
            .animation(.easeOut(duration: 0.18), value: openID)
            .onChange(of: openID) { _, _ in translation = 0 }
    }
}
