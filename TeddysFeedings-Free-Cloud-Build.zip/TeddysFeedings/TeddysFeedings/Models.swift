import Foundation

enum VolumeUnit: String, Codable, CaseIterable, Identifiable {
    case ounces = "oz"
    case milliliters = "mL"
    var id: String { rawValue }
    var symbol: String { rawValue }
    var millilitersPerUnit: Double { self == .ounces ? 29.5735295625 : 1 }
    func toMilliliters(_ value: Double) -> Double { value * millilitersPerUnit }
    func fromMilliliters(_ value: Double) -> Double { value / millilitersPerUnit }
    func display(_ ml: Double) -> String {
        let number = fromMilliliters(ml)
        return "\(number.formatted(.number.precision(.fractionLength(0...1)))) \(symbol)"
    }
}

struct Feeding: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var time: Date
    var formulaML: Double
    var breastMilkML: Double
    var notes: String = ""
    var offeredFormulaML: Double? = nil
    var offeredBreastMilkML: Double? = nil
    var lastTopUpAt: Date? = nil
    var topUps: [FeedingTopUp]? = nil
    var lastMilkAt: Date { max(lastTopUpAt ?? time, time) }
    var offeredTotalML: Double? {
        guard let formula = offeredFormulaML, let breast = offeredBreastMilkML else { return nil }
        return formula + breast
    }
    func milk(on day: Date, calendar: Calendar = .current) -> (formula: Double, breast: Double) {
        let extras = topUps ?? []
        let baseFormula = max(0, formulaML - extras.reduce(0) { $0 + $1.formulaML })
        let baseBreast = max(0, breastMilkML - extras.reduce(0) { $0 + $1.breastMilkML })
        let today = extras.filter { calendar.isDate($0.time, inSameDayAs: day) }
        return ((calendar.isDate(time, inSameDayAs: day) ? baseFormula : 0) + today.reduce(0) { $0 + $1.formulaML },
                (calendar.isDate(time, inSameDayAs: day) ? baseBreast : 0) + today.reduce(0) { $0 + $1.breastMilkML })
    }
    var totalML: Double { formulaML + breastMilkML }
    var category: String {
        if formulaML > 0 && breastMilkML > 0 { return "Mixed feeding" }
        return formulaML > 0 ? "Formula" : "Breast milk"
    }
}

struct TeddySettings: Codable, Equatable {
    var babyName: String = "Teddy"
    var birthDate: Date? = nil
    var unit: VolumeUnit = .ounces
    var remindersEnabled = false
    var reminderIntervalMinutes = 180
    var reminderSoundEnabled = true
    var clinicianTarget: ClinicianFeedingTarget? = nil

    // Migrate data written by version 1, which did not have a sound preference.
    init() {}

    private enum CodingKeys: String, CodingKey {
        case babyName, birthDate, unit, remindersEnabled, reminderIntervalMinutes, reminderSoundEnabled, clinicianTarget
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        babyName = try values.decodeIfPresent(String.self, forKey: .babyName) ?? "Teddy"
        birthDate = try values.decodeIfPresent(Date.self, forKey: .birthDate)
        unit = try values.decodeIfPresent(VolumeUnit.self, forKey: .unit) ?? .ounces
        remindersEnabled = try values.decodeIfPresent(Bool.self, forKey: .remindersEnabled) ?? false
        reminderIntervalMinutes = try values.decodeIfPresent(Int.self, forKey: .reminderIntervalMinutes) ?? 180
        reminderSoundEnabled = try values.decodeIfPresent(Bool.self, forKey: .reminderSoundEnabled) ?? true
        clinicianTarget = try values.decodeIfPresent(ClinicianFeedingTarget.self, forKey: .clinicianTarget)
    }
}

struct FeedingDraft: Identifiable {
    let id = UUID()
    var originalFeeding: Feeding? = nil
    var editingID: UUID? = nil
    var topUpForID: UUID? = nil
    var topUps: [FeedingTopUp]? = nil
    var offeredFormulaML: Double? = nil
    var offeredBreastMilkML: Double? = nil
    var lastTopUpAt: Date? = nil
    var time: Date = Date()
    var formulaML: Double = 0
    var breastMilkML: Double = 0
    var notes: String = ""

    init() {}
    init(formulaML: Double, breastMilkML: Double = 0) {
        self.formulaML = formulaML
        self.breastMilkML = breastMilkML
    }
    init(feeding: Feeding) {
        originalFeeding = feeding
        editingID = feeding.id
        time = feeding.time
        formulaML = feeding.formulaML
        breastMilkML = feeding.breastMilkML
        notes = feeding.notes
        offeredFormulaML = feeding.offeredFormulaML
        offeredBreastMilkML = feeding.offeredBreastMilkML
        lastTopUpAt = feeding.lastTopUpAt
        topUps = feeding.topUps
    }
    static func topUp(for feeding: Feeding) -> FeedingDraft {
        var draft = FeedingDraft()
        draft.topUpForID = feeding.id
        return draft
    }
    func feeding() -> Feeding {
        Feeding(id: editingID ?? UUID(), time: time, formulaML: formulaML,
                breastMilkML: breastMilkML, notes: notes.trimmingCharacters(in: .whitespacesAndNewlines),
                offeredFormulaML: offeredFormulaML, offeredBreastMilkML: offeredBreastMilkML, lastTopUpAt: lastTopUpAt, topUps: topUps)
    }
}

extension Date {
    var shortFeedingTime: String { formatted(date: .omitted, time: .shortened) }
    var shortFeedingDate: String { formatted(.dateTime.month(.abbreviated).day()) }
}

enum FeedingMath {
    static func intervalText(_ seconds: TimeInterval) -> String {
        let minutes = max(0, Int(seconds / 60))
        if minutes < 60 { return "\(minutes)m" }
        let hours = minutes / 60
        let remaining = minutes % 60
        return remaining == 0 ? "\(hours)h" : "\(hours)h \(remaining)m"
    }
    static func averageGap(_ feedings: [Feeding]) -> TimeInterval? {
        let sorted = feedings.sorted { $0.time < $1.time }
        guard sorted.count > 1 else { return nil }
        let deltas = zip(sorted.dropFirst(), sorted).map { $0.time.timeIntervalSince($1.time) }
        return deltas.reduce(0, +) / Double(deltas.count)
    }
}


// Read current records when the reminder opens, including edits made since scheduling.
enum FeedingReminderMessage {
    static func text(feedings: [Feeding], unit: VolumeUnit, birthDate: Date? = nil, clinicianTarget: ClinicianFeedingTarget? = nil, now: Date = Date()) -> String {
        let suggestion = FeedingPlan.message(feedings: feedings, unit: unit, birthDate: birthDate, target: clinicianTarget, now: now, concise: true)
        guard let last = feedings.filter({ $0.lastMilkAt <= now }).max(by: { $0.lastMilkAt < $1.lastMilkAt }) else {
            return "No previous feeding has been logged yet.\n\n" + suggestion
        }
        let timestamp = last.lastMilkAt.formatted(date: .abbreviated, time: .shortened)
        return "Last milk: \(timestamp)\n\(last.lastTopUpAt == nil ? "" : "Includes top-up; bottle started at \(last.time.shortFeedingTime).\n")Formula: \(unit.display(last.formulaML))\nBreast milk: \(unit.display(last.breastMilkML))\nTotal: \(unit.display(last.totalML))\n\n" + suggestion
    }
}


// Educational bottle-feeding ranges; never split a range between formula and breast milk.
// Sources: AAP How Often and How Much Should Your Baby Eat?; Nemours feed13m.
enum AgeFeedingGuide {
    static func text(birthDate: Date?, unit: VolumeUnit, now: Date = Date(), calendar: Calendar = .current, concise: Bool = false) -> String {
        guard let birthDate, birthDate <= now else {
            return "Next bottle: add Teddy’s birth date in Settings for an age-based amount guide."
        }
        let days = calendar.dateComponents([.day], from: calendar.startOfDay(for: birthDate), to: calendar.startOfDay(for: now)).day ?? 0
        let months = calendar.dateComponents([.month], from: birthDate, to: now).month ?? 0
        let age = months == 0 ? "\(days) day\(days == 1 ? "" : "s")" : "\(months) month\(months == 1 ? "" : "s")"
        guard months < 12 else {
            return "Teddy’s age: \(age). Next milk amount: follow his pediatrician’s plan as meals and milk needs change after infancy."
        }
        let range: String
        if days < 2 { range = unit.display(VolumeUnit.ounces.toMilliliters(0.5)) }
        else {
            let ounces: (Double, Double)
            switch months {
            case 0: ounces = (1, 2)
            case 1: ounces = (3, 4)
            case 2: ounces = (4, 5)
            default: ounces = (6, 8)
            }
            let lower = unit.fromMilliliters(VolumeUnit.ounces.toMilliliters(ounces.0))
            let upper = unit.fromMilliliters(VolumeUnit.ounces.toMilliliters(ounces.1))
            let precision = FloatingPointFormatStyle<Double>.number.precision(.fractionLength(0...1))
            range = "\(lower.formatted(precision))–\(upper.formatted(precision)) \(unit.symbol)"
        }
        if concise {
            return "Teddy’s age: \(age)\nNext bottle guide: about \(range) total milk.\nFor healthy, full-term babies. Follow his pediatrician’s plan and hunger/fullness cues; don’t force him to finish."
        }
        return "Teddy’s age: \(age)\nNext bottle guide: about \(range) total milk.\n\nGeneral age reference for healthy, full-term babies, not a required amount. Needs vary with weight and feeding frequency. Follow his pediatrician’s plan and hunger/fullness cues; don’t force him to finish."
    }
}


struct ClinicianFeedingTarget: Codable, Equatable {
    var minimumML: Double
    var maximumML: Double
    var isValid: Bool {
        minimumML.isFinite && maximumML.isFinite && minimumML > 0 && maximumML >= minimumML && maximumML <= 1000
    }
    func display(unit: VolumeUnit) -> String {
        minimumML == maximumML ? unit.display(minimumML) : "\(unit.display(minimumML)) to \(unit.display(maximumML))"
    }
}

enum FeedingPlan {
    static func typicalML(_ feedings: [Feeding], now: Date = Date()) -> Double? {
        let values = feedings.filter { $0.lastMilkAt <= now && $0.lastMilkAt >= now.addingTimeInterval(-7 * 86400) && $0.totalML > 0 }
            .sorted { $0.lastMilkAt > $1.lastMilkAt }.prefix(10).map(\.totalML).sorted()
        guard values.count >= 3 else { return nil }
        let middle = values.count / 2
        return values.count.isMultiple(of: 2) ? (values[middle - 1] + values[middle]) / 2 : values[middle]
    }
    static func message(feedings: [Feeding], unit: VolumeUnit, birthDate: Date?, target: ClinicianFeedingTarget?, now: Date = Date(), concise: Bool = false) -> String {
        var parts: [String] = []
        if let target, target.isValid {
            parts.append("Your pediatrician-set bottle target: \(target.display(unit: unit)) total milk. Follow the plan your clinician gave you and Teddy’s hunger/fullness cues.")
        } else {
            parts.append(AgeFeedingGuide.text(birthDate: birthDate, unit: unit, now: now, concise: concise))
        }
        if let typical = typicalML(feedings, now: now) {
            if concise { parts.append("Usual recent bottle: \(unit.display(typical)) actually drank (history, not a target).") }
            else { parts.append("Recent usual bottle: \(unit.display(typical)) actually drank (middle amount of up to 10 bottles in the past 7 days; a history reference, not a required amount).") }
        }
        return parts.joined(separator: "\n\n")
    }
    static func addingTopUp(_ topUp: Feeding, to original: Feeding) -> Feeding? {
        guard topUp.formulaML.isFinite, topUp.breastMilkML.isFinite, topUp.formulaML >= 0, topUp.breastMilkML >= 0,
              topUp.totalML > 0, original.totalML + topUp.totalML <= 1000,
              topUp.time >= original.lastMilkAt, topUp.time <= Date().addingTimeInterval(60) else { return nil }
        var combined = original
        combined.formulaML += topUp.formulaML
        combined.breastMilkML += topUp.breastMilkML
        // Unknown offered amounts stay unknown; never invent an offered volume.
        if let old = original.offeredFormulaML, let extra = topUp.offeredFormulaML { combined.offeredFormulaML = old + extra }
        else { combined.offeredFormulaML = nil }
        if let old = original.offeredBreastMilkML, let extra = topUp.offeredBreastMilkML { combined.offeredBreastMilkML = old + extra }
        else { combined.offeredBreastMilkML = nil }
        combined.lastTopUpAt = topUp.time
        combined.topUps = (original.topUps ?? []) + [FeedingTopUp(time: topUp.time, formulaML: topUp.formulaML, breastMilkML: topUp.breastMilkML)]
        let addition = "Top-up at \(topUp.time.shortFeedingTime): \(VolumeUnit.milliliters.display(topUp.totalML))." + (topUp.notes.isEmpty ? "" : " " + topUp.notes)
        combined.notes = [original.notes, addition].filter { !$0.isEmpty }.joined(separator: "\n")
        return combined
    }
}


struct FeedingTopUp: Codable, Equatable {
    var time: Date
    var formulaML: Double
    var breastMilkML: Double
}

// Pumping is its own log: producing milk never inserts a feeding or changes feeding reminders.
struct PumpingSession: Identifiable, Codable, Equatable {
    var id = UUID()
    var endedAt: Date
    var amountML: Double
    var durationMinutes: Int = 30
    var notes: String = ""
    var startedAt: Date { endedAt.addingTimeInterval(-Double(durationMinutes) * 60) }
    func isValid(now: Date = Date()) -> Bool {
        amountML.isFinite && amountML >= 0 && amountML <= 2000 &&
        (30...180).contains(durationMinutes) && durationMinutes.isMultiple(of: 30) && endedAt <= now.addingTimeInterval(60)
    }
}

struct PumpingBucket: Identifiable {
    var id: Date { date }
    var date: Date
    var amountML: Double
    var count: Int
}

enum PumpingMath {
    static func days(_ sessions: [PumpingSession], now: Date = Date(), calendar: Calendar = .current) -> [PumpingBucket] {
        (0..<7).reversed().compactMap { offset in
            guard let date = calendar.date(byAdding: .day, value: -offset, to: calendar.startOfDay(for: now)) else { return nil }
            let matching = sessions.filter { $0.endedAt <= now && calendar.isDate($0.endedAt, inSameDayAs: date) }
            return PumpingBucket(date: date, amountML: matching.reduce(0) { $0 + $1.amountML }, count: matching.count)
        }
    }
    static func halfHours(_ sessions: [PumpingSession], day: Date = Date(), calendar: Calendar = .current) -> [PumpingBucket] {
        let start = calendar.startOfDay(for: day)
        let matching = sessions.filter { calendar.isDate($0.endedAt, inSameDayAs: day) && $0.endedAt <= Date() }
        let grouped = Dictionary(grouping: matching) { session in
            start.addingTimeInterval(floor(session.endedAt.timeIntervalSince(start) / 1800) * 1800)
        }
        return grouped.map { PumpingBucket(date: $0.key, amountML: $0.value.reduce(0) { $0 + $1.amountML }, count: $0.value.count) }.sorted { $0.date < $1.date }
    }
    static func percentage(_ amount: Double, total: Double) -> String {
        guard total > 0 else { return "—" }
        return (amount / total).formatted(.percent.precision(.fractionLength(0...1)))
    }
}

enum PumpingSpeechError: Error, LocalizedError {
    case unclear, invalid
    var errorDescription: String? {
        switch self {
        case .unclear: return "Say one amount, like ‘I pumped 3 ounces’ or ‘I pumped 90 milliliters’."
        case .invalid: return "Please give a valid amount from 0 to 2000 milliliters."
        }
    }
}

enum PumpingSpeechParser {
    static func parse(_ text: String, defaultUnit: VolumeUnit = .ounces) throws -> Double {
        var input = text.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        input = input.replacingOccurrences(of: #"^(?:hey siri[, ]*)?(?:log pumping[, .]*)?(?:i\s+)?pumped\s+"#, with: "", options: .regularExpression)
        input = input.replacingOccurrences(of: "fluid ounces", with: "ounces")
        input = input.replacingOccurrences(of: #"\s+(?:of\s+)?(?:breast\s*milk|milk)\s*[.!]?$"#, with: "", options: .regularExpression)
        input = input.replacingOccurrences(of: #"[.!]+$"#, with: "", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
        let words = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"]
        for (number, word) in words.enumerated() {
            input = input.replacingOccurrences(of: "^" + word + #"\s+and\s+a\s+half\b"#, with: "\(number).5", options: .regularExpression)
            input = input.replacingOccurrences(of: "^" + word + "\\b", with: "\(number)", options: .regularExpression)
        }
        input = input.replacingOccurrences(of: #"^(?:a\s+)?half(?:\s+an?)?\b"#, with: "0.5", options: .regularExpression)
        let regex = try NSRegularExpression(pattern: #"^((?:\d+(?:[.,]\d+)?|[.,]\d+))\s*(oz|ounces?|ml|millilit(?:er|re)s?)?$"#)
        let ns = input as NSString
        guard let match = regex.firstMatch(in: input, range: NSRange(location: 0, length: ns.length)),
              let value = Double(ns.substring(with: match.range(at: 1)).replacingOccurrences(of: ",", with: ".")) else { throw PumpingSpeechError.unclear }
        let unitText = match.range(at: 2).location == NSNotFound ? "" : ns.substring(with: match.range(at: 2))
        let unit = unitText.isEmpty ? defaultUnit : (unitText.hasPrefix("m") ? .milliliters : .ounces)
        let ml = unit.toMilliliters(value)
        guard ml.isFinite, ml >= 0, ml <= 2000 else { throw PumpingSpeechError.invalid }
        return ml
    }
}
