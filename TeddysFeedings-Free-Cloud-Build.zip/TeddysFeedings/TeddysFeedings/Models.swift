import Foundation

enum VolumeUnit: String, Codable, CaseIterable, Identifiable {
    case ounces = "oz"
    case milliliters = "mL"
    var id: String { rawValue }
    var symbol: String { rawValue }
    var millilitersPerUnit: Double { self == .ounces ? 29.5735295625 : 1 }
    func toMilliliters(_ value: Double) -> Double { value * millilitersPerUnit }
    func fromMilliliters(_ value: Double) -> Double { value / millilitersPerUnit }
    func display(_ ml: Double) -> String {
        let number = fromMilliliters(ml)
        return "\(number.formatted(.number.precision(.fractionLength(0...1)))) \(symbol)"
    }
}

struct Feeding: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var time: Date
    var formulaML: Double
    var breastMilkML: Double
    var notes: String = ""
    var totalML: Double { formulaML + breastMilkML }
    var category: String {
        if formulaML > 0 && breastMilkML > 0 { return "Mixed feeding" }
        return formulaML > 0 ? "Formula" : "Breast milk"
    }
}

struct TeddySettings: Codable, Equatable {
    var babyName: String = "Teddy"
    var birthDate: Date? = nil
    var unit: VolumeUnit = .ounces
    var remindersEnabled = false
    var reminderIntervalMinutes = 180
    var reminderSoundEnabled = true

    // Migrate data written by version 1, which did not have a sound preference.
    init() {}

    private enum CodingKeys: String, CodingKey {
        case babyName, birthDate, unit, remindersEnabled, reminderIntervalMinutes, reminderSoundEnabled
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        babyName = try values.decodeIfPresent(String.self, forKey: .babyName) ?? "Teddy"
        birthDate = try values.decodeIfPresent(Date.self, forKey: .birthDate)
        unit = try values.decodeIfPresent(VolumeUnit.self, forKey: .unit) ?? .ounces
        remindersEnabled = try values.decodeIfPresent(Bool.self, forKey: .remindersEnabled) ?? false
        reminderIntervalMinutes = try values.decodeIfPresent(Int.self, forKey: .reminderIntervalMinutes) ?? 180
        reminderSoundEnabled = try values.decodeIfPresent(Bool.self, forKey: .reminderSoundEnabled) ?? true
    }
}

struct FeedingDraft: Identifiable {
    let id = UUID()
    var editingID: UUID? = nil
    var time: Date = Date()
    var formulaML: Double = 0
    var breastMilkML: Double = 0
    var notes: String = ""

    init() {}
    init(formulaML: Double, breastMilkML: Double = 0) {
        self.formulaML = formulaML
        self.breastMilkML = breastMilkML
    }
    init(feeding: Feeding) {
        editingID = feeding.id
        time = feeding.time
        formulaML = feeding.formulaML
        breastMilkML = feeding.breastMilkML
        notes = feeding.notes
    }
    func feeding() -> Feeding {
        Feeding(id: editingID ?? UUID(), time: time, formulaML: formulaML,
                breastMilkML: breastMilkML, notes: notes.trimmingCharacters(in: .whitespacesAndNewlines))
    }
}

extension Date {
    var shortFeedingTime: String { formatted(date: .omitted, time: .shortened) }
    var shortFeedingDate: String { formatted(.dateTime.month(.abbreviated).day()) }
}

enum FeedingMath {
    static func intervalText(_ seconds: TimeInterval) -> String {
        let minutes = max(0, Int(seconds / 60))
        if minutes < 60 { return "\(minutes)m" }
        let hours = minutes / 60
        let remaining = minutes % 60
        return remaining == 0 ? "\(hours)h" : "\(hours)h \(remaining)m"
    }
    static func averageGap(_ feedings: [Feeding]) -> TimeInterval? {
        let sorted = feedings.sorted { $0.time < $1.time }
        guard sorted.count > 1 else { return nil }
        let deltas = zip(sorted.dropFirst(), sorted).map { $0.time.timeIntervalSince($1.time) }
        return deltas.reduce(0, +) / Double(deltas.count)
    }
}


// Read current records when the reminder opens, including edits made since scheduling.
enum FeedingReminderMessage {
    static func text(feedings: [Feeding], unit: VolumeUnit, birthDate: Date? = nil, now: Date = Date()) -> String {
        let suggestion = AgeFeedingGuide.text(birthDate: birthDate, unit: unit, now: now)
        guard let last = feedings.filter({ $0.time <= now }).max(by: { $0.time < $1.time }) else {
            return "No previous feeding has been logged yet.\n\n" + suggestion
        }
        let timestamp = last.time.formatted(date: .abbreviated, time: .shortened)
        return "Last feeding: \(timestamp)\nFormula: \(unit.display(last.formulaML))\nBreast milk: \(unit.display(last.breastMilkML))\nTotal: \(unit.display(last.totalML))\n\n" + suggestion
    }
}


// Educational bottle-feeding ranges; never split a range between formula and breast milk.
// Sources: AAP How Often and How Much Should Your Baby Eat?; Nemours feed13m.
enum AgeFeedingGuide {
    static func text(birthDate: Date?, unit: VolumeUnit, now: Date = Date(), calendar: Calendar = .current) -> String {
        guard let birthDate, birthDate <= now else {
            return "Next bottle: add Teddy’s birth date in Settings for an age-based amount guide."
        }
        let days = calendar.dateComponents([.day], from: calendar.startOfDay(for: birthDate), to: calendar.startOfDay(for: now)).day ?? 0
        let months = calendar.dateComponents([.month], from: birthDate, to: now).month ?? 0
        let age = months == 0 ? "\(days) day\(days == 1 ? "" : "s")" : "\(months) month\(months == 1 ? "" : "s")"
        guard months < 12 else {
            return "Teddy’s age: \(age). Next milk amount: follow his pediatrician’s plan as meals and milk needs change after infancy."
        }
        let range: String
        if days < 2 { range = unit.display(VolumeUnit.ounces.toMilliliters(0.5)) }
        else {
            let ounces: (Double, Double)
            switch months {
            case 0: ounces = (1, 2)
            case 1: ounces = (3, 4)
            case 2: ounces = (4, 5)
            default: ounces = (6, 8)
            }
            let lower = unit.fromMilliliters(VolumeUnit.ounces.toMilliliters(ounces.0))
            let upper = unit.fromMilliliters(VolumeUnit.ounces.toMilliliters(ounces.1))
            let precision = FloatingPointFormatStyle<Double>.number.precision(.fractionLength(0...1))
            range = "\(lower.formatted(precision))–\(upper.formatted(precision)) \(unit.symbol)"
        }
        return "Teddy’s age: \(age)\nNext bottle guide: about \(range) total milk.\n\nGeneral age reference for healthy, full-term babies, not a required amount. Needs vary with weight and feeding frequency. Follow his pediatrician’s plan and hunger/fullness cues; don’t force him to finish."
    }
}
