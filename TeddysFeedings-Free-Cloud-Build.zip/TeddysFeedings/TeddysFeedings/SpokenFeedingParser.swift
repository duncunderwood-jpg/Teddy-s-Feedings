import Foundation

struct ParsedSpokenFeeding {
    let formulaML: Double
    let breastMilkML: Double
    let time: Date
}

enum SpokenFeedingError: Error, LocalizedError {
    case missingVolume, ambiguousMixedVolume, invalidTime, invalidVolume
    var errorDescription: String? {
        switch self {
        case .missingVolume: return "Say an amount and milk type, like '3 ounces formula and 1 ounce breast milk at 8 PM'."
        case .ambiguousMixedVolume: return "For a mixed bottle, say a separate amount for formula and breast milk."
        case .invalidTime: return "I couldn't understand the time. Try 'at 8:15 PM', or leave the time out to log now."
        case .invalidVolume: return "That amount doesn't look right. Please say amounts between 0 and 1000 mL in total."
        }
    }
}

enum SpokenFeedingParser {
    // Amounts are attached to their own milk type; no guessed split of a combined bottle.
    static func parse(_ text: String, now: Date = Date(), calendar: Calendar = .current) throws -> ParsedSpokenFeeding {
        let input = text.lowercased()
            .replacingOccurrences(of: "fluid ounces", with: "oz")
            .replacingOccurrences(of: "fl. oz.", with: "oz")
            .replacingOccurrences(of: "breastmilk", with: "breast milk")
        let amount = #"(\d+(?:[.,]\d+)?)\s*(oz|ounces?|ml|millilit(?:er|re)s?)?\s*(?:of\s+)?(breast\s*milk|expressed\s*milk|formula)\b"#
        let reverse = #"\b(breast\s*milk|expressed\s*milk|formula)\s*(?:of\s+)?(\d+(?:[.,]\d+)?)\s*(oz|ounces?|ml|millilit(?:er|re)s?)?"#
        var formulaML = 0.0, breastML = 0.0
        var matchedTypes: Set<String> = []
        let ns = input as NSString
        let directRegex = try NSRegularExpression(pattern: amount)
        let reverseRegex = try NSRegularExpression(pattern: reverse)
        let full = NSRange(location: 0, length: ns.length)
        var taken: [NSRange] = []

        func contribute(value: String, unit: String, milkType: String) {
            let numeric = Double(value.replacingOccurrences(of: ",", with: ".")) ?? 0
            let ml = unit.lowercased().hasPrefix("m") ? numeric : numeric * 29.5735295625
            if milkType.contains("formula") { formulaML += ml; matchedTypes.insert("formula") }
            else { breastML += ml; matchedTypes.insert("breast") }
        }
        for match in directRegex.matches(in: input, range: full) {
            taken.append(match.range)
            contribute(value: ns.substring(with: match.range(at: 1)),
                       unit: match.range(at: 2).location == NSNotFound ? "oz" : ns.substring(with: match.range(at: 2)),
                       milkType: ns.substring(with: match.range(at: 3)))
        }
        for match in reverseRegex.matches(in: input, range: full) {
            guard !taken.contains(where: { NSIntersectionRange($0, match.range).length > 0 }) else { continue }
            contribute(value: ns.substring(with: match.range(at: 2)),
                       unit: match.range(at: 3).location == NSNotFound ? "oz" : ns.substring(with: match.range(at: 3)),
                       milkType: ns.substring(with: match.range(at: 1)))
        }
        if matchedTypes.isEmpty { throw SpokenFeedingError.missingVolume }
        if (input.contains("formula") && (input.contains("breast milk") || input.contains("expressed milk")))
            && matchedTypes.count == 1 { throw SpokenFeedingError.ambiguousMixedVolume }
        guard formulaML + breastML > 0, formulaML + breastML <= 1000 else { throw SpokenFeedingError.invalidVolume }
        let timestamp = try parseTime(input, now: now, calendar: calendar)
        return ParsedSpokenFeeding(formulaML: formulaML, breastMilkML: breastML, time: timestamp)
    }

    private static func parseTime(_ text: String, now: Date, calendar: Calendar) throws -> Date {
        let pattern = #"\b(?:at|around)\s+(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?\b"#
        let regex = try NSRegularExpression(pattern: pattern)
        let ns = text as NSString
        let full = NSRange(location: 0, length: ns.length)
        guard let match = regex.firstMatch(in: text, range: full) else { return now }
        let hours = Int(ns.substring(with: match.range(at: 1))) ?? -1
        let minutes = match.range(at: 2).location == NSNotFound ? 0 : (Int(ns.substring(with: match.range(at: 2))) ?? -1)
        guard (0...23).contains(hours), (0...59).contains(minutes) else { throw SpokenFeedingError.invalidTime }
        let ampm = match.range(at: 3).location == NSNotFound ? "" : ns.substring(with: match.range(at: 3)).replacingOccurrences(of: ".", with: "")
        guard ampm.isEmpty || (1...12).contains(hours) else { throw SpokenFeedingError.invalidTime }
        let possibleHours: [Int]
        if ampm.hasPrefix("a") { possibleHours = [hours % 12] }
        else if ampm.hasPrefix("p") { possibleHours = [(hours % 12) + 12] }
        else if hours > 12 { possibleHours = [hours] }
        else if hours == 0 { possibleHours = [0] }
        else { possibleHours = [hours % 12, (hours % 12) + 12] }
        let base = calendar.startOfDay(for: now)
        let requestedYesterday = text.contains("yesterday")
        let explicitToday = text.contains("today")
        let days = requestedYesterday ? [-1] : (explicitToday ? [0] : [0, -1])
        let candidates: [Date] = days.flatMap { offset -> [Date] in
            guard let day = calendar.date(byAdding: .day, value: offset, to: base) else { return [] }
            return possibleHours.compactMap { calendar.date(byAdding: .minute, value: $0 * 60 + minutes, to: day) }
        }
        guard let selected = candidates.filter({ $0 <= now.addingTimeInterval(60) }).max() else {
            throw SpokenFeedingError.invalidTime
        }
        return selected
    }
}
