import SwiftUI

struct FeedingGuideView: View {
    @EnvironmentObject private var store: FeedingStore
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Label("Feeding guide", systemImage: "book.closed.fill")
                        .font(.system(size: 27, weight: .heavy, design: .rounded)).foregroundStyle(TeddyTheme.cocoa)
                    Text("A little reassurance for your bottle breaks").font(.subheadline).foregroundStyle(TeddyTheme.muted)
                    TeddyCard(color: TeddyTheme.paleHoney) {
                        Text("Teddy’s current bottle guide").font(.headline)
                        Text(FeedingPlan.message(feedings: store.feedings, unit: store.settings.unit, birthDate: store.settings.birthDate, target: store.settings.clinicianTarget, concise: true)).font(.subheadline)
                        Text("Set his birthdate or a pediatrician-provided target in Settings.").font(.caption).foregroundStyle(TeddyTheme.muted)
                    }
                    TeddyCard {
                        Label("Formula bottles", systemImage: "drop.fill").font(.headline).foregroundStyle(TeddyTheme.brown)
                        Text("For babies receiving only formula, CDC suggests starting with 1–2 oz every 2–3 hours in the first days. Amounts and timing change as babies grow.").font(.subheadline)
                        Link("Read CDC’s formula feeding guide", destination: URL(string: "https://www.cdc.gov/infant-toddler-nutrition/formula-feeding/how-much-and-how-often.html")!).foregroundStyle(TeddyTheme.action)
                    }
                    TeddyCard {
                        Label { Text("Breast milk & baby’s cues") } icon: { BreastMilkIcon().frame(width: 24, height: 24).foregroundStyle(TeddyTheme.rose) }
                            .font(.headline)
                        Text("Breastfeeding patterns vary. Follow hunger and fullness cues and your pediatrician’s plan. Nursing frequency is not a fixed bottle-volume target.").font(.subheadline)
                        Link("Read CDC’s breastfeeding guide", destination: URL(string: "https://www.cdc.gov/infant-toddler-nutrition/breastfeeding/how-much-and-how-often.html")!).foregroundStyle(TeddyTheme.action)
                    }
                    TeddyCard {
                        Label("A gentle reminder", systemImage: "heart.fill").font(.headline)
                        Text("Your charts describe logged history, not feeding goals. Don’t force a bottle to reach a chart average. For prematurity, growth concerns, or scheduled newborn feeds, use Teddy’s clinician-specific plan.").font(.subheadline)
                    }
                }.padding(18)
            }.background(TeddyTheme.cream.ignoresSafeArea()).toolbar(.hidden, for: .navigationBar)
        }
    }
}
