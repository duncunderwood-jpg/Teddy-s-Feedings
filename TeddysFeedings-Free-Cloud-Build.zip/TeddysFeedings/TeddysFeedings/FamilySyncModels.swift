import Foundation

struct SharedBabyProfile: Codable, Equatable {
    var babyName: String
    var birthDate: Date?
    var clinicianTarget: ClinicianFeedingTarget?
    init(_ settings: TeddySettings) {
        babyName = settings.babyName; birthDate = settings.birthDate; clinicianTarget = settings.clinicianTarget
    }
}

struct FamilyRemoteRecord: Codable, Equatable {
    var payload: String
    var deleted: Bool
    var revision: Int
    var operation: String
    var author: String
}

struct FamilySyncRecord: Codable, Identifiable, Equatable {
    var id: String // feeding/UUID, pumping/UUID or profile/baby
    var value: FamilyRemoteRecord
    var baseRevision: Int
    var dirty: Bool
    var conflict: FamilyRemoteRecord?
}

// One durable outbox item per record, with an optimistic revision and stable operation ID.
// A later local change is never acknowledged by an earlier in-flight upload.
struct FamilySyncLedger: Codable {
    var records: [String: FamilySyncRecord] = [:]
    mutating func stage(id: String, payload: String, deleted: Bool = false, author: String) {
        if let old = records[id], old.value.payload == payload, old.value.deleted == deleted { return }
        let old = records[id]
        records[id] = FamilySyncRecord(id: id,
            value: FamilyRemoteRecord(payload: payload, deleted: deleted, revision: old?.baseRevision ?? 0,
                                      operation: UUID().uuidString, author: author),
            baseRevision: old?.baseRevision ?? 0, dirty: true, conflict: old?.conflict)
    }
    mutating func receive(id: String, remote: FamilyRemoteRecord) {
        guard var local = records[id] else {
            records[id] = FamilySyncRecord(id: id, value: remote, baseRevision: remote.revision, dirty: false)
            return
        }
        guard remote.revision >= local.baseRevision else { return }
        if local.dirty {
            if remote.operation == local.value.operation {
                local.value = remote; local.baseRevision = remote.revision; local.dirty = false; local.conflict = nil
            } else if remote.revision > local.baseRevision {
                local.conflict = remote
            }
        } else {
            local.value = remote; local.baseRevision = remote.revision
        }
        records[id] = local
    }
    mutating func acknowledge(id: String, sent: FamilySyncRecord, remote: FamilyRemoteRecord) {
        guard var current = records[id] else { return }
        if current.value.operation == sent.value.operation { receive(id: id, remote: remote) }
        else if remote.operation == sent.value.operation {
            // A local edit happened during upload. It is based on our own acknowledged write.
            current.baseRevision = remote.revision
            if current.conflict?.operation == remote.operation { current.conflict = nil }
            records[id] = current
        } else { receive(id: id, remote: remote) }
    }
    mutating func resolve(id: String, keepLocal: Bool) {
        guard var record = records[id], let remote = record.conflict else { return }
        record.baseRevision = remote.revision; record.conflict = nil
        if keepLocal {
            record.value.operation = UUID().uuidString; record.dirty = true
        } else { record.value = remote; record.dirty = false }
        records[id] = record
    }
    var pending: [FamilySyncRecord] { records.values.filter { $0.dirty && $0.conflict == nil }.sorted { $0.id < $1.id } }
    var conflicts: [FamilySyncRecord] { records.values.filter { $0.conflict != nil }.sorted { $0.id < $1.id } }
    static func encode<T: Encodable>(_ value: T) -> String? {
        let encoder = JSONEncoder(); encoder.outputFormatting = .sortedKeys
        guard let data = try? encoder.encode(value) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    static func decode<T: Decodable>(_ payload: String, as type: T.Type) -> T? {
        try? JSONDecoder().decode(type, from: Data(payload.utf8))
    }
}

struct FamilyJournalSeed {
    let feedings: [Feeding]
    let pumping: [PumpingSession]
    init(feedings: [Feeding], pumping: [PumpingSession], confirmedRealRecords: Bool) {
        self.feedings = confirmedRealRecords ? feedings : []
        self.pumping = confirmedRealRecords ? pumping : []
    }
}
