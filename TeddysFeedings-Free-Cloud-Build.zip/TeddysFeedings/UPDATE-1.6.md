# Teddy’s Feedings 1.6
- Feeding chart includes actual formula and breast-milk amounts centered inside their colored bar segments; combined total stays above each bar.
- Seven-day summary adds each milk type’s percentage of actual consumed volume. Empty totals show a dash.
- New Pumping tab stores independent sessions with amount, end time, calculated start, notes, and 30-minute duration increments (default 30 minutes).
- Daily and seven-day pumping graphs, today’s half-hour buckets, total/average volumes, count, duration, active days, peak day, session edits/deletion, and CSV export.
- Pumping is never counted as feeding, and never reschedules feeding reminders.
- Siri action Log pumping accepts a single dictated amount, saves now as the session end and 30 minutes as duration, then confirms after persisted save.
- Automatic Siri trigger includes app name. Personal shortcut named Log pumping with Dictate Text → Log pumping supports the short trigger; requires an on-device setup. A single continuous invocation is not guaranteed by iOS.
- Existing feeding data and the approved lullaby retained. Native compilation passed in Codemagic build #11. Siri recognition on a real device still needs checking.

## Family sharing (build 9)
- Firebase Email/Password sign-in with email verification, password reset, and generic Invite caregiver wording.
- Shared feedings, pumping, birthdate, nickname, and clinician-entered target; units and reminders remain per-phone.
- Owner creates private family and explicitly uploads existing local records; joining opens the shared journal without automatically importing unrelated local records.
- Email-bound, one-use, 48-hour invitation codes with manual sharing, revocation, and caregiver removal.
- Pull-to-refresh makes server reads, active listeners show remote changes, persistent outbox handles offline saves, and status shows pending changes/last refresh/errors.
- Record revision transactions, stable IDs, deletion tombstones, conflict review retaining both versions, and stale-editor checks prevent silent concurrent overwrites.
- Records display their last saving caregiver. Shared data is separately cached by family; previous local-only journals are retained.
- Security rules and their passing emulator tests are included in Firebase/. Native compilation and executable tests passed in build #11. Two-phone testing remains pending; rules must be published before sharing can connect.
