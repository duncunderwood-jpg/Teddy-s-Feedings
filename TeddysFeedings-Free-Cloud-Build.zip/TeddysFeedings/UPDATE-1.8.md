# Teddy’s Feedings 1.8 (build 12)

- Pumping reminders have separate per-phone enable, interval (1.5–6 hours), and lullaby controls in the Pumping tab. Each completed session resets a single reminder; edits, deletion, Siri logging and shared refresh recalculate it. Notification taps open Pumping with last-session time/amount and Log pumping. Five-second test button included. Refresh does not postpone a pending reminder or repeat the same delivered check-in. No session means no scheduled reminder. New settings default off and preserve old records.
- Pumping now shows a live Time since last pump card, measured from the latest session’s end, with date, time and amount. Updates every minute and after journal refresh/edit/delete. Future-dated entries are excluded; empty history shows a first-session prompt.
- Swipe left on feeding and pumping entries to reveal Delete; confirm before removal. Swipe right to edit. Shared deletions apply to both caregivers.
- No Practice mode. Joining a family opens its shared journal without uploading the joining phone’s old local entries. Create the family on the accurate phone; explicitly enable “Include this phone’s existing REAL entries” to import its history. Default: empty shared journal.
- New Log milk now Siri action records the current time without asking for a time. Try “Hey Siri, log 3 ounces of formula in Teddy’s Feedings.” If Siri cannot resolve the complete sentence, say “Log milk in Teddy’s Feedings” and give the amount and type when prompted.
- Warm spoken responses: “Looks like Teddy wanted a little more milk this time” or “A little less milk for Teddy this time,” followed by the numerical difference. Equal totals say he drank the same amount.
- Siri repeats the saved amounts, milk types and time, then compares the consumed total with the latest earlier logged feeding. Both formula and breast milk count toward that total. No comparison for the first feeding. Offline comparisons use the journal currently cached on the phone.
- Siri controls audio output. Choose Prefer Spoken Responses under Siri Responses on the iPhone for spoken confirmation.
- Short personal shortcut: name it Log milk, add Log milk now, set Bottle to Ask Each Time.

Validation: Swift syntax and project/workflow checks can run here. Native compilation, executable tests and Siri device behavior require the next Mac/iPhone build and have not yet run for 1.8. No paid-plan change is needed.
